<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/safe_render.php';
SafeRender::init();

$active = $_GET['page'] ?? 'files';
$view = $_GET['view'] ?? 'list';
$folderId = intval($_GET['folder'] ?? 0);

// API key verification ONLY for GET AJAX requests (not POST file operations)
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_SERVER['HTTP_X_RENDER_KEY'])) {
    SafeRender::requireApi();
}

// Handle logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    // Clear remember me cookie and token
    if (isset($_COOKIE['mycloud_remember'])) {
        list($uid, $token) = explode(':', $_COOKIE['mycloud_remember'], 2);
        $uid = intval($uid);
        if ($uid > 0) {
            $pdo->prepare("UPDATE users SET remember_token = NULL WHERE id = ?")->execute([$uid]);
        }
        setcookie('mycloud_remember', '', time() - 3600, '/');
    }
    session_destroy();
    header('Location: login.php');
    exit;
}

// Handle AJAX content requests (skip search, handled below)
if (isset($_GET['ajax']) && $_GET['ajax'] !== 'search' && isLogin()) {
    header('Content-Type: text/html; charset=utf-8');
    if ($_GET['ajax'] === 'breadcrumb') {
        $bid = intval($_GET['id'] ?? 0);
        $breadcrumb = [];
        $fid = $bid;
        while ($fid > 0) {
            $stmt = $pdo->prepare("SELECT id, name, parent_id FROM files WHERE id = ? AND uid = ? AND is_folder = 1");
            $stmt->execute([$fid, $_SESSION['uid']]);
            $f = $stmt->fetch();
            if (!$f) break;
            array_unshift($breadcrumb, $f);
            $fid = $f['parent_id'];
        }
        $html = '<a href="javascript:void(0)" onclick="navigateFolder(0)" class="bc-link"><i class="fa fa-home"></i> 全部文件</a>';
        foreach ($breadcrumb as $bc) {
            $html .= '<span class="bc-sep"><i class="fa fa-chevron-right"></i></span>';
            $html .= '<a href="javascript:void(0)" onclick="navigateFolder('.$bc['id'].')" class="bc-link">'.htmlspecialchars($bc['name']).'</a>';
        }
        echo $html;
        exit;
    }
    if ($active === 'files') { include __DIR__ . '/file_list.php'; }
    elseif ($active === 'files_grid') { include __DIR__ . '/file_grid.php'; }
    elseif ($active === 'upload') { include __DIR__ . '/upload_content.php'; }
    elseif ($active === 'recycle') { include __DIR__ . '/recycle_content.php'; }
    elseif ($active === 'settings') { include __DIR__ . '/settings_content.php'; }
    exit;
}

// Handle file operations (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isLogin()) {
    error_reporting(E_ERROR | E_PARSE);
    $action = $_POST['action'] ?? '';
    $uid = $_SESSION['uid'];

    // Upload skips CSRF here, verified inside upload handler
    if ($action !== 'upload' && $action !== 'upload_chunk') {
        verify_csrf();
    }

    if ($action === 'delete') {
        $id = intval($_POST['id']);
        $pdo->prepare("UPDATE files SET deleted = 1, deleted_at = NOW() WHERE id = ? AND uid = ?")->execute([$id, $uid]);
        header('Content-Type: application/json'); echo json_encode(['ok' => true]); exit;
    }
    if ($action === 'batch_delete') {
        $ids = array_map('intval', explode(',', $_POST['ids'] ?? ''));
        foreach ($ids as $id) {
            if ($id > 0) {
                $pdo->prepare("UPDATE files SET deleted = 1, deleted_at = NOW() WHERE id = ? AND uid = ?")->execute([$id, $uid]);
            }
        }
        header('Content-Type: application/json'); echo json_encode(['ok' => true]); exit;
    }
    if ($action === 'permanent_delete') {
        header('Content-Type: application/json');
        $id = intval($_POST['id']);
        $stmt = $pdo->prepare("SELECT * FROM files WHERE id = ? AND uid = ?");
        $stmt->execute([$id, $uid]);
        $file = $stmt->fetch();
        if ($file) {
            $filepath = UPLOAD_DIR . $file['hash'] . '.' . $file['ext'];
            if (file_exists($filepath)) unlink($filepath);
            $pdo->prepare("DELETE FROM files WHERE id = ?")->execute([$id]);
            $pdo->prepare("DELETE FROM shares WHERE file_id = ?")->execute([$id]);
        }
        header('Content-Type: application/json'); echo json_encode(['ok' => true]); exit;
    }
    if ($action === 'restore') {
        $id = intval($_POST['id']);
        $pdo->prepare("UPDATE files SET deleted = 0, deleted_at = NULL WHERE id = ? AND uid = ?")->execute([$id, $uid]);
        header('Content-Type: application/json'); echo json_encode(['ok' => true]); exit;
    }
    if ($action === 'batch_restore' || $action === 'batch_permanent_delete') {
        header('Content-Type: application/json');
        $ids = $_POST['ids'] ?? [];
        foreach ($ids as $id) {
            $id = intval($id);
            if ($action === 'batch_restore') {
                $pdo->prepare("UPDATE files SET deleted = 0, deleted_at = NULL WHERE id = ? AND uid = ?")->execute([$id, $uid]);
            } else {
                $stmt = $pdo->prepare("SELECT * FROM files WHERE id = ? AND uid = ?");
                $stmt->execute([$id, $uid]);
                $file = $stmt->fetch();
                if ($file) {
                    $filepath = UPLOAD_DIR . $file['hash'] . '.' . $file['ext'];
                    if (file_exists($filepath)) unlink($filepath);
                    $pdo->prepare("DELETE FROM files WHERE id = ?")->execute([$id]);
                    $pdo->prepare("DELETE FROM shares WHERE file_id = ?")->execute([$id]);
                }
            }
        }
        echo json_encode(['ok' => true]); exit;
    }
    if ($action === 'create_folder') {
        header('Content-Type: application/json');
        $name = cleanInput($_POST['name'] ?? '');
        $parentId = intval($_POST['parent_id'] ?? 0);
        if (empty($name)) { echo json_encode(['ok' => false, 'msg' => '文件夹名不能为空']); exit; }
        if (strlen($name) > 100) { echo json_encode(['ok' => false, 'msg' => '文件夹名过长']); exit; }
        $hash = md5(uniqid(mt_rand(), true));
        try {
            $pdo->prepare("INSERT INTO files (uid, name, ext, size, hash, type, is_folder, parent_id, added_at) VALUES (?, ?, '', 0, ?, 'folder', 1, ?, NOW())")
                ->execute([$uid, $name, $hash, $parentId]);
        } catch (Throwable $e) {
            echo json_encode(['ok' => false, 'msg' => $e->getMessage()]); exit;
        }
        echo json_encode(['ok' => true, 'id' => $pdo->lastInsertId()]); exit;
    }
    if ($action === 'rename') {
        header('Content-Type: application/json');
        $id = intval($_POST['id']);
        $name = cleanInput($_POST['name'] ?? '');
        if (empty($name)) { echo json_encode(['ok' => false, 'msg' => '名称不能为空']); exit; }
        try {
            $pdo->prepare("UPDATE files SET name = ? WHERE id = ? AND uid = ?")->execute([$name, $id, $uid]);
        } catch (Throwable $e) {
            echo json_encode(['ok' => false, 'msg' => $e->getMessage()]); exit;
        }
        echo json_encode(['ok' => true]); exit;
    }
    if ($action === 'list_folders') {
        header('Content-Type: application/json');
        $parentId = intval($_POST['parent_id'] ?? 0);
        $stmt = $pdo->prepare("SELECT id, name, parent_id FROM files WHERE uid = ? AND parent_id = ? AND is_folder = 1 AND deleted = 0 ORDER BY name ASC");
        $stmt->execute([$uid, $parentId]);
        $folders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $result = [];
        foreach ($folders as &$f) {
            $chk = $pdo->prepare("SELECT COUNT(*) FROM files WHERE uid = ? AND parent_id = ? AND is_folder = 1 AND deleted = 0");
            $chk->execute([$uid, $f['id']]);
            $f['has_children'] = intval($chk->fetchColumn()) > 0;
            $f['depth'] = 0;
            $result[] = $f;
        }
        echo json_encode(['folders' => $result]); exit;
    }
    if ($action === 'batch_move' || $action === 'batch_copy') {
        header('Content-Type: application/json');
        $ids = array_map('intval', explode(',', $_POST['ids'] ?? ''));
        $targetId = intval($_POST['target_id'] ?? 0);
        if (empty($ids)) { echo json_encode(['ok' => false, 'msg' => '未选择文件']); exit; }
        if ($targetId > 0) {
            $chk = $pdo->prepare("SELECT id FROM files WHERE id = ? AND uid = ? AND is_folder = 1 AND deleted = 0");
            $chk->execute([$targetId, $uid]);
            if (!$chk->fetch()) { echo json_encode(['ok' => false, 'msg' => '目标文件夹不存在']); exit; }
        }
        try {
            foreach ($ids as $id) {
                $stmt = $pdo->prepare("SELECT id, name, ext, hash, size, type, is_folder, parent_id FROM files WHERE id = ? AND uid = ? AND deleted = 0");
                $stmt->execute([$id, $uid]);
                $file = $stmt->fetch();
                if (!$file) continue;
                if ($action === 'batch_move') {
                    $pdo->prepare("UPDATE files SET parent_id = ? WHERE id = ? AND uid = ?")->execute([$targetId, $id, $uid]);
                } else {
                    $newName = $file['name'];
                    $dup = $pdo->prepare("SELECT id FROM files WHERE name = ? AND parent_id = ? AND uid = ? AND deleted = 0");
                    $dup->execute([$newName, $targetId, $uid]);
                    if ($dup->fetch()) {
                        $base = pathinfo($file['name'], PATHINFO_FILENAME);
                        $ext = $file['is_folder'] ? '' : '.' . $file['ext'];
                        $newName = $base . '_copy' . $ext;
                    }
                    if ($file['is_folder']) {
                        $pdo->prepare("INSERT INTO files (uid, name, ext, hash, size, type, is_folder, parent_id, added_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())")
                            ->execute([$uid, $newName, '', '', 0, '', 1, $targetId]);
                    } else {
                        $srcPath = UPLOAD_DIR . $file['hash'] . '.' . $file['ext'];
                        $newHash = md5(uniqid(mt_rand(), true));
                        $dstPath = UPLOAD_DIR . $newHash . '.' . $file['ext'];
                        if (is_file($srcPath) && copy($srcPath, $dstPath)) {
                            $pdo->prepare("INSERT INTO files (uid, name, ext, hash, size, type, is_folder, parent_id, added_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())")
                                ->execute([$uid, $newName, $file['ext'], $newHash, $file['size'], $file['type'], 0, $targetId]);
                        } else {
                            echo json_encode(['ok' => false, 'msg' => '复制文件失败: ' . $file['name']]); exit;
                        }
                    }
                }
            }
        } catch (Throwable $e) {
            echo json_encode(['ok' => false, 'msg' => $e->getMessage()]); exit;
        }
        echo json_encode(['ok' => true]); exit;
    }
    if ($action === 'create_share') {
        header('Content-Type: application/json');
        $fileId = intval($_POST['file_id']);
        $expiry = intval($_POST['expiry']);
        $hasCode = isset($_POST['has_code']) ? 1 : 0;
        $code = $hasCode ? generateShareCode(4) : '';
        $shareCode = generateShareCode(6);
        $expireTime = $expiry > 0 ? date('Y-m-d H:i:s', time() + $expiry * 86400) : null;
        if ($fileId <= 0) { echo json_encode(['success'=>false,'error'=>'无效的文件ID']); exit; }
        try {
            $stmt = $pdo->prepare("SELECT id FROM files WHERE id = ? AND uid = ? AND deleted = 0");
            $stmt->execute([$fileId, $uid]);
            if (!$stmt->fetch()) { echo json_encode(['success'=>false,'error'=>'文件不存在']); exit; }
            $pdo->prepare("INSERT INTO shares (file_id, uid, share_code, extract_code, expire_time) VALUES (?, ?, ?, ?, ?)")
                ->execute([$fileId, $uid, $shareCode, $code, $expireTime]);
        } catch (Throwable $e) {
            echo json_encode(['success'=>false,'error'=>$e->getMessage()]); exit;
        }
        $shareUrl = SITE_URL . '/share.php?code=' . $shareCode;
        echo json_encode(['url' => $shareUrl, 'code' => $code, 'success' => true]); exit;
    }
    if ($action === 'create_batch_share') {
        header('Content-Type: application/json');
        $fileIds = array_map('intval', explode(',', $_POST['file_ids'] ?? ''));
        $expiry = intval($_POST['expiry'] ?? 7);
        $hasCode = isset($_POST['has_code']) ? 1 : 0;
        $extractCode = $hasCode ? generateShareCode(4) : '';
        $batchCode = generateShareCode(8);
        $expireTime = $expiry > 0 ? date('Y-m-d H:i:s', time() + $expiry * 86400) : null;
        if (empty($fileIds)) { echo json_encode(['success'=>false,'error'=>'未选择文件']); exit; }
        try {
            $shareCodes = [];
            foreach ($fileIds as $fileId) {
                if ($fileId <= 0) continue;
                $stmt = $pdo->prepare("SELECT id FROM files WHERE id = ? AND uid = ? AND deleted = 0");
                $stmt->execute([$fileId, $uid]);
                if (!$stmt->fetch()) continue;
                $shareCode = generateShareCode(6);
                $pdo->prepare("INSERT INTO shares (file_id, uid, share_code, extract_code, expire_time) VALUES (?, ?, ?, ?, ?)")
                    ->execute([$fileId, $uid, $shareCode, '', $expireTime]);
                $shareCodes[] = $shareCode;
            }
            if (empty($shareCodes)) { echo json_encode(['success'=>false,'error'=>'没有有效的文件可分享']); exit; }
            $title = $_POST['title'] ?? '';
            $pdo->prepare("INSERT INTO batch_shares (uid, batch_code, title, share_codes, extract_code, expire_time) VALUES (?, ?, ?, ?, ?, ?)")
                ->execute([$uid, $batchCode, $title, implode(',', $shareCodes), $extractCode, $expireTime]);
        } catch (Throwable $e) {
            echo json_encode(['success'=>false,'error'=>$e->getMessage()]); exit;
        }
        $shareUrl = SITE_URL . '/batch_share.php?code=' . $batchCode;
        echo json_encode(['url'=>$shareUrl,'code'=>$extractCode,'success'=>true]); exit;
    }
    if ($action === 'upload') {
        error_reporting(E_ALL);
        ini_set('display_errors', 0);
        ini_set('log_errors', 1);
        verify_csrf();
        header('Content-Type: application/json');
        $results = [];
        try {
            error_log('UPLOAD_DEBUG: action=upload, FILES=' . print_r(array_keys($_FILES ?? []), true));
            $postMax = ini_get('post_max_size');
            $uploadMax = ini_get('upload_max_filesize');
            $postMaxBytes = parse_size($postMax);
            $uploadMaxBytes = parse_size($uploadMax);
            if (!isset($_FILES['files']) || empty($_FILES['files']['name'][0])) {
                if (isset($_SERVER['CONTENT_LENGTH']) && $_SERVER['CONTENT_LENGTH'] > 0) {
                    if ($_SERVER['CONTENT_LENGTH'] > $postMaxBytes) {
                        echo json_encode(['error'=>'文件('.round($_SERVER['CONTENT_LENGTH']/1048576,1).'MB)超过服务器限制('.$postMax.')，请压缩后重试']); exit;
                    }
                }
                echo json_encode(['error'=>'上传失败，当前限制 upload_max_filesize='.$uploadMax.', post_max_size='.$postMax]); exit;
            }
            foreach ($_FILES['files']['name'] as $i => $name) {
                if ($_FILES['files']['error'][$i] !== UPLOAD_ERR_OK) {
                    $errMsg = '上传错误';
                    $fileSize = $_FILES['files']['size'][$i] ?? 0;
                    $sizeStr = $fileSize > 0 ? '('.round($fileSize/1048576,1).'MB)' : '';
                    switch($_FILES['files']['error'][$i]){
                        case UPLOAD_ERR_INI_SIZE: $errMsg='文件'.$sizeStr.'超过上传限制('.$uploadMax.')，请压缩后重试'; break;
                        case UPLOAD_ERR_FORM_SIZE: $errMsg='文件'.$sizeStr.'超过表单限制('.$postMax.')，请压缩后重试'; break;
                        case UPLOAD_ERR_PARTIAL: $errMsg='文件只上传了一部分，请检查网络后重试'; break;
                        case UPLOAD_ERR_NO_FILE: $errMsg='没有文件被上传'; break;
                        case UPLOAD_ERR_NO_TMP_DIR: $errMsg='服务器临时目录不存在'; break;
                        case UPLOAD_ERR_CANT_WRITE: $errMsg='写入磁盘失败，请检查磁盘空间'; break;
                    }
                    $results[] = ['name'=>$name,'success'=>false,'msg'=>$errMsg]; continue;
                }
                $size = $_FILES['files']['size'][$i];
                $name = $_POST['original_name'] ?? $_FILES['files']['name'][$i];
                $ext = pathinfo($_FILES['files']['name'][$i], PATHINFO_EXTENSION);
                $hash = md5(uniqid(mt_rand(), true));
                $filetype = getFileType($ext);
                $dest = UPLOAD_DIR . $hash . '.' . $ext;
                if (!is_dir(UPLOAD_DIR)) @mkdir(UPLOAD_DIR, 0755, true);
                // Check disk space
                $free = @disk_free_space(UPLOAD_DIR);
                if ($free !== false && $free < $size) {
                    $results[] = ['name'=>$name,'success'=>false,'msg'=>'磁盘空间不足，剩余'.round($free/1048576,1).'MB']; continue;
                }
                $tmpName = $_FILES['files']['tmp_name'][$i];
                $tmpSize = @filesize($tmpName);
                // Verify temp file has content
                if ($tmpSize === false || $tmpSize === 0) {
                    $results[] = ['name'=>$name,'success'=>false,'msg'=>'临时文件为空，可能是上传超时或文件过大，请压缩后重试']; continue;
                }
                $saved = false;
                // Method 1: move_uploaded_file (standard)
                if (is_uploaded_file($tmpName)) {
                    $saved = @move_uploaded_file($tmpName, $dest);
                }
                // Method 2: rename (works on same filesystem, bypasses move_uploaded_file restrictions)
                if (!$saved && @is_readable($tmpName)) {
                    $saved = @rename($tmpName, $dest);
                }
                // Method 3: copy
                if (!$saved && @is_readable($tmpName)) {
                    $saved = @copy($tmpName, $dest);
                }
                // Method 4: stream copy
                if (!$saved && @is_readable($tmpName)) {
                    $in = @fopen($tmpName, 'rb');
                    $out = @fopen($dest, 'wb');
                    if ($in && $out) {
                        @stream_copy_to_stream($in, $out);
                        fclose($in); fclose($out);
                        $saved = @file_exists($dest) && @filesize($dest) > 0;
                    }
                }
                if ($saved) {
                    $parentId = intval($_POST['folder_id'] ?? 0);
                    $pdo->prepare("INSERT INTO files (uid, name, ext, size, hash, type, parent_id, added_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())")
                        ->execute([$uid, $name, $ext, $size, $hash, $filetype, $parentId]);
                    $results[] = ['name'=>$name,'success'=>true];
                } else {
                    $results[] = ['name'=>$name,'success'=>false,'msg'=>'保存失败，请压缩后重试'];
                }
            }
        } catch (Throwable $e) {
            if (empty($results)) {
                $results[] = ['name'=>'文件','success'=>false,'msg'=>'服务器错误: '.$e->getMessage()];
            }
        }
        echo json_encode($results, JSON_UNESCAPED_UNICODE); exit;
    }
    if ($action === 'upload_chunk') {
        verify_csrf();
        $fileId = preg_replace('/[^a-zA-Z0-9_\-]/', '', $_POST['file_id'] ?? '');
        $chunk = intval($_POST['chunk'] ?? 0);
        $totalChunks = intval($_POST['total_chunks'] ?? 1);
        $name = $_POST['name'] ?? '';
        $size = intval($_POST['size'] ?? 0);
        $parentId = intval($_POST['folder_id'] ?? 0);
        $ext = pathinfo($name, PATHINFO_EXTENSION);
        $chunkDir = UPLOAD_DIR . '.chunks/' . $fileId;
        if (!is_dir($chunkDir)) mkdir($chunkDir, 0755, true);
        $chunkFile = $chunkDir . '/' . $chunk . '.part';
        if (isset($_FILES['file_chunk'])) {
            move_uploaded_file($_FILES['file_chunk']['tmp_name'], $chunkFile);
        }
        if ($chunk + 1 >= $totalChunks) {
            $hash = md5(uniqid(mt_rand(), true));
            $dest = UPLOAD_DIR . $hash . '.' . $ext;
            $out = fopen($dest, 'wb');
            for ($i = 0; $i < $totalChunks; $i++) {
                $part = $chunkDir . '/' . $i . '.part';
                if (file_exists($part)) {
                    $in = fopen($part, 'rb');
                    stream_copy_to_stream($in, $out);
                    fclose($in);
                    unlink($part);
                }
            }
            fclose($out);
            rmdir($chunkDir);
            $filetype = getFileType($ext);
            $pdo->prepare("INSERT INTO files (uid, name, ext, size, hash, type, parent_id, added_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())")
                ->execute([$uid, $name, $ext, $size, $hash, $filetype, $parentId]);
            header('Content-Type: application/json'); echo json_encode(['ok'=>true,'merge'=>true]); exit;
        }
        header('Content-Type: application/json'); echo json_encode(['ok'=>true,'merge'=>false]); exit;
    }
    if ($action === 'cancel_chunk') {
        header('Content-Type: application/json');
        $fileId = preg_replace('/[^a-zA-Z0-9_\-]/', '', $_POST['file_id'] ?? '');
        if ($fileId) {
            $chunkDir = UPLOAD_DIR . '.chunks/' . $fileId;
            if (is_dir($chunkDir)) {
                $files = glob($chunkDir . '/*');
                foreach ($files as $f) { if (is_file($f)) unlink($f); }
                rmdir($chunkDir);
            }
        }
        echo json_encode(['ok' => true]); exit;
    }
    if ($action === 'batch_zip') {
        verify_csrf();
        $ids = array_values(array_filter(array_map('intval', explode(',', $_POST['ids'] ?? ''))));
        if (empty($ids)) { header('Content-Type: application/json'); echo json_encode(['error' => '未选择文件']); exit; }
        $stmt = $pdo->prepare("SELECT * FROM files WHERE id IN (" . implode(',', array_fill(0, count($ids), '?')) . ") AND uid = ? AND deleted = 0 AND is_folder = 0");
        $params = array_merge($ids, [$uid]);
        $stmt->execute($params);
        $files = $stmt->fetchAll();
        if (empty($files)) { header('Content-Type: application/json'); echo json_encode(['error' => '没有可压缩的文件']); exit; }
        $zipName = 'batch_' . date('Ymd_His') . '.zip';
        $zipPath = sys_get_temp_dir() . '/' . $zipName;
        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            header('Content-Type: application/json'); echo json_encode(['error' => '创建压缩包失败']); exit;
        }
        foreach ($files as $f) {
            $filepath = UPLOAD_DIR . $f['hash'] . '.' . $f['ext'];
            if (file_exists($filepath)) {
                $zip->addFile($filepath, $f['name']);
            }
        }
        $zip->close();
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $zipName . '"');
        header('Content-Length: ' . filesize($zipPath));
        readfile($zipPath);
        unlink($zipPath);
        exit;
    }
}

requireLogin();

// AJAX requests return raw content (no SafeRender encryption)
$isAjax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest';
if ($isAjax) {
    // Search: respond before page includes
    if (isset($_GET['ajax']) && $_GET['ajax'] === 'search') {
        header('Content-Type: text/html; charset=utf-8');
        $q = trim($_GET['q'] ?? '');
        if (mb_strlen($q) < 1) { echo ''; exit; }
        $uid = $_SESSION['uid'] ?? 0;
        if ($uid < 1) { echo '<!-- no session uid -->'; exit; }
        $like = '%' . $q . '%';
        $stmt = $pdo->prepare("SELECT id, name, ext, size, hash, type, is_folder, parent_id, added_at FROM files WHERE uid = ? AND deleted = 0 AND name LIKE ? ORDER BY is_folder DESC, name ASC LIMIT 50");
        $stmt->execute([$uid, $like]);
        $files = $stmt->fetchAll();
        $view = $_GET['view'] ?? 'list';
        if ($view === 'grid') {
            foreach ($files as $f) {
                $icon = 'fa-file-o';
                if ($f['is_folder']) $icon = 'fa-folder';
                else { $ft = getFileType($f['ext']); if ($ft === 'image') $icon = 'fa-file-image-o'; elseif ($ft === 'video') $icon = 'fa-file-video-o'; elseif ($ft === 'audio') $icon = 'fa-file-audio-o'; elseif ($ft === 'pdf') $icon = 'fa-file-pdf-o'; elseif ($ft === 'text') $icon = 'fa-file-text-o'; }
                $color = $f['is_folder'] ? 'var(--primary)' : 'var(--text-dim)';
                $onclick = $f['is_folder'] ? ' onclick="event.stopPropagation();navigateFolder('.$f['id'].')"' : '';
                echo '<div class="file-card" data-id="'.$f['id'].'" data-name="'.htmlspecialchars($f['name']).'" data-ext="'.$f['ext'].'" data-hash="'.$f['hash'].'" data-type="'.($f['is_folder']?'folder':'file').'"'.$onclick.' style="cursor:pointer">';
                echo '<div class="card-select"><input type="checkbox" class="file-cb" value="'.$f['id'].'" style="accent-color:var(--primary)"></div>';
                echo '<div class="card-icon"><i class="fa '.$icon.'" style="color:'.$color.'"></i></div>';
                echo '<div class="card-name" title="'.htmlspecialchars($f['name']).'">'.htmlspecialchars($f['name']).'</div>';
                echo '<div class="card-size">'.($f['is_folder'] ? '文件夹' : formatSize($f['size'])).'</div>';
                echo '</div>';
            }
        } else {
            foreach ($files as $f) {
                $type = $f['is_folder'] ? 'folder' : getFileType($f['ext']);
                $dblclick = $f['is_folder'] ? "if(!event.target.closest('.file-cb')&&!event.target.closest('.file-actions'))navigateFolder({$f['id']})" : "";
                $click = $f['is_folder'] ? "if(!event.target.closest('.file-cb')&&!event.target.closest('.file-actions'))navigateFolder({$f['id']})" : "";
                echo '<tr class="file-row" data-id="'.$f['id'].'" data-type="'.($f['is_folder']?'folder':'file').'" data-ext="'.htmlspecialchars($f['ext']).'" data-hash="'.htmlspecialchars($f['hash']).'" data-name="'.htmlspecialchars($f['name']).'" data-size="'.$f['size'].'" ondblclick="'.$dblclick.'" onclick="'.$click.'">';
                echo '<td><input type="checkbox" class="file-cb" value="'.$f['id'].'" style="accent-color:var(--primary)"></td>';
                echo '<td><div class="file-name"><div class="icon '.$type.'">';
                if ($f['is_folder']) echo '<i class="fa fa-folder"></i>';
                else echo getFileIcon($type);
                echo '</div><span class="name-text">'.htmlspecialchars($f['name']).'</span></div></td>';
                echo '<td class="file-size">'.($f['is_folder'] ? '—' : formatSize($f['size'])).'</td>';
                echo '<td class="file-time">'.$f['added_at'].'</td>';
                echo '<td><div class="file-actions">';
                if (!$f['is_folder']) {
                    echo '<button onclick="event.stopPropagation();previewFile('.$f['id'].',\''.htmlspecialchars($f['name']).'\',\''.$f['ext'].'\',\''.$f['hash'].'\')" title="查看" class="action-btn"><i class="fa fa-eye"></i></button>';
                    echo '<a href="download.php?id='.$f['id'].'" title="下载" class="action-btn"><i class="fa fa-download"></i></a>';
                    echo '<button onclick="event.stopPropagation();openShare('.$f['id'].',\''.htmlspecialchars($f['name']).'\','.$f['size'].')" title="分享" class="action-btn"><i class="fa fa-share-alt"></i></button>';
                }
                echo '<button onclick="event.stopPropagation();renameItem('.$f['id'].',\''.htmlspecialchars($f['name']).'\')" title="重命名" class="action-btn"><i class="fa fa-pencil"></i></button>';
                echo '<button onclick="event.stopPropagation();deleteItem('.$f['id'].',\''.htmlspecialchars($f['name']).'\')" title="删除" class="action-btn danger"><i class="fa fa-trash"></i></button>';
                echo '</div></td></tr>';
            }
        }
        exit;
    }
    // Breadcrumb
    if (isset($_GET['ajax']) && $_GET['ajax'] === 'breadcrumb') {
        $bid = intval($_GET['id'] ?? 0);
        $breadcrumb = [];
        $fid = $bid;
        while ($fid > 0) {
            $stmt = $pdo->prepare("SELECT id, name, parent_id FROM files WHERE id = ? AND uid = ? AND is_folder = 1");
            $stmt->execute([$fid, $_SESSION['uid']]);
            $f = $stmt->fetch();
            if (!$f) break;
            array_unshift($breadcrumb, $f);
            $fid = $f['parent_id'];
        }
        $html = '<a href="javascript:void(0)" onclick="navigateFolder(0)" class="bc-link"><i class="fa fa-home"></i> 全部文件</a>';
        foreach ($breadcrumb as $bc) {
            $html .= '<span class="bc-sep"><i class="fa fa-chevron-right"></i></span>';
            $html .= '<a href="javascript:void(0)" onclick="navigateFolder('.$bc['id'].')" class="bc-link">'.htmlspecialchars($bc['name']).'</a>';
        }
        echo $html;
        exit;
    }
    // Page content includes
    if ($active === 'files') {
        if ($view === 'grid') { include __DIR__ . '/file_grid.php'; }
        else { include __DIR__ . '/file_list.php'; }
    } elseif ($active === 'upload') { include __DIR__ . '/upload_content.php'; }
    elseif ($active === 'recycle') { include __DIR__ . '/recycle_content.php'; }
    elseif ($active === 'settings') { include __DIR__ . '/settings_content.php'; }
    elseif ($active === 'shares') { include __DIR__ . '/shares_content.php'; }
    exit;
}

ob_start();
require_once __DIR__ . '/includes/header.php';
?>

<?php if ($active === 'files'): ?>
    <?php if ($view === 'grid'): ?>
        <?php include __DIR__ . '/file_grid.php'; ?>
    <?php else: ?>
        <?php include __DIR__ . '/file_list.php'; ?>
    <?php endif; ?>
<?php elseif ($active === 'upload'): ?>
    <?php include __DIR__ . '/upload_content.php'; ?>
<?php elseif ($active === 'recycle'): ?>
    <?php include __DIR__ . '/recycle_content.php'; ?>
<?php elseif ($active === 'settings'): ?>
    <?php include __DIR__ . '/settings_content.php'; ?>
<?php elseif ($active === 'shares'): ?>
    <?php include __DIR__ . '/shares_content.php'; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php';
$html = ob_get_clean();
SafeRender::render($html);
