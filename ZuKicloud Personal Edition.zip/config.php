<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'mycloud');
define('DB_USER', 'root');
define('DB_PASS', '123456');
define('DB_CHARSET', 'utf8mb4');

define('SITE_NAME', 'MyCloud');
define('SITE_URL', 'http://localhost:8004');
define('VERSION', '1.0.0');
define('UPLOAD_DIR', __DIR__ . '/upload/');
define('MAX_FILE_SIZE', 2 * 1024 * 1024 * 1024); // 2GB
// Storage limit: dynamically get disk free space of upload directory
function getStorageLimit() {
    $bytes = disk_free_space(UPLOAD_DIR);
    return $bytes ? $bytes : PHP_INT_MAX;
}
function getStorageTotal() {
    $bytes = disk_total_space(UPLOAD_DIR);
    return $bytes ? $bytes : PHP_INT_MAX;
}
define('RECYCLE_DAYS', 30);

function parse_size($size) {
    $unit = preg_replace('/[^a-zA-Z]/', '', $size);
    $size = (int) $size;
    if (stripos($size, 'G') !== false) $size *= 1024 * 1024 * 1024;
    elseif (stripos($size, 'M') !== false) $size *= 1024 * 1024;
    elseif (stripos($size, 'K') !== false) $size *= 1024;
    return $size;
}

session_start();
