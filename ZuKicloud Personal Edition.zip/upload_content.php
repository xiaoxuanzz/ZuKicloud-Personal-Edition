<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
requireLogin();
?>

<div class="content-area">
    <div class="upload-zone" id="dropZone" onclick="document.getElementById('fileInput').click()">
        <input type="file" id="fileInput" multiple style="display:none" onchange="handleFiles(this.files)">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
        <div class="uz-icon"><i class="fa fa-cloud-upload"></i></div>
        <p class="uz-text" id="uzText">点击选择文件或拖拽到此处</p>
        <p class="uz-sub">支持任意格式，单文件最大 <?= ini_get('upload_max_filesize') ?>，超大文件自动分片上传</p>
        <div class="upload-btns">
            <button class="btn-file primary" onclick="event.stopPropagation();document.getElementById('fileInput').click()">选择文件</button>
        </div>
    </div>
    <div style="margin-top:24px;padding:16px;border-radius:12px;background:var(--bg);font-size:.8125rem;color:var(--text-dim);line-height:1.8;">
        <p style="font-weight:600;color:var(--text);margin-bottom:8px;"><i class="fa fa-info-circle" style="color:var(--primary);"></i> 上传说明</p>
        <p>支持所有文件格式上传，包括 PPT、Word、Excel、PDF、图片、视频、压缩包等。</p>
        <p>单文件超过服务器限制时，系统将自动分片上传。</p>
        <p>上传进度可在右下角悬浮按钮查看，切换页面不会中断上传。</p>
    </div>
</div>
<script>
const dropZone=document.getElementById('dropZone');
dropZone.addEventListener('dragover',e=>{e.preventDefault();dropZone.classList.add('dragover');document.getElementById('uzText').textContent='释放以上传文件'});
dropZone.addEventListener('dragleave',()=>{dropZone.classList.remove('dragover');document.getElementById('uzText').textContent='点击选择文件或拖拽到此处'});
dropZone.addEventListener('drop',e=>{e.preventDefault();dropZone.classList.remove('dragover');document.getElementById('uzText').textContent='点击选择文件或拖拽到此处';UploadManager.addFiles(e.dataTransfer.files)});
function handleFiles(files){UploadManager.addFiles(files);}
function clearTasks(){UploadManager.cancelAll();}
</script>
