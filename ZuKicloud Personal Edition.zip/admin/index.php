<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/safe_render.php';
SafeRender::init();

$activePage = 'admin';
$pageTitle = '管理面板 - ' . SITE_NAME;

// 读取自定义更新链接
$linkFile = __DIR__ . '/../data/update_links.json';
$customLinks = ['uhub' => '', 'github' => ''];
if (file_exists($linkFile)) {
    $customLinks = json_decode(file_get_contents($linkFile), true) ?: $customLinks;
}

// 保存自定义链接（PRG模式：保存后重定向，避免重复提交）
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_links'])) {
    verify_csrf();
    $uhub = trim($_POST['uhub_url'] ?? '');
    $github = trim($_POST['github_repo'] ?? '');
    $links = ['uhub' => $uhub, 'github' => $github];
    if (!is_dir(__DIR__ . '/../data')) @mkdir(__DIR__ . '/../data', 0755, true);
    file_put_contents($linkFile, json_encode($links, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    header('Location: index.php?saved=1');
    exit;
}

if (isset($_GET['saved']) && $_GET['saved'] === '1') {
    $savedMsg = '链接已保存';
}

ob_start();
require_once __DIR__ . '/../includes/header.php';
?>

<div class="content-area">
    <div class="settings-wrap">
        <?php if (!empty($savedMsg)): ?>
            <div class="alert alert-success"><i class="fa fa-check-circle"></i> <?= $savedMsg ?></div>
        <?php endif; ?>

        <!-- 更新管理 -->
        <section class="settings-sec">
            <h3><i class="fa fa-cloud-download" style="color:var(--primary)"></i> 更新管理</h3>
            <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;font-size:.875rem;">
                <span style="color:var(--text-sub);">当前版本</span>
                <span id="currentVer" style="font-weight:600;color:var(--text);">v<?= VERSION ?></span>
                <span id="latestVer" style="color:var(--text-sub);"></span>
            </div>

            <!-- 高级设置（可折叠） -->
            <details style="margin-bottom:16px;">
                <summary style="cursor:pointer;font-size:.8125rem;color:var(--text-sub);padding:8px 0;user-select:none;"><i class="fa fa-cog"></i> 高级设置</summary>
                <form method="POST" style="margin-top:8px;">
                    <?= csrf_field() ?>
                    <input type="hidden" name="save_links" value="1">
                    <div class="fg">
                        <label>私人推送节点 URL</label>
                        <input type="text" name="uhub_url" value="<?= htmlspecialchars($customLinks['uhub']) ?>" placeholder="https://update.xiaoxuanzz.cloud/index.php?route=api/mycloud" style="width:100%;padding:10px 16px;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--input-bg);font-size:.875rem;outline:none;box-sizing:border-box;">
                    </div>
                    <div class="fg" style="margin-top:12px;">
                        <label>GitHub 仓库 (owner/repo)</label>
                        <input type="text" name="github_repo" value="<?= htmlspecialchars($customLinks['github']) ?>" placeholder="xiaoxuanzz/mycloud" style="width:100%;padding:10px 16px;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--input-bg);font-size:.875rem;outline:none;box-sizing:border-box;">
                    </div>
                    <button type="submit" class="btn-save" style="margin-top:12px;"><i class="fa fa-save"></i> 保存链接</button>
                </form>
            </details>

            <div style="display:flex;gap:8px;margin-bottom:12px;">
                <button class="btn-pwd" onclick="checkUpdate()" style="font-size:.8125rem;padding:8px 16px;"><i class="fa fa-refresh"></i> 检查更新</button>
                <button class="btn-save" id="btnApply" onclick="applyUpdate()" style="display:none;"><i class="fa fa-download"></i> 应用更新</button>
            </div>
            <div class="alert" id="updateResult" style="display:none;margin-top:12px;"></div>

            <!-- 更新日志 -->
            <div id="changelogBox" style="display:none;margin-top:12px;">
                <div style="font-weight:600;color:var(--text);font-size:.875rem;margin-bottom:8px;"><i class="fa fa-list-ul"></i> 更新日志</div>
                <div id="changelogContent" style="background:var(--input-bg);border:1px solid var(--border);border-radius:var(--radius-sm);padding:12px 16px;font-size:.8125rem;color:var(--text-sub);max-height:200px;overflow-y:auto;line-height:1.8;white-space:pre-wrap;"></div>
            </div>
        </section>

        <!-- 系统信息 -->
        <section class="settings-sec">
            <h3><i class="fa fa-info-circle" style="color:var(--primary)"></i> 系统信息</h3>
            <div class="info-row"><span class="info-label">站点名称</span><span class="info-value"><?= SITE_NAME ?></span></div>
            <div class="info-row"><span class="info-label">PHP 版本</span><span class="info-value"><?= PHP_VERSION ?></span></div>
            <div class="info-row"><span class="info-label">MySQL</span><span class="info-value"><?= $pdo->query('SELECT VERSION()')->fetchColumn() ?></span></div>
            <div class="info-row"><span class="info-label">服务器</span><span class="info-value" style="font-size:.75rem;"><?= $_SERVER['SERVER_SOFTWARE'] ?? 'N/A' ?></span></div>
            <div class="info-row"><span class="info-label">当前用户</span><span class="info-value"><?= htmlspecialchars(getCurrentUser()['nickname'] ?? getCurrentUser()['username']) ?></span></div>
        </section>

        <!-- 文件统计 -->
        <section class="settings-sec">
            <h3><i class="fa fa-database" style="color:var(--primary)"></i> 文件统计</h3>
            <div class="info-row"><span class="info-label">文件数量</span><span class="info-value"><?= $pdo->query("SELECT COUNT(*) FROM files WHERE deleted=0")->fetchColumn() ?></span></div>
            <div class="info-row"><span class="info-label">分享数量</span><span class="info-value"><?= $pdo->query("SELECT COUNT(*) FROM shares")->fetchColumn() ?></span></div>
            <div class="info-row"><span class="info-label">已删除文件</span><span class="info-value"><?= $pdo->query("SELECT COUNT(*) FROM files WHERE deleted=1")->fetchColumn() ?></span></div>
            <div class="info-row"><span class="info-label">存储使用</span><span class="info-value"><?= formatSize($pdo->query("SELECT COALESCE(SUM(size),0) FROM files WHERE deleted=0")->fetchColumn()) ?></span></div>
        </section>
    </div>
</div>

<script>
function verCompare(a,b){
    var pa=a.split('.').map(Number),pb=b.split('.').map(Number);
    for(var i=0;i<3;i++){if((pa[i]||0)>(pb[i]||0))return 1;if((pa[i]||0)<(pb[i]||0))return -1;}
    return 0;
}
function checkUpdate() {
    var btn=document.querySelector('button[onclick="checkUpdate()"]');
    var icon=btn?btn.querySelector('i'):null;
    if(icon){icon.classList.add('fa-spin');btn.disabled=true;}
    var el = document.getElementById('latestVer');
    if (el) {el.textContent='检查中...';el.style.color='var(--text-sub)';}
    var uhubUrl = document.querySelector('input[name="uhub_url"]').value.trim();
    var ghRepo = document.querySelector('input[name="github_repo"]').value.trim();
    var params = 'act=check&_t=' + Date.now();
    if (uhubUrl) params += '&uhub_url=' + encodeURIComponent(uhubUrl);
    if (ghRepo) params += '&gh_repo=' + encodeURIComponent(ghRepo);
    fetch('admin/ajax_update.php?' + params)
        .then(r => r.json())
        .then(data => {
            if(icon){icon.classList.remove('fa-spin');btn.disabled=false;}
            if (data.code === 0 && data.version) {
                var cur=data.current||'<?= VERSION ?>';
                if(el){el.textContent='最新 v'+data.version;el.style.color='var(--text-sub)';}
                if(verCompare(data.version,cur)>0){
                    document.getElementById('btnApply').style.display = 'inline-flex';
                    showUpdateResult('info', '发现新版本: v' + data.version + ' (当前 v'+cur+') - ' + data.source);
                    if (data.changelog) {
                        var box = document.getElementById('changelogBox');
                        var content = document.getElementById('changelogContent');
                        if (box && content) {box.style.display = 'block';content.textContent = data.changelog;}
                    }
                } else {
                    document.getElementById('btnApply').style.display = 'none';
                    showUpdateResult('success', '当前已是最新版本 v'+cur);
                }
            } else {
                if (el) {el.textContent = data.msg || '获取失败';el.style.color='var(--danger)';}
                showUpdateResult('error', data.msg || '无法获取版本信息');
            }
        })
        .catch(err => {
            if(icon){icon.classList.remove('fa-spin');btn.disabled=false;}
            if (el) {el.textContent = '连接失败';el.style.color='var(--danger)';}
            showUpdateResult('error', '连接更新服务器失败: ' + err.message);
        });
}
function applyUpdate() {
    if (!confirm('确定要更新吗？')) return;
    var btn=document.getElementById('btnApply');
    var icon=btn?btn.querySelector('i'):null;
    if(icon){icon.classList.add('fa-spin');btn.disabled=true;}
    showUpdateResult('info', '正在下载更新...');
    fetch('admin/ajax_update.php?act=update', { method: 'POST' })
        .then(r => r.json())
        .then(data => {
            if(icon){icon.classList.remove('fa-spin');btn.disabled=false;}
            if (data.code === 0) {
                showUpdateResult('success', '更新成功！' + data.msg);
                setTimeout(() => location.reload(), 2000);
            } else {
                showUpdateResult('error', '更新失败: ' + (data.msg || '未知错误'));
            }
        })
        .catch(err => {
            if(icon){icon.classList.remove('fa-spin');btn.disabled=false;}
            showUpdateResult('error', '连接失败: ' + err.message);
        });
}
function showUpdateResult(type, msg) {
    var el = document.getElementById('updateResult');
    el.style.display = 'block';
    el.style.opacity = '0';
    el.style.transform = 'translateY(-8px)';
    el.className = 'alert alert-' + (type === 'error' ? 'danger' : type === 'success' ? 'success' : 'info');
    el.innerHTML = msg;
    requestAnimationFrame(function(){
        el.style.transition = 'opacity .3s, transform .3s';
        el.style.opacity = '1';
        el.style.transform = 'translateY(0)';
    });
}
setTimeout(function(){checkUpdate();},1000);
</script>

<?php
require_once __DIR__ . '/../includes/footer.php';
$html = ob_get_clean();
SafeRender::render($html);
