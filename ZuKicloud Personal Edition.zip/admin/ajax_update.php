<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireLogin();

$action = $_GET['act'] ?? $_POST['act'] ?? '';
$source = $_REQUEST['source'] ?? 'auto';
if (!in_array($source, ['auto', 'uhub', 'github'])) $source = 'auto';

header('Content-Type: application/json; charset=utf-8');

// 读取自定义链接（支持前端传入覆盖）
$linkFile = __DIR__ . '/../data/update_links.json';
$links = ['uhub' => '', 'github' => ''];
if (file_exists($linkFile)) {
    $links = json_decode(file_get_contents($linkFile), true) ?: $links;
}

$uhubApi = $_REQUEST['uhub_url'] ?? ($links['uhub'] ?: 'https://update.xiaoxuanzz.cloud/index.php?route=api/mycloud');
// 规范化URL：去掉末尾的 /latest、/check 等路径
$uhubApi = preg_replace('#/(latest|check|download)(\?.*)?$#i', '', rtrim($uhubApi, '/'));
$ghRepo = $_REQUEST['gh_repo'] ?? ($links['github'] ?: 'xiaoxuanzz/mycloud');

function httpGet($url, $timeout = 10) {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_ENCODING => '',
        CURLOPT_USERAGENT => 'MyCloud-Update/1.0',
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    if ($body === false || $code !== 200) return null;
    return $body;
}

function httpGetJson($url, $timeout = 10) {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTPHEADER => ['Accept: application/json', 'Accept-Encoding: identity'],
        CURLOPT_USERAGENT => 'MyCloud-Update/1.0',
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($body === false || $code !== 200) return null;
    return $body;
}

function githubApi($url) {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTPHEADER => ['Accept: application/vnd.github.v3+json', 'User-Agent: MyCloud-Update'],
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($body === false || $code !== 200) return null;
    $data = @json_decode($body, true);
    return is_array($data) ? $data : null;
}

/* ========== 检查更新 ========== */
if ($action === 'check') {
    $result = null;
    $usedSource = '';
    $debug = [];

    // 尝试私人节点
    if (($source === 'auto' || $source === 'uhub') && $uhubApi) {
        $url = $uhubApi . '/check&_=' . time();
        $debug[] = 'url:' . $url;
        $body = httpGetJson($url);
        $debug[] = 'body_len:' . strlen($body ?? 'null');
        $debug[] = 'body_start:' . substr($body ?? 'null', 0, 100);
        $data = $body ? @json_decode($body, true) : null;
        $debug[] = 'parsed:' . ($data ? 'yes' : 'no');
        if ($data) {
            $debug[] = 'keys:' . implode(',', array_keys($data));
            if (isset($data['latest'])) {
                $debug[] = 'latest_keys:' . implode(',', array_keys($data['latest']));
            }
        }
        if ($data && isset($data['latest']['version'])) {
            $result = ['version' => $data['latest']['version'], 'changelog' => $data['latest']['changelog'] ?? '', 'source' => '私人节点'];
            $usedSource = '私人节点';
        }
    }

    // 尝试 GitHub
    if (!$result && ($source === 'auto' || $source === 'github') && $ghRepo) {
        $data = githubApi("https://api.github.com/repos/$ghRepo/releases/latest");
        if ($data && isset($data['tag_name'])) {
            $ver = preg_replace('/^v/i', '', $data['tag_name']);
            $result = ['version' => $ver, 'changelog' => $data['body'] ?? '', 'source' => 'GitHub'];
            $usedSource = 'GitHub';
        }
    }

    if ($result) {
        echo json_encode(['code' => 0, 'version' => $result['version'], 'current' => VERSION, 'changelog' => $result['changelog'], 'source' => $result['source']]);
    } else {
        echo json_encode(['code' => 1, 'msg' => '无法获取版本信息，请检查网络连接或更新地址是否正确', 'current' => VERSION, 'debug' => $debug]);
    }
    exit;
}

/* ========== 更新下载 ========== */
if ($action === 'update') {
    if (!class_exists('ZipArchive')) {
        echo json_encode(['code' => 1, 'msg' => '请启用 php_zip 扩展']);
        exit;
    }

    $tempDir = sys_get_temp_dir() . '/mycloud_update';
    $zipFile = sys_get_temp_dir() . '/mycloud_update.zip';

    // 获取下载链接
    $downloadUrl = null;
    if (($source === 'auto' || $source === 'uhub') && $uhubApi) {
        // /latest 端点直接返回 ZIP 文件，使用它作为下载链接
        $downloadUrl = $uhubApi . '/latest&_=' . time();
    }
    if (!$downloadUrl && ($source === 'auto' || $source === 'github') && $ghRepo) {
        $data = githubApi("https://api.github.com/repos/$ghRepo/releases/latest");
        if ($data && !empty($data['zipball_url'])) {
            $downloadUrl = $data['zipball_url'];
        }
    }
    if (!$downloadUrl) {
        $downloadUrl = "https://github.com/$ghRepo/archive/refs/heads/main.zip";
    }

    // 下载
    $fp = @fopen($zipFile, 'w');
    if (!$fp) {
        echo json_encode(['code' => 1, 'msg' => '无法创建临时文件']);
        exit;
    }
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $downloadUrl,
        CURLOPT_FILE => $fp,
        CURLOPT_TIMEOUT => 300,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_USERAGENT => 'Mozilla/5.0',
    ]);
    curl_exec($ch);
    $hc = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    fclose($fp);

    if ($hc !== 200 || filesize($zipFile) < 100) {
        @unlink($zipFile);
        echo json_encode(['code' => 1, 'msg' => '下载失败 (HTTP ' . $hc . ')']);
        exit;
    }

    // 解压
    $zip = new ZipArchive();
    if ($zip->open($zipFile) !== true) {
        @unlink($zipFile);
        echo json_encode(['code' => 1, 'msg' => '无法解压 ZIP 文件']);
        exit;
    }
    if (is_dir($tempDir)) {
        array_map('unlink', glob("$tempDir/*"));
        @rmdir($tempDir);
    }
    $zip->extractTo($tempDir);
    $zip->close();

    // 找到解压后的根目录
    $root = null;
    foreach (scandir($tempDir) as $item) {
        if ($item !== '.' && $item !== '..' && is_dir("$tempDir/$item")) {
            $root = "$tempDir/$item";
            break;
        }
    }
    if (!$root) {
        @unlink($zipFile);
        echo json_encode(['code' => 1, 'msg' => '解压后找不到项目目录']);
        exit;
    }

    // 复制文件
    $projectRoot = dirname(__DIR__);
    $copied = 0;
    $skipped = 0;
    $excludeDirs = ['admin', 'data', 'upload', '.git', 'vendor_imports'];
    $excludeFiles = ['config.php', 'install.php', '.htaccess'];

    function copyRecursive($src, $dst, &$copied, &$skipped, $ed, $ef) {
        if (!is_dir($src)) return;
        if (!is_dir($dst)) @mkdir($dst, 0755, true);
        foreach (scandir($src) as $item) {
            if ($item === '.' || $item === '..') continue;
            $sp = "$src/$item";
            $dp = "$dst/$item";
            if (is_dir($sp)) {
                if (in_array($item, $ed)) { $skipped++; continue; }
                copyRecursive($sp, $dp, $copied, $skipped, $ed, $ef);
            } else {
                if (in_array($item, $ef)) { $skipped++; continue; }
                if (copy($sp, $dp)) $copied++;
                else $skipped++;
            }
        }
    }

    copyRecursive($root, $projectRoot, $copied, $skipped, $excludeDirs, $excludeFiles);

    // 清理
    @unlink($zipFile);
    array_map('unlink', glob("$tempDir/*"));
    @rmdir($tempDir);

    // 更新 config.php 中的 VERSION
    $newVer = null;
    if ($data && isset($data['tag_name'])) {
        $newVer = preg_replace('/^v/i', '', $data['tag_name']);
    } elseif (isset($result['version'])) {
        $newVer = $result['version'];
    }
    if ($newVer) {
        $cfgFile = $projectRoot . '/config.php';
        if (file_exists($cfgFile)) {
            $cfg = file_get_contents($cfgFile);
            $cfg = preg_replace("/define\('VERSION'\s*,\s*'[^']*'\)/", "define('VERSION', '$newVer')", $cfg);
            file_put_contents($cfgFile, $cfg);
        }
    }

    echo json_encode(['code' => 0, 'msg' => "更新成功！复制 $copied 个文件，跳过 $skipped 个", 'version' => $newVer]);
    exit;
}

echo json_encode(['code' => 1, 'msg' => '未知操作']);
