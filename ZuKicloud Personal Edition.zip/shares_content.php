<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
requireLogin();

$uid = $_SESSION['uid'];

// 删除分享
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_share'])) {
    verify_csrf();
    $id = intval($_POST['id']);
    $type = $_POST['type'] ?? '';
    if ($type === 'batch') {
        $batch = $pdo->prepare("SELECT share_codes FROM batch_shares WHERE id = ? AND uid = ?");
        $batch->execute([$id, $uid]);
        $row = $batch->fetch();
        if ($row) {
            $codes = array_filter(explode(',', $row['share_codes']));
            if (!empty($codes)) {
                $ph = implode(',', array_fill(0, count($codes), '?'));
                $pdo->prepare("DELETE FROM shares WHERE share_code IN ($ph) AND uid = ?")->execute(array_merge($codes, [$uid]));
            }
            $pdo->prepare("DELETE FROM batch_shares WHERE id = ? AND uid = ?")->execute([$id, $uid]);
        }
    } else {
        $pdo->prepare("DELETE FROM shares WHERE id = ? AND uid = ?")->execute([$id, $uid]);
    }
    header('Location: index.php?page=shares');
    exit;
}

// 获取批量分享
$batchShares = $pdo->prepare("SELECT * FROM batch_shares WHERE uid = ? ORDER BY created_at DESC");
$batchShares->execute([$uid]);
$batchShares = $batchShares->fetchAll(PDO::FETCH_ASSOC);

// 收集所有批量分享中引用的 share_code
$batchCodes = [];
foreach ($batchShares as $b) {
    $codes = array_filter(explode(',', $b['share_codes']));
    $batchCodes = array_merge($batchCodes, $codes);
}

// 获取单个分享（排除批量分享中的）
if (!empty($batchCodes)) {
    $singleShares = $pdo->prepare("SELECT s.*, f.name, f.ext, f.size, f.type FROM shares s JOIN files f ON s.file_id = f.id WHERE s.uid = ? AND f.deleted = 0 AND s.share_code NOT IN (" . implode(',', array_fill(0, count($batchCodes), '?')) . ") ORDER BY s.created_at DESC");
    $singleShares->execute(array_merge([$uid], $batchCodes));
} else {
    $singleShares = $pdo->prepare("SELECT s.*, f.name, f.ext, f.size, f.type FROM shares s JOIN files f ON s.file_id = f.id WHERE s.uid = ? AND f.deleted = 0 ORDER BY s.created_at DESC");
    $singleShares->execute([$uid]);
}
$singleShares = $singleShares->fetchAll(PDO::FETCH_ASSOC);

$activePage = 'shares';
$pageForTitle = 'shares';
require_once __DIR__ . '/includes/header.php';
?>

<div class="content-area" style="display:flex;flex-direction:column;overflow:hidden;">
    <div style="flex:1;overflow-y:auto;">
    <div class="settings-wrap">
        <section class="settings-sec">
            <h3><i class="fa fa-share-alt" style="color:var(--primary)"></i> 我的分享</h3>
            <?php if (empty($singleShares) && empty($batchShares)): ?>
                <div class="empty-state" style="padding:40px 0;">
                    <i class="fa fa-share-alt" style="font-size:48px;color:var(--text-dim);margin-bottom:12px;"></i>
                    <p style="color:var(--text-dim);">暂无分享记录</p>
                </div>
            <?php else: ?>
                <?php foreach ($batchShares as $b):
                    $shareCodes = array_filter(explode(',', $b['share_codes']));
                    $fileNames = [];
                    if (!empty($shareCodes)) {
                        $ph = implode(',', array_fill(0, count($shareCodes), '?'));
                        $stmt = $pdo->prepare("SELECT f.name FROM shares s JOIN files f ON s.file_id = f.id WHERE s.share_code IN ($ph) AND f.deleted = 0");
                        $stmt->execute($shareCodes);
                        $fileNames = $stmt->fetchAll(PDO::FETCH_COLUMN);
                    }
                ?>
                <div style="background:#fff;border-radius:12px;border:1px solid var(--border);padding:16px 20px;margin-bottom:12px;">
                    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;">
                        <div style="display:flex;align-items:center;gap:10px;min-width:0;">
                            <div style="width:36px;height:36px;border-radius:10px;background:var(--primary-bg);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                                <i class="fa fa-files-o" style="color:var(--primary);"></i>
                            </div>
                            <div style="min-width:0;">
                                <div style="font-weight:600;font-size:.875rem;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= htmlspecialchars($b['title'] ?: count($fileNames) . ' 个文件') ?></div>
                                <div style="font-size:.75rem;color:var(--text-dim);margin-top:2px;">
                                    <?= $b['created_at'] ?>
                                    <?php if ($b['expire_time']): ?>
                                        · 有效期至 <?= date('Y-m-d', strtotime($b['expire_time'])) ?>
                                    <?php else: ?>
                                        · 永久有效
                                    <?php endif; ?>
                                    <?php if ($b['extract_code']): ?>
                                        · 提取码 <?= $b['extract_code'] ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div style="display:flex;gap:6px;flex-shrink:0;">
                            <button class="action-btn" onclick="copyText('<?= SITE_URL ?>/batch_share.php?code=<?= $b['batch_code'] ?>')" title="复制链接"><i class="fa fa-copy"></i></button>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('确定删除此分享？')">
                                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                <input type="hidden" name="id" value="<?= $b['id'] ?>">
                                <input type="hidden" name="type" value="batch">
                                <button type="submit" name="delete_share" class="action-btn danger" title="删除"><i class="fa fa-trash"></i></button>
                            </form>
                        </div>
                    </div>
                    <?php if (!empty($fileNames)): ?>
                    <div style="margin-top:10px;padding-top:10px;border-top:1px solid var(--border);display:flex;flex-wrap:wrap;gap:6px;">
                        <?php foreach ($fileNames as $fn): ?>
                            <span style="font-size:.75rem;background:var(--bg);padding:3px 10px;border-radius:6px;color:var(--text-sub);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:200px;" title="<?= htmlspecialchars($fn) ?>"><?= htmlspecialchars($fn) ?></span>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>

                <?php foreach ($singleShares as $s): ?>
                <div style="background:#fff;border-radius:12px;border:1px solid var(--border);padding:16px 20px;margin-bottom:12px;">
                    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;">
                        <div style="display:flex;align-items:center;gap:10px;min-width:0;">
                            <div style="width:36px;height:36px;border-radius:10px;background:var(--primary-bg);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                                <i class="fa fa-file" style="color:var(--primary);"></i>
                            </div>
                            <div style="min-width:0;">
                                <div style="font-weight:600;font-size:.875rem;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= htmlspecialchars($s['name']) ?></div>
                                <div style="font-size:.75rem;color:var(--text-dim);margin-top:2px;">
                                    <?= $s['created_at'] ?>
                                    · <?= formatSize($s['size']) ?>
                                    <?php if ($s['expire_time']): ?>
                                        · 有效期至 <?= date('Y-m-d', strtotime($s['expire_time'])) ?>
                                    <?php else: ?>
                                        · 永久有效
                                    <?php endif; ?>
                                    <?php if ($s['extract_code']): ?>
                                        · 提取码 <?= $s['extract_code'] ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div style="display:flex;gap:6px;flex-shrink:0;">
                            <button class="action-btn" onclick="copyText('<?= SITE_URL ?>/share.php?code=<?= $s['share_code'] ?>')" title="复制链接"><i class="fa fa-copy"></i></button>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('确定删除此分享？')">
                                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                <input type="hidden" name="id" value="<?= $s['id'] ?>">
                                <input type="hidden" name="type" value="single">
                                <button type="submit" name="delete_share" class="action-btn danger" title="删除"><i class="fa fa-trash"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </section>
    </div>
    </div>

<script>
function copyText(val){
    navigator.clipboard.writeText(val).catch(function(){
        var t=document.createElement('textarea');t.value=val;document.body.appendChild(t);t.select();document.execCommand('copy');document.body.removeChild(t);
    });
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
