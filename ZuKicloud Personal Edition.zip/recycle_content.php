<?php
$uid = $_SESSION['uid'];

// Handle single restore
if (isset($_POST['action']) && $_POST['action'] === 'restore') {
    verify_csrf();
    $id = intval($_POST['id']);
    $stmt = $pdo->prepare("UPDATE files SET deleted = 0, deleted_at = NULL WHERE id = ? AND uid = ?");
    $stmt->execute([$id, $uid]);
    header('Location: index.php?page=recycle');
    exit;
}

// Handle single permanent delete
if (isset($_POST['action']) && $_POST['action'] === 'permanent_delete') {
    verify_csrf();
    $id = intval($_POST['id']);
    $stmt = $pdo->prepare("SELECT * FROM files WHERE id = ? AND uid = ?");
    $stmt->execute([$id, $uid]);
    $file = $stmt->fetch();
    if ($file) {
        $filepath = UPLOAD_DIR . $file['hash'] . '.' . $file['ext'];
        if (file_exists($filepath)) unlink($filepath);
        $stmt = $pdo->prepare("DELETE FROM files WHERE id = ?");
        $stmt->execute([$id]);
        $pdo->prepare("DELETE FROM shares WHERE file_id = ?")->execute([$id]);
    }
    header('Location: index.php?page=recycle');
    exit;
}

// Handle batch operations
if (isset($_POST['action']) && in_array($_POST['action'], ['batch_restore', 'batch_permanent_delete', 'empty_recycle'])) {
    verify_csrf();
    $action = $_POST['action'];
    if ($action === 'empty_recycle') {
        $files = $pdo->prepare("SELECT * FROM files WHERE uid = ? AND deleted = 1");
        $files->execute([$uid]);
        $files = $files->fetchAll();
        foreach ($files as $f) {
            $filepath = UPLOAD_DIR . $f['hash'] . '.' . $f['ext'];
            if (file_exists($filepath)) unlink($filepath);
            $pdo->prepare("DELETE FROM shares WHERE file_id = ?")->execute([$f['id']]);
        }
        $pdo->prepare("DELETE FROM files WHERE uid = ? AND deleted = 1")->execute([$uid]);
    } else {
        $ids = $_POST['ids'] ?? [];
        foreach ($ids as $id) {
            $id = intval($id);
            if ($action === 'batch_restore') {
                $pdo->prepare("UPDATE files SET deleted = 0, deleted_at = NULL WHERE id = ? AND uid = ?")->execute([$id, $uid]);
            } else {
                $stmt = $pdo->prepare("SELECT * FROM files WHERE id = ? AND uid = ?");
                $stmt->execute([$id, $uid]);
                $file = $stmt->fetch();
                if ($file) {
                    $filepath = UPLOAD_DIR . $file['hash'] . '.' . $file['ext'];
                    if (file_exists($filepath)) unlink($filepath);
                    $pdo->prepare("DELETE FROM files WHERE id = ?")->execute([$id]);
                    $pdo->prepare("DELETE FROM shares WHERE file_id = ?")->execute([$id]);
                }
            }
        }
    }
    header('Location: index.php?page=recycle');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM files WHERE uid = ? AND deleted = 1 ORDER BY deleted_at DESC");
$stmt->execute([$uid]);
$recycled = $stmt->fetchAll();
?>

<div class="content-area" style="display:flex;flex-direction:column;overflow:hidden;">
    <div style="flex:1;overflow-y:auto;">
    <div class="settings-wrap">
        <section class="settings-sec">
            <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:16px;">
                <h3 style="margin:0;"><i class="fa fa-trash-o" style="color:var(--primary)"></i> 回收站</h3>
                <?php if (!empty($recycled)): ?>
                <div style="display:flex;gap:8px;">
                    <form method="POST" onsubmit="return confirm('确定清空回收站？彻底删除后不可恢复！')">
                        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                        <input type="hidden" name="action" value="empty_recycle">
                        <button type="submit" class="btn-del-p" style="font-size:.75rem;padding:6px 12px;"><i class="fa fa-trash"></i> 一键清空</button>
                    </form>
                </div>
                <?php endif; ?>
            </div>

            <div class="notice-bar" style="margin-bottom:12px;">
                <i class="fa fa-exclamation-circle"></i>
                <p>回收站文件将在 <strong>30 天</strong>后自动永久删除，请及时恢复重要文件。</p>
            </div>

            <?php if (!empty($recycled)): ?>
            <form method="POST" id="rcBatchForm">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                <div id="rcBatchBar" style="display:none;align-items:center;gap:10px;padding:10px 14px;border-radius:10px;background:var(--primary-bg);margin-bottom:12px;font-size:.8125rem;">
                    <span id="rcSelectedCount" style="color:var(--primary);font-weight:500;">已选择 0 项</span>
                    <button type="submit" name="action" value="batch_restore" class="btn-restore" style="font-size:.75rem;padding:5px 10px;"><i class="fa fa-undo"></i> 批量恢复</button>
                    <button type="button" class="btn-del-p" style="font-size:.75rem;padding:5px 10px;" onclick="rcBatchDelete()"><i class="fa fa-trash"></i> 批量删除</button>
                    <button type="button" class="btn-cancel" style="font-size:.75rem;padding:5px 10px;border:1px solid var(--border);background:#fff;color:var(--text-sub);border-radius:8px;cursor:pointer;" onclick="rcClearSelection()">取消</button>
                </div>

                <table class="file-table">
                    <thead>
                        <tr>
                            <th style="width:40px"><input type="checkbox" onchange="rcToggleAll(this)" style="accent-color:var(--primary)"></th>
                            <th>文件名</th>
                            <th style="width:160px">删除时间</th>
                            <th style="width:160px">操作</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($recycled as $f): ?>
                        <tr class="file-row" data-id="<?= $f['id'] ?>">
                            <td><input type="checkbox" class="rc-cb" value="<?= $f['id'] ?>" onchange="rcToggleSelect()" style="accent-color:var(--primary)"></td>
                            <td><div class="file-name"><div class="icon <?= $f['type'] ?>"><?= getFileIcon($f['type']) ?></div><span class="name-text"><?= htmlspecialchars($f['name']) ?></span></div></td>
                            <td class="file-time"><?= $f['deleted_at'] ?></td>
                            <td>
                                <div class="file-actions" style="opacity:1">
                                    <button type="button" class="btn-restore" style="font-size:.75rem" onclick="rcRestore(<?= $f['id'] ?>)"><i class="fa fa-undo"></i> 恢复</button>
                                    <button type="button" class="btn-del-p" style="font-size:.75rem" onclick="rcPermanentDelete(<?= $f['id'] ?>)"><i class="fa fa-trash"></i> 彻底删除</button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </form>
            <?php else: ?>
            <div style="text-align:center;padding:60px 0;color:var(--text-dim);">
                <i class="fa fa-trash-o" style="font-size:48px;margin-bottom:12px;display:block;"></i>
                <p>回收站为空</p>
            </div>
            <?php endif; ?>
        </section>
    </div>
    </div>

<script>
var csrfToken = '<?= csrf_token() ?>';

function rcToggleAll(cb) {
    document.querySelectorAll('.rc-cb').forEach(function(c) { c.checked = cb.checked; });
    rcUpdateBar();
}

function rcToggleSelect() {
    rcUpdateBar();
}

function rcUpdateBar() {
    var checked = document.querySelectorAll('.rc-cb:checked');
    var bar = document.getElementById('rcBatchBar');
    var cnt = document.getElementById('rcSelectedCount');
    if (checked.length > 0) {
        bar.style.display = 'flex';
        cnt.textContent = '已选择 ' + checked.length + ' 项';
    } else {
        bar.style.display = 'none';
    }
}

function rcClearSelection() {
    document.querySelectorAll('.rc-cb').forEach(function(c) { c.checked = false; });
    rcUpdateBar();
}

function rcRestore(id) {
    fetch('index.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest'},
        body: 'action=restore&id=' + id + '&csrf_token=' + csrfToken
    }).then(function(r) { return r.json(); }).then(function(d) {
        if (d.ok) loadRecycle();
    });
}

function rcPermanentDelete(id) {
    if (!confirm('彻底删除后不可恢复！')) return;
    fetch('index.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest'},
        body: 'action=permanent_delete&id=' + id + '&csrf_token=' + csrfToken
    }).then(function(r) { return r.json(); }).then(function(d) {
        if (d.ok) loadRecycle();
    });
}

function rcBatchDelete() {
    var ids = [];
    document.querySelectorAll('.rc-cb:checked').forEach(function(c) { ids.push(c.value); });
    if (!ids.length) return;
    if (!confirm('确定彻底删除选中的 ' + ids.length + ' 个文件？不可恢复！')) return;
    fetch('index.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest'},
        body: 'action=batch_permanent_delete&ids[]=' + ids.join('&ids[]=') + '&csrf_token=' + csrfToken
    }).then(function(r) { return r.json(); }).then(function(d) {
        if (d.ok) loadRecycle();
    });
}

function loadRecycle() {
    fetch('index.php?page=recycle&ajax=recycle', {headers: {'X-Requested-With': 'XMLHttpRequest'}})
        .then(function(r) { return r.text(); })
        .then(function(html) {
            var el = document.querySelector('.content-area');
            if (el) {
                var temp = document.createElement('div');
                temp.innerHTML = html;
                el.innerHTML = temp.querySelector('.content-area').innerHTML;
            }
        });
}
</script>
