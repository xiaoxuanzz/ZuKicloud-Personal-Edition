<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';

if (isLogin()) { header('Location: index.php'); exit; }

$msg = '';
$msgType = 'success';
$step = $_GET['step'] ?? 'email';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'send_code') {
        $email = trim($_POST['email'] ?? '');
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $msg = '请输入有效的邮箱地址'; $msgType = 'danger';
        } else {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            if (!$user) {
                $msg = '该邮箱未注册'; $msgType = 'danger';
            } else {
                $rl = rateLimit('reset:' . getClientIp(), 3, 600, 600);
                if (!$rl['ok']) {
                    $msg = '请求过于频繁，请等待 ' . $rl['wait'] . ' 秒'; $msgType = 'danger';
                } else {
                    $code = str_pad(random_int(100000, 999999), 6, '0', STR_PAD_LEFT);
                    $_SESSION['reset_email'] = $email;
                    $_SESSION['reset_code'] = $code;
                    $_SESSION['reset_time'] = time();
                    $msg = "验证码已发送到 $email（演示模式：验证码为 $code）"; $msgType = 'success';
                    $step = 'verify';
                }
            }
        }
    } elseif ($action === 'verify_code') {
        $inputCode = trim($_POST['code'] ?? '');
        if (empty($inputCode)) {
            $msg = '请输入验证码'; $msgType = 'danger';
        } elseif (!isset($_SESSION['reset_code']) || !isset($_SESSION['reset_email'])) {
            $msg = '请先获取验证码'; $msgType = 'danger';
        } elseif (time() - ($_SESSION['reset_time'] ?? 0) > 600) {
            $msg = '验证码已过期，请重新获取'; $msgType = 'danger'; $step = 'email';
        } elseif ($inputCode !== $_SESSION['reset_code']) {
            $msg = '验证码错误'; $msgType = 'danger';
        } else {
            $_SESSION['reset_verified'] = true;
            $step = 'reset';
        }
    } elseif ($action === 'reset_password') {
        $new = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';
        if (!isset($_SESSION['reset_verified']) || !$_SESSION['reset_verified']) {
            $msg = '请先验证邮箱'; $msgType = 'danger'; $step = 'email';
        } elseif (strlen($new) < 8) {
            $msg = '新密码至少8位字符'; $msgType = 'danger';
        } elseif ($new !== $confirm) {
            $msg = '两次密码不一致'; $msgType = 'danger';
        } else {
            $hash = password_hash($new, PASSWORD_DEFAULT);
            $pdo->prepare("UPDATE users SET password = ? WHERE email = ?")->execute([$hash, $_SESSION['reset_email']]);
            unset($_SESSION['reset_email'], $_SESSION['reset_code'], $_SESSION['reset_time'], $_SESSION['reset_verified']);
            $msg = '密码已重置，请使用新密码登录'; $msgType = 'success';
            $step = 'done';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>忘记密码 - <?= SITE_NAME ?></title>
    <link rel="icon" type="image/svg+xml" href="favicon.svg">
    <link rel="stylesheet" href="assets/css/fontawesome/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <?php include __DIR__ . '/includes/antidebug.php'; ?>
    <style>
    .reset-card{background:#fff;border-radius:var(--radius);padding:40px;max-width:420px;width:100%;box-shadow:var(--shadow);margin:60px auto}
    .reset-card h2{font-weight:600;font-size:1.25rem;color:var(--text);margin-bottom:8px;text-align:center}
    .reset-card .subtitle{color:var(--text-dim);font-size:.875rem;text-align:center;margin-bottom:24px}
    .reset-icon{width:64px;height:64px;border-radius:50%;background:var(--primary-bg);display:flex;align-items:center;justify-content:center;margin:0 auto 20px;color:var(--primary);font-size:28px}
    .code-input{text-align:center;font-size:1.5rem;letter-spacing:.3em;font-weight:600}
    .back-link{text-align:center;margin-top:16px;font-size:.8125rem}
    .back-link a{color:var(--primary);font-weight:500}
    </style>
</head>
<body style="background:var(--bg);min-height:100vh;display:flex;align-items:center;justify-content:center;">
<div class="reset-card">
    <div class="reset-icon"><i class="fa fa-<?= $step==='email'?'envelope' : ($step==='verify'?'shield':'check-circle') ?>"></i></div>
    <h2><?= $step==='email'?'忘记密码' : ($step==='verify'?'验证邮箱' : ($step==='reset'?'重置密码':'完成')) ?></h2>
    <p class="subtitle"><?= $step==='email'?'输入注册邮箱，我们将发送验证码' : ($step==='verify'?'请输入收到的6位验证码' : ($step==='reset'?'设置新密码':'密码已重置')) ?></p>
    <?php if ($msg): ?>
        <div class="alert alert-<?= $msgType ?>" style="margin-bottom:16px;"><i class="fa fa-<?= $msgType==='success'?'check-circle':'exclamation-circle' ?>"></i> <?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>
    <?php if ($step === 'email'): ?>
    <form method="POST"><?= csrf_field() ?><input type="hidden" name="action" value="send_code">
        <div class="form-group"><label>邮箱地址</label><div class="input-wrap"><i class="fa fa-envelope-o"></i><input type="email" name="email" placeholder="请输入注册邮箱" required autofocus></div></div>
        <button type="submit" class="btn-primary">发送验证码</button>
    </form>
    <?php elseif ($step === 'verify'): ?>
    <form method="POST"><?= csrf_field() ?><input type="hidden" name="action" value="verify_code">
        <div class="form-group"><label>验证码</label><div class="input-wrap"><i class="fa fa-key"></i><input type="text" name="code" placeholder="请输入6位验证码" required maxlength="6" pattern="[0-9]{6}" class="code-input" autofocus></div></div>
        <button type="submit" class="btn-primary">验证</button>
    </form>
    <?php elseif ($step === 'reset'): ?>
    <form method="POST"><?= csrf_field() ?><input type="hidden" name="action" value="reset_password">
        <div class="form-group"><label>新密码</label><div class="input-wrap"><i class="fa fa-lock"></i><input type="password" name="new_password" placeholder="请输入新密码（至少8位）" required minlength="8"></div></div>
        <div class="form-group"><label>确认密码</label><div class="input-wrap"><i class="fa fa-lock"></i><input type="password" name="confirm_password" placeholder="再次输入新密码" required minlength="8"></div></div>
        <button type="submit" class="btn-primary">重置密码</button>
    </form>
    <?php elseif ($step === 'done'): ?>
    <a href="login.php" class="btn-primary" style="display:block;text-align:center;text-decoration:none;">去登录</a>
    <?php endif; ?>
    <div class="back-link"><a href="login.php"><i class="fa fa-arrow-left"></i> 返回登录</a></div>
</div>
</body>
</html>
