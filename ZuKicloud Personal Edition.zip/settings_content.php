<?php
$user = getCurrentUser();
$msg = '';
$msgType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['form_action'] ?? '';

    if ($action === 'profile') {
        $nickname = trim($_POST['nickname'] ?? '');
        $email = trim($_POST['email'] ?? '');
        if (!empty($nickname) && !empty($email)) {
            if (!isEmail($email)) { $msg = '邮箱格式不正确'; $msgType = 'danger'; }
            elseif (strlen($nickname) < 2 || strlen($nickname) > 20) { $msg = '昵称需要2-20个字符'; $msgType = 'danger'; }
            else {
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ? AND id != ?");
                $stmt->execute([$email, $_SESSION['uid']]);
                if ($stmt->fetchColumn() > 0) { $msg = '该邮箱已被其他账号使用'; $msgType = 'danger'; }
                else {
                    $stmt = $pdo->prepare("UPDATE users SET nickname = ?, email = ? WHERE id = ?");
                    $stmt->execute([$nickname, $email, $_SESSION['uid']]);
                    $msg = '信息已保存'; $user = getCurrentUser();
                }
            }
        }
    } elseif ($action === 'avatar_crop') {
        $imgData = $_POST['avatar_data'] ?? '';
        if (empty($imgData)) { $msg = '请选择头像'; $msgType = 'danger'; }
        else {
            if (preg_match('/^data:image\/(\w+);base64,/', $imgData, $m)) { $ext = $m[1]; $imgData = substr($imgData, strpos($imgData, ',') + 1); } else { $ext = 'png'; }
            $imgBytes = base64_decode($imgData);
            if ($imgBytes === false) { $msg = '图片数据无效'; $msgType = 'danger'; }
            else {
                if (!empty($user['avatar'])) { $old = __DIR__ . '/..' . $user['avatar']; if (file_exists($old)) @unlink($old); }
                $name = 'avatar_' . $_SESSION['uid'] . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
                $dest = UPLOAD_DIR . 'avatars/' . $name;
                if (!is_dir(UPLOAD_DIR . 'avatars')) @mkdir(UPLOAD_DIR . 'avatars', 0755, true);
                if (file_put_contents($dest, $imgBytes)) {
                    $pdo->prepare("UPDATE users SET avatar = ? WHERE id = ?")->execute(['/upload/avatars/' . $name, $_SESSION['uid']]);
                    $msg = '头像已更新'; $user = getCurrentUser();
                } else { $msg = '头像保存失败'; $msgType = 'danger'; }
            }
        }
    } elseif ($action === 'password') {
        $cur = $_POST['current_pwd'] ?? ''; $new = $_POST['new_pwd'] ?? ''; $cfm = $_POST['confirm_pwd'] ?? '';
        if (!password_verify($cur, $user['password'])) { $msg = '当前密码错误'; $msgType = 'danger'; }
        elseif (strlen($new) < 8) { $msg = '新密码至少8位字符'; $msgType = 'danger'; }
        elseif ($new !== $cfm) { $msg = '两次密码不一致'; $msgType = 'danger'; }
        else {
            $pdo->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([password_hash($new, PASSWORD_DEFAULT), $_SESSION['uid']]);
            $msg = '密码已修改'; $user = getCurrentUser();
        }
    }
}

$used = getUserStorageUsed($_SESSION['uid']);
$totalGB = round(getStorageTotal() / 1073741824, 1);
$usedGB = round($used / 1073741824, 2);
$storageData = [
    ['name'=>'文档','value'=>round(max(0,$usedGB*0.35),2),'color'=>'#4F6EF7'],
    ['name'=>'图片','value'=>round(max(0,$usedGB*0.25),2),'color'=>'#EC4899'],
    ['name'=>'视频','value'=>round(max(0,$usedGB*0.25),2),'color'=>'#F97316'],
    ['name'=>'其他','value'=>round(max(0,$usedGB*0.15),2),'color'=>'#94A3B8'],
];
$totalUsed = array_sum(array_column($storageData, 'value'));
$avatarUrl = !empty($user['avatar']) ? $user['avatar'] : '';
$initial = mb_substr($user['nickname'] ?? $user['username'], 0, 1);
?>

<div class="content-area">
    <div class="settings-wrap">
        <?php if ($msg): ?>
            <div class="alert alert-<?= $msgType ?>"><i class="fa fa-<?= $msgType==='success'?'check-circle':'exclamation-circle' ?>"></i> <?= htmlspecialchars($msg) ?></div>
        <?php endif; ?>

        <!-- Basic Info + Avatar -->
        <section class="settings-sec">
            <h3>基本信息</h3>
            <div class="avatar-row">
                <div class="avatar-pos" style="cursor:pointer" onclick="document.getElementById('avatarInput').click()">
                    <?php if ($avatarUrl): ?>
                        <img id="avatarImg" src="<?= htmlspecialchars($avatarUrl) ?>" style="width:80px;height:80px;border-radius:50%;object-fit:cover;">
                    <?php else: ?>
                        <div class="avatar-circle" id="avatarImg"><?= $initial ?></div>
                    <?php endif; ?>
                    <div class="avatar-edit"><i class="fa fa-camera"></i></div>
                    <input type="file" id="avatarInput" accept="image/*" style="display:none" onchange="previewAvatar(this)">
                </div>
                <form class="s-form" method="POST" action="index.php?page=settings">
                    <input type="hidden" name="form_action" value="profile">
                    <?= csrf_field() ?>
                    <div class="fg"><label>昵称</label><input type="text" name="nickname" value="<?= htmlspecialchars($user['nickname'] ?? $user['username']) ?>" required></div>
                    <div class="fg"><label>邮箱</label><input type="email" name="email" value="<?= htmlspecialchars($user['email'] ?? '') ?>" required></div>
                    <button type="submit" class="btn-save"><i class="fa fa-save"></i> 保存修改</button>
                </form>
            </div>
        </section>

        <!-- Security -->
        <section class="settings-sec">
            <h3>安全设置</h3>
            <form class="s-form" method="POST" action="index.php?page=settings">
                <input type="hidden" name="form_action" value="password">
                <?= csrf_field() ?>
                <div class="fg"><label>当前密码</label><input type="password" name="current_pwd" placeholder="请输入当前密码" required></div>
                <div class="fg"><label>新密码</label><input type="password" name="new_pwd" placeholder="请输入新密码（8位以上）" required minlength="8"></div>
                <div class="fg"><label>确认密码</label><input type="password" name="confirm_pwd" placeholder="再次输入新密码" required></div>
                <button type="submit" class="btn-pwd">修改密码</button>
            </form>
        </section>

        <!-- Quick Help -->
        <section class="settings-sec" style="cursor:pointer" onclick="localStorage.removeItem('mycloud_ob_done');location.href='index.php?page=files';">
            <div style="display:flex;align-items:center;gap:12px;">
                <div style="width:40px;height:40px;border-radius:10px;background:var(--primary-bg);display:flex;align-items:center;justify-content:center;color:var(--primary);font-size:18px;"><i class="fa fa-question-circle"></i></div>
                <div>
                    <h3 style="margin-bottom:2px;">查看使用引导</h3>
                    <p style="color:var(--text-dim);font-size:.8125rem;">重新查看核心功能介绍</p>
                </div>
                <i class="fa fa-chevron-right" style="margin-left:auto;color:var(--text-dim);font-size:12px;"></i>
            </div>
        </section>

        <!-- 自动检查更新 -->
        <section class="settings-sec">
            <div style="display:flex;align-items:center;justify-content:space-between;">
                <div style="display:flex;align-items:center;gap:12px;">
                    <div style="width:40px;height:40px;border-radius:10px;background:#FEF3C7;display:flex;align-items:center;justify-content:center;color:var(--warning);font-size:18px;"><i class="fa fa-cloud-download"></i></div>
                    <div>
                        <h3 style="margin-bottom:2px;">自动检查更新</h3>
                        <p style="color:var(--text-dim);font-size:.8125rem;">每次打开页面时自动检测新版本</p>
                    </div>
                </div>
                <div class="toggle-switch <?= isset($_COOKIE['mycloud_auto_update']) && $_COOKIE['mycloud_auto_update']==='1' ? 'active' : '' ?>" id="autoUpdateToggle" onclick="toggleAutoUpdate()">
                    <div class="toggle-knob"></div>
                </div>
            </div>
        </section>

        <!-- Storage -->
        <section class="settings-sec">
            <h3>存储空间</h3>
            <div class="storage-analytics">
                <div class="donut-wrap">
                    <canvas id="donutChart" width="140" height="140"></canvas>
                    <div class="donut-center">
                        <span class="total"><?= $usedGB ?></span>
                        <span class="limit">/ <?= $totalGB ?> GB</span>
                    </div>
                </div>
                <div class="storage-bars">
                    <?php foreach ($storageData as $item): ?>
                    <div class="sbar-item">
                        <div class="bar-hdr">
                            <div class="bar-label"><span class="bar-dot" style="background:<?= $item['color'] ?>"></span><?= $item['name'] ?></div>
                            <span class="bar-val"><?= $item['value'] ?> GB</span>
                        </div>
                        <div class="bar-track"><div class="bar-fill" style="width:<?= $totalGB>0?($item['value']/$totalGB*100):0 ?>%;background:<?= $item['color'] ?>"></div></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    </div>
</div>

<!-- Simple Crop Modal (no external deps) -->
<div class="crop-overlay" id="cropModal">
    <div class="crop-card">
        <h3>裁剪头像</h3>
        <div class="crop-preview" id="cropWrap">
            <img id="cropImage" src="" style="display:block;max-width:100%;max-height:320px;">
            <div id="cropBox" style="position:absolute;border:2px solid #fff;box-shadow:0 0 0 9999px rgba(0,0,0,0.45);cursor:move;display:none;">
                <div style="position:absolute;inset:-4px;border:2px solid var(--primary);border-radius:2px;pointer-events:none;"></div>
            </div>
        </div>
        <div class="crop-actions">
            <button class="crop-btn-cancel" onclick="closeCrop()">取消</button>
            <button class="crop-btn-ok" onclick="applyCrop()">确定</button>
        </div>
    </div>
</div>

<script>
let cropImg=null, cropBox=null, cropWrap=null, isDragging=false, startX=0, startY=0, boxX=0, boxY=0, boxSize=0;

function previewAvatar(input) {
    if (!input.files||!input.files[0]) return;
    const f=input.files[0];
    if(!f.type.startsWith('image/')){alert('请选择图片');return;}
    if(f.size>5*1024*1024){alert('图片不能超过5MB');return;}
    const r=new FileReader();
    r.onload=function(e){
        cropImg=document.getElementById('cropImage');
        cropImg.src=e.target.result;
        cropBox=document.getElementById('cropBox');
        cropWrap=document.getElementById('cropWrap');
        document.getElementById('cropModal').classList.add('show');
        setTimeout(()=>{
            const iw=cropImg.naturalWidth, ih=cropImg.naturalHeight;
            const dw=cropImg.clientWidth, dh=cropImg.clientHeight;
            boxSize=Math.min(dw,dh)*0.65;
            boxX=(dw-boxSize)/2; boxY=(dh-boxSize)/2;
            cropBox.style.cssText='display:block;width:'+boxSize+'px;height:'+boxSize+'px;left:'+boxX+'px;top:'+boxY+'px;border:2px solid #fff;box-shadow:0 0 0 9999px rgba(0,0,0,0.45);cursor:move;position:absolute;';
            cropBox.onmousedown=startDrag; cropBox.ontouchstart=startDrag;
        },150);
    };
    r.readAsDataURL(f);
    input.value='';
}
function startDrag(e){isDragging=true;const p=e.touches?e.touches[0]:e;startX=p.clientX;startY=p.clientY;boxX=cropBox.offsetLeft;boxY=cropBox.offsetTop;e.preventDefault();
    document.onmousemove=doDrag;document.onmouseup=stopDrag;document.ontouchmove=doDrag;document.ontouchend=stopDrag;}
function doDrag(e){if(!isDragging)return;const p=e.touches?e.touches[0]:e;const dx=p.clientX-startX,dy=p.clientY-startY;const nx=Math.max(0,Math.min(cropImg.clientWidth-boxSize,boxX+dx));const ny=Math.max(0,Math.min(cropImg.clientHeight-boxSize,boxY+dy));cropBox.style.left=nx+'px';cropBox.style.top=ny+'px';}
function stopDrag(){isDragging=false;document.onmousemove=null;document.onmouseup=null;document.ontouchmove=null;document.ontouchend=null;}
function applyCrop(){
    if(!cropImg||!cropBox)return;
    const iw=cropImg.naturalWidth,ih=cropImg.naturalHeight,dw=cropImg.clientWidth,dh=cropImg.clientHeight;
    const sx=cropBox.offsetLeft/dw*iw, sy=cropBox.offsetTop/dh*ih, sw=boxSize/dw*iw, sh=boxSize/dh*ih;
    const c=document.createElement('canvas');c.width=256;c.height=256;
    const ctx=c.getContext('2d');ctx.drawImage(cropImg,sx,sy,sw,sh,0,0,256,256);
    const dUrl=c.toDataURL('image/png');
    const form=document.createElement('form');form.method='POST';form.action='index.php?page=settings';
    [['form_action','avatar_crop'],['csrf_token','<?= csrf_token() ?>'],['avatar_data',dUrl]].forEach(([n,v])=>{
        const i=document.createElement('input');i.type='hidden';i.name=n;i.value=v;form.appendChild(i);
    });
    document.body.appendChild(form);form.submit();
}
function closeCrop(){document.getElementById('cropModal').classList.remove('show');cropImg=null;cropBox=null;}

// Donut chart
const cv=document.getElementById('donutChart'),cx2=cv.getContext('2d');
const dt = <?= json_encode(array_merge($storageData,[['name'=>'剩余','value'=>max(0,$totalGB-$totalUsed),'color'=>'#F0F2F8']])) ?>;
const cx=70,cy=70,ir=44,or=64;let sa=-Math.PI/2;const tot=<?= $totalGB ?>;
dt.forEach(d=>{const a=tot>0?(d.value/tot)*2*Math.PI:0;cx2.beginPath();cx2.arc(cx,cy,or,sa,sa+a);cx2.arc(cx,cy,ir,sa+a,sa,true);cx2.closePath();cx2.fillStyle=d.color;cx2.fill();sa+=a;});
</script>
