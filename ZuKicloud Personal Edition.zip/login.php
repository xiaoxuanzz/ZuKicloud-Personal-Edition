<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';

// Auto-login from remember me cookie
if (!isLogin() && isset($_COOKIE['mycloud_remember'])) {
    list($userId, $token) = explode(':', $_COOKIE['mycloud_remember'], 2);
    $userId = intval($userId);
    if ($userId > 0 && !empty($token)) {
        $hash = hash_hmac('sha256', $token . $userId, 'mycloud_remember');
        $stmt = $pdo->prepare("SELECT id FROM users WHERE id = ? AND remember_token = ?");
        $stmt->execute([$userId, $hash]);
        if ($stmt->fetch()) {
            $_SESSION['uid'] = $userId;
            $_SESSION['login_ip'] = getClientIp();
            $_SESSION['login_time'] = time();
            // Refresh cookie
            setcookie('mycloud_remember', $userId . ':' . $token, time() + 30 * 24 * 3600, '/');
            header('Location: index.php');
            exit;
        } else {
            // Invalid token, clear cookie
            setcookie('mycloud_remember', '', time() - 3600, '/');
        }
    }
}

if (isLogin()) { header('Location: index.php'); exit; }

$error = '';
$ip = getClientIp();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $rl = rateLimit('login:' . $ip, 5, 60, 300);
    if (!$rl['ok']) {
        $error = '登录尝试过于频繁，请等待 ' . $rl['wait'] . ' 秒后重试';
        logSecurityEvent('rate_block', $ip, ['action' => 'login', 'wait' => $rl['wait']]);
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($username) || empty($password)) {
            $error = '用户名/邮箱和密码不能为空';
        } else {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['uid'] = $user['id'];
                $_SESSION['login_ip'] = $ip;
                $_SESSION['login_time'] = time();
                logSecurityEvent('login_success', $ip, ['user_id' => $user['id'], 'username' => $user['username']]);
                // Remember me: set persistent cookie
                if (!empty($_POST['remember'])) {
                    $token = bin2hex(random_bytes(32));
                    $expires = time() + 30 * 24 * 3600; // 30 days
                    $hash = hash_hmac('sha256', $token . $user['id'], 'mycloud_remember');
                    setcookie('mycloud_remember', $user['id'] . ':' . $token, $expires, '/');
                    $pdo->prepare("UPDATE users SET remember_token = ? WHERE id = ?")->execute([$hash, $user['id']]);
                }
                header('Location: index.php');
                exit;
            } else {
                $error = '用户名或密码错误';
                logSecurityEvent('failed_login', $ip, ['username' => $username]);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>登录 - <?= SITE_NAME ?></title>
    <link rel="icon" type="image/svg+xml" href="favicon.svg">
    <link rel="stylesheet" href="assets/css/fontawesome/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <?php include __DIR__ . '/includes/antidebug.php'; ?>
</head>
<body>
<div class="auth-layout">
    <div class="auth-left">
        <div class="circle" style="width:384px;height:384px;top:-160px;left:-160px;"></div>
        <div class="circle" style="width:256px;height:256px;top:-80px;left:-80px;"></div>
        <div class="circle" style="width:480px;height:480px;bottom:0;right:0;transform:translate(33%,33%);"></div>
        <div class="circle" style="width:256px;height:256px;bottom:80px;right:80px;"></div>
        <div style="display:flex;flex-direction:column;align-items:center;gap:40px;z-index:1;">
            <div style="display:flex;flex-direction:column;align-items:center;gap:20px;">
                <div class="brand-logo"><i class="fa fa-cloud"></i></div>
                <h1><?= SITE_NAME ?></h1>
                <p class="slogan">安全存储，随时访问</p>
            </div>
            <div class="features">
                <div class="feature-item">免费存储空间，无容量限制</div>
                <div class="feature-item">上传文件无大小限制</div>
                <div class="feature-item">多端同步访问</div>
            </div>
        </div>
    </div>
    <div class="auth-right">
        <div class="auth-card">
            <div class="mobile-brand">
                <div class="logo-sm"><i class="fa fa-cloud"></i></div>
                <span><?= SITE_NAME ?></span>
            </div>
            <h2>欢迎登录</h2>
            <p class="subtitle">请输入用户名或邮箱继续</p>
            <?php if ($error): ?>
                <div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <form method="POST">
                <?= csrf_field() ?>
                <div class="form-group">
                    <label>用户名 / 邮箱</label>
                    <div class="input-wrap">
                        <i class="fa fa-user"></i>
                        <input type="text" name="username" placeholder="请输入用户名或邮箱" required autofocus value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label>密码</label>
                    <div class="input-wrap">
                        <i class="fa fa-lock"></i>
                        <input type="password" name="password" id="login-pwd" placeholder="请输入密码" required>
                        <button type="button" class="toggle-pwd" onclick="togglePwd('login-pwd',this)"><i class="fa fa-eye"></i></button>
                    </div>
                </div>
                <div class="form-row">
                    <label><input type="checkbox" name="remember" style="accent-color:var(--primary);"> 记住我</label>
                    <a href="forgot.php">忘记密码？</a>
                </div>
                <button type="submit" class="btn-primary" style="margin-top:8px;">登录</button>
            </form>
            <p class="auth-footer">还没有账号？ <a href="register.php">立即注册</a></p>
        </div>
    </div>
</div>
<script>
function togglePwd(id, btn) {
    const input = document.getElementById(id);
    const icon = btn.querySelector('i');
    if (input.type === 'password') { input.type = 'text'; icon.className = 'fa fa-eye-slash'; }
    else { input.type = 'password'; icon.className = 'fa fa-eye'; }
}
</script>
</body>
</html>
