<?php
require_once __DIR__ . '/includes/db.php';

$code = $_GET['code'] ?? '';
if (empty($code)) die('无效链接');

$stmt = $pdo->prepare("SELECT * FROM batch_shares WHERE batch_code = ?");
$stmt->execute([$code]);
$batch = $stmt->fetch();
if (!$batch) die('分享不存在');
if ($batch['expire_time'] && strtotime($batch['expire_time']) < time()) die('分享已过期');

$shareCodes = array_filter(explode(',', $batch['share_codes']));
if (empty($shareCodes)) die('无文件');

$placeholders = implode(',', array_fill(0, count($shareCodes), '?'));
$stmt = $pdo->prepare("SELECT f.name, f.ext, f.hash FROM shares s JOIN files f ON s.file_id = f.id WHERE s.share_code IN ($placeholders) AND f.deleted = 0");
$stmt->execute($shareCodes);
$files = $stmt->fetchAll(PDO::FETCH_ASSOC);
if (empty($files)) die('文件不存在');

require_once __DIR__ . '/includes/auth.php';

$zipName = 'batch_' . date('Ymd_His') . '.zip';
$zipPath = sys_get_temp_dir() . '/' . $zipName;
$zip = new ZipArchive();
if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) die('创建压缩包失败');

foreach ($files as $f) {
    $filepath = UPLOAD_DIR . $f['hash'] . '.' . $f['ext'];
    if (file_exists($filepath)) {
        $name = preg_replace('/[\\\\/:*?"<>|]/', '_', $f['name']);
        $zip->addFile($filepath, $name);
    }
}
$zip->close();

header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="' . $zipName . '"');
header('Content-Length: ' . filesize($zipPath));
readfile($zipPath);
unlink($zipPath);
exit;
