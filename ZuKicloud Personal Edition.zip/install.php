<?php
session_start();
$lockFile = __DIR__ . '/install.lock';
$configFile = __DIR__ . '/config.php';
$configExists = file_exists($configFile);

// 已安装则阻止访问
if (file_exists($lockFile)) {
    ?><!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>已安装 - MyCloud</title><link rel="icon" type="image/svg+xml" href="favicon.svg"><link rel="stylesheet" href="assets/css/style.css">
<style>.install-wrap{min-height:100vh;display:flex;align-items:center;justify-content:center;background:var(--bg);padding:20px}.install-card{background:#fff;border-radius:var(--radius);padding:40px;max-width:480px;width:100%;box-shadow:var(--shadow);text-align:center}</style>
</head><body><div class="install-wrap"><div class="install-card">
<h1 style="font-size:1.5rem;font-weight:700;margin-bottom:12px"><i class="fa fa-cloud" style="color:var(--primary)"></i> MyCloud</h1>
<p style="color:var(--text-sub);font-size:.875rem;margin-bottom:20px">系统已安装，无需重复安装。</p>
<a href="login.php" style="display:inline-block;padding:10px 32px;background:var(--primary);color:#fff;border-radius:var(--radius-sm);text-decoration:none;font-weight:600"><i class="fa fa-sign-in"></i> 前往登录</a>
</div></div></body></html><?php exit;
}

if ($configExists) {
    require_once $configFile;
}

$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;
if (!$configExists && $step === 1) $step = 1;

$messages = [];

// 处理安装提交
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['install'])) {
    $db_host = trim($_POST['db_host'] ?? 'localhost');
    $db_name = trim($_POST['db_name'] ?? 'mycloud');
    $db_user = trim($_POST['db_user'] ?? 'root');
    $db_pass = $_POST['db_pass'] ?? '';
    $db_charset = 'utf8mb4';
    $site_name = trim($_POST['site_name'] ?? 'MyCloud');
    $site_url = trim($_POST['site_url'] ?? '');

    // 自动补全站点 URL
    if (empty($site_url)) {
        $proto = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $site_url = $proto . '://' . $_SERVER['HTTP_HOST'];
    }
    $site_url = rtrim($site_url, '/');

    // 写入 config.php
    $configContent = "<?php
define('DB_HOST', " . var_export($db_host, true) . ");
define('DB_NAME', " . var_export($db_name, true) . ");
define('DB_USER', " . var_export($db_user, true) . ");
define('DB_PASS', " . var_export($db_pass, true) . ");
define('DB_CHARSET', " . var_export($db_charset, true) . ");

define('SITE_NAME', " . var_export($site_name, true) . ");
define('SITE_URL', " . var_export($site_url, true) . ");
define('VERSION', '1.0.0');
define('UPLOAD_DIR', __DIR__ . '/upload/');
define('MAX_FILE_SIZE', 2 * 1024 * 1024 * 1024);

function getStorageLimit() {
    \$bytes = disk_free_space(UPLOAD_DIR);
    return \$bytes ? \$bytes : PHP_INT_MAX;
}
function getStorageTotal() {
    \$bytes = disk_total_space(UPLOAD_DIR);
    return \$bytes ? \$bytes : PHP_INT_MAX;
}
define('RECYCLE_DAYS', 30);

function parse_size(\$size) {
    \$unit = preg_replace('/[^a-zA-Z]/', '', \$size);
    \$size = (int) \$size;
    if (stripos(\$size, 'G') !== false) \$size *= 1024 * 1024 * 1024;
    elseif (stripos(\$size, 'M') !== false) \$size *= 1024 * 1024;
    elseif (stripos(\$size, 'K') !== false) \$size *= 1024;
    return \$size;
}
";

    if (!file_put_contents($configFile, $configContent)) {
        $messages[] = ['type' => 'danger', 'text' => '无法写入 config.php，请检查目录权限'];
    } else {
        require_once $configFile;

        try {
            $pdoInit = new PDO("mysql:host=$db_host;charset=$db_charset", $db_user, $db_pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
            $pdoInit->exec("CREATE DATABASE IF NOT EXISTS `" . $db_name . "` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdoInit = null;

            $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=$db_charset", $db_user, $db_pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

            $pdo->exec("CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50) UNIQUE NOT NULL, email VARCHAR(100) UNIQUE NOT NULL, password VARCHAR(255) NOT NULL, nickname VARCHAR(50) DEFAULT NULL, avatar VARCHAR(255) DEFAULT NULL, created_at DATETIME NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $pdo->exec("CREATE TABLE IF NOT EXISTS files (id INT AUTO_INCREMENT PRIMARY KEY, uid INT NOT NULL, name VARCHAR(255) NOT NULL, ext VARCHAR(20) DEFAULT '', size BIGINT DEFAULT 0, hash VARCHAR(32) NOT NULL, type VARCHAR(20) DEFAULT 'other', is_folder TINYINT DEFAULT 0, parent_id INT DEFAULT 0, downloads INT DEFAULT 0, deleted TINYINT DEFAULT 0, deleted_at DATETIME DEFAULT NULL, added_at DATETIME NOT NULL, INDEX idx_uid (uid), INDEX idx_deleted (deleted)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $pdo->exec("CREATE TABLE IF NOT EXISTS shares (id INT AUTO_INCREMENT PRIMARY KEY, file_id INT NOT NULL, uid INT NOT NULL, share_code VARCHAR(20) UNIQUE NOT NULL, extract_code VARCHAR(10) DEFAULT '', expire_time DATETIME DEFAULT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX idx_share_code (share_code)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $pdo->exec("CREATE TABLE IF NOT EXISTS rate_limits (id INT AUTO_INCREMENT PRIMARY KEY, key_name VARCHAR(128) NOT NULL, attempts INT DEFAULT 1, window_start INT NOT NULL, blocked_until INT DEFAULT 0, UNIQUE KEY uk_key (key_name), KEY idx_blocked (blocked_until)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $pdo->exec("CREATE TABLE IF NOT EXISTS security_events (id INT AUTO_INCREMENT PRIMARY KEY, event_type VARCHAR(50) NOT NULL, ip VARCHAR(45) NOT NULL, details JSON DEFAULT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, KEY idx_type (event_type), KEY idx_ip (ip), KEY idx_created (created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $pdo->exec("CREATE TABLE IF NOT EXISTS batch_shares (id INT AUTO_INCREMENT PRIMARY KEY, uid INT NOT NULL, batch_code VARCHAR(20) UNIQUE NOT NULL, title VARCHAR(255) DEFAULT '', share_codes TEXT NOT NULL, extract_code VARCHAR(10) DEFAULT '', expire_time DATETIME DEFAULT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX idx_batch_code (batch_code)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

            if (!is_dir(__DIR__ . '/upload')) mkdir(__DIR__ . '/upload', 0755, true);
            if (!is_dir(__DIR__ . '/upload/avatars')) mkdir(__DIR__ . '/upload/avatars', 0755, true);

            file_put_contents($lockFile, date('Y-m-d H:i:s'));
            $messages[] = ['type' => 'success', 'text' => '安装成功！'];
        } catch (PDOException $e) {
            $messages[] = ['type' => 'danger', 'text' => '数据库错误：' . $e->getMessage()];
        }
    }
}

// 环境检测
$checks = [];
$checks[] = ['PHP 版本 ≥ 7.4', version_compare(PHP_VERSION, '7.4.0', '>=')];
$checks[] = ['PDO MySQL 扩展', extension_loaded('pdo_mysql')];
$checks[] = ['JSON 扩展', extension_loaded('json')];
$checks[] = ['Session 支持', extension_loaded('session')];
$uploadDir = __DIR__ . '/upload';
$checks[] = ['upload/ 目录可写', is_dir($uploadDir) && is_writable($uploadDir)];
$configWritable = !file_exists($configFile) || is_writable($configFile);
$checks[] = ['config.php 可写', $configWritable];
$allPass = !in_array(false, array_column($checks, 1));

// 数据库连接测试
$dbTestResult = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['test_db'])) {
    $db_host = trim($_POST['db_host'] ?? 'localhost');
    $db_user = trim($_POST['db_user'] ?? 'root');
    $db_pass = $_POST['db_pass'] ?? '';
    $db_name = trim($_POST['db_name'] ?? 'mycloud');
    try {
        $pdoTest = new PDO("mysql:host=$db_host;charset=utf8mb4", $db_user, $db_pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $dbTestResult = ['type' => 'success', 'text' => '连接成功'];
        $pdoTest = null;
    } catch (PDOException $e) {
        $dbTestResult = ['type' => 'danger', 'text' => '连接失败：' . $e->getMessage()];
    }
}

// 读取已有配置用于默认值
$defaults = [
    'db_host' => $configExists ? DB_HOST : 'localhost',
    'db_name' => $configExists ? DB_NAME : 'mycloud',
    'db_user' => $configExists ? DB_USER : 'root',
    'db_pass' => $configExists ? DB_PASS : '',
    'site_name' => $configExists ? SITE_NAME : 'MyCloud',
    'site_url' => $configExists ? SITE_URL : '',
];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>安装向导 - MyCloud</title>
    <link rel="icon" type="image/svg+xml" href="favicon.svg">
    <link rel="stylesheet" href="assets/css/fontawesome/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .install-wrap{min-height:100vh;display:flex;align-items:center;justify-content:center;background:var(--bg);padding:20px}
        .install-card{background:#fff;border-radius:var(--radius);padding:40px;max-width:560px;width:100%;box-shadow:var(--shadow)}
        .install-card h1{font-size:1.5rem;font-weight:700;color:var(--text);margin-bottom:4px;text-align:center}
        .install-card .sub{color:var(--text-sub);text-align:center;margin-bottom:28px;font-size:.875rem}
        .steps{display:flex;justify-content:center;gap:8px;margin-bottom:28px}
        .steps .dot{width:32px;height:4px;border-radius:2px;background:var(--border)}
        .steps .dot.active{background:var(--primary)}
        .steps .dot.done{background:var(--success)}
        .form-group{margin-bottom:16px}
        .form-group label{display:block;font-size:.875rem;font-weight:600;color:var(--text);margin-bottom:6px}
        .form-group input{width:100%;padding:10px 12px;border:1px solid var(--border);border-radius:var(--radius-sm);font-size:.875rem;background:var(--input-bg);color:var(--text);box-sizing:border-box}
        .form-group input:focus{outline:none;border-color:var(--primary)}
        .form-row{display:flex;gap:12px}
        .form-row .form-group{flex:1}
        .check-list{list-style:none;padding:0;margin:0 0 20px}
        .check-list li{display:flex;align-items:center;gap:10px;padding:8px 0;font-size:.875rem;color:var(--text-sub);border-bottom:1px solid var(--border)}
        .check-list li:last-child{border-bottom:none}
        .check-list .fa{font-size:1rem;width:20px;text-align:center}
        .check-list .fa-check-circle{color:var(--success)}
        .check-list .fa-times-circle{color:var(--danger)}
        .btn-row{display:flex;gap:12px;margin-top:24px}
        .btn-row .btn-primary{flex:1}
        .btn-outline{padding:10px 20px;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--input-bg);color:var(--text);font-size:.875rem;cursor:pointer;font-weight:600;text-align:center}
        .btn-outline:hover{border-color:var(--primary);color:var(--primary)}
        .success-icon{font-size:3rem;color:var(--success);text-align:center;margin-bottom:12px}
        .alert{padding:12px 16px;border-radius:var(--radius-sm);font-size:.875rem;margin-bottom:16px;display:flex;align-items:center;gap:8px}
        .alert-success{background:#f0fdf4;color:#166534;border:1px solid #bbf7d0}
        .alert-danger{background:#fef2f2;color:#991b1b;border:1px solid #fecaca}
    </style>
</head>
<body>
<div class="install-wrap">
    <div class="install-card">
        <h1><i class="fa fa-cloud" style="color:var(--primary)"></i> MyCloud</h1>
        <p class="sub">安装向导</p>

        <div class="steps">
            <div class="dot <?= $step >= 1 ? ($step > 1 ? 'done' : 'active') : '' ?>"></div>
            <div class="dot <?= $step >= 2 ? ($step > 2 ? 'done' : 'active') : '' ?>"></div>
            <div class="dot <?= $step >= 3 ? 'done' : '' ?>"></div>
        </div>

        <?php if (!empty($messages)): ?>
            <?php foreach ($messages as $msg): ?>
                <div class="alert alert-<?= $msg['type'] ?>"><i class="fa fa-<?= $msg['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i> <?= htmlspecialchars($msg['text']) ?></div>
            <?php endforeach; ?>
            <?php if ($messages[0]['type'] === 'success'): ?>
                <div class="success-icon"><i class="fa fa-check-circle"></i></div>
                <div style="text-align:center">
                    <p style="color:var(--text-sub);font-size:.875rem;margin-bottom:20px">系统已安装完成，可以开始使用了。</p>
                    <a href="login.php" class="btn-primary" style="display:inline-block;padding:10px 32px;text-decoration:none"><i class="fa fa-sign-in"></i> 前往登录</a>
                </div>
            <?php endif; ?>
        <?php elseif ($step === 1): ?>
            <h3 style="font-size:1rem;font-weight:600;color:var(--text);margin-bottom:12px"><i class="fa fa-cog" style="color:var(--primary)"></i> 环境检测</h3>
            <ul class="check-list">
                <?php foreach ($checks as $check): ?>
                    <li>
                        <i class="fa fa-<?= $check[1] ? 'check-circle' : 'times-circle' ?>"></i>
                        <span><?= $check[0] ?></span>
                        <span style="margin-left:auto;font-size:.75rem;color:<?= $check[1] ? 'var(--success)' : 'var(--danger)' ?>"><?= $check[1] ? '通过' : '未通过' ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
            <?php if ($allPass): ?>
                <a href="?step=2" class="btn-primary" style="display:block;text-align:center;text-decoration:none"><i class="fa fa-arrow-right"></i> 下一步</a>
            <?php else: ?>
                <div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> 请先解决以上环境问题再继续安装</div>
            <?php endif; ?>
        <?php elseif ($step === 2): ?>
            <h3 style="font-size:1rem;font-weight:600;color:var(--text);margin-bottom:16px"><i class="fa fa-database" style="color:var(--primary)"></i> 数据库配置</h3>
            <form method="POST" id="dbForm">
                <div class="form-row">
                    <div class="form-group">
                        <label>数据库主机</label>
                        <input type="text" name="db_host" value="<?= htmlspecialchars($defaults['db_host']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label>数据库名</label>
                        <input type="text" name="db_name" value="<?= htmlspecialchars($defaults['db_name']) ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>用户名</label>
                        <input type="text" name="db_user" value="<?= htmlspecialchars($defaults['db_user']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label>密码</label>
                        <input type="password" name="db_pass" value="<?= htmlspecialchars($defaults['db_pass']) ?>">
                    </div>
                </div>
                <?php if ($dbTestResult): ?>
                    <div class="alert alert-<?= $dbTestResult['type'] ?>"><i class="fa fa-<?= $dbTestResult['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i> <?= htmlspecialchars($dbTestResult['text']) ?></div>
                <?php endif; ?>
                <div class="btn-row">
                    <a href="?step=1" class="btn-outline"><i class="fa fa-arrow-left"></i> 返回</a>
                    <button type="submit" name="test_db" value="1" class="btn-outline"><i class="fa fa-plug"></i> 测试连接</button>
                    <button type="submit" name="skip_test" value="1" class="btn-primary"><i class="fa fa-arrow-right"></i> 下一步</button>
                </div>
            </form>
        <?php elseif ($step === 3): ?>
            <h3 style="font-size:1rem;font-weight:600;color:var(--text);margin-bottom:16px"><i class="fa fa-cog" style="color:var(--primary)"></i> 站点设置</h3>
            <form method="POST">
                <input type="hidden" name="db_host" value="<?= htmlspecialchars($_POST['db_host'] ?? $defaults['db_host']) ?>">
                <input type="hidden" name="db_name" value="<?= htmlspecialchars($_POST['db_name'] ?? $defaults['db_name']) ?>">
                <input type="hidden" name="db_user" value="<?= htmlspecialchars($_POST['db_user'] ?? $defaults['db_user']) ?>">
                <input type="hidden" name="db_pass" value="<?= htmlspecialchars($_POST['db_pass'] ?? $defaults['db_pass']) ?>">
                <div class="form-group">
                    <label>站点名称</label>
                    <input type="text" name="site_name" value="<?= htmlspecialchars($_POST['site_name'] ?? $defaults['site_name']) ?>" required>
                </div>
                <div class="form-group">
                    <label>站点地址 <span style="font-weight:400;color:var(--text-sub)">（留空自动检测）</span></label>
                    <input type="text" name="site_url" value="<?= htmlspecialchars($_POST['site_url'] ?? $defaults['site_url']) ?>" placeholder="例如：https://example.com">
                </div>
                <div class="btn-row">
                    <a href="?step=2" class="btn-outline"><i class="fa fa-arrow-left"></i> 返回</a>
                    <button type="submit" name="install" value="1" class="btn-primary"><i class="fa fa-rocket"></i> 开始安装</button>
                </div>
            </form>
        <?php endif; ?>

    </div>
</div>
</body>
</html>
