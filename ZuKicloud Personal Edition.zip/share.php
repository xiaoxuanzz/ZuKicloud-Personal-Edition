<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';

$code = $_GET['code'] ?? '';
$password_error = false;
$verified = false;
$share = null;

if (empty($code)) {
    die('无效的分享链接');
}

$stmt = $pdo->prepare("SELECT s.*, f.name, f.ext, f.size, f.hash, f.type, f.uid as owner_uid FROM shares s JOIN files f ON s.file_id = f.id WHERE s.share_code = ? AND f.deleted = 0");
$stmt->execute([$code]);
$share = $stmt->fetch();

if (!$share) {
    die('分享链接不存在或文件已被删除');
}

if ($share['expire_time'] && strtotime($share['expire_time']) < time()) {
    die('分享链接已过期');
}

if (!empty($share['extract_code'])) {
    if (isset($_POST['pwd'])) {
        if ($_POST['pwd'] === $share['extract_code']) {
            $verified = true;
            $_SESSION['share_verified_' . $code] = true;
        } else {
            $password_error = true;
        }
    } elseif (isset($_SESSION['share_verified_' . $code])) {
        $verified = true;
    }
} else {
    $verified = true;
}

if ($verified && isset($_GET['download'])) {
    $hash = preg_replace('/[^a-f0-9]/', '', $share['hash']);
    $ext = preg_replace('/[^a-zA-Z0-9]/', '', $share['ext']);
    $filepath = UPLOAD_DIR . $hash . '.' . $ext;
    if (file_exists($filepath)) {
        $pdo->prepare("UPDATE files SET downloads = downloads + 1 WHERE id = ?")->execute([$share['file_id']]);
        $filename = preg_replace('/[^a-zA-Z0-9_\-\.\x80-\xff]/', '_', $share['name']);
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . $share['size']);
        header('Cache-Control: no-cache');
        readfile($filepath);
        exit;
    } else {
        die('文件不存在');
    }
}

$filetype = getFileType($share['ext']);
$file_url = SITE_URL . '/upload/' . $share['hash'] . '.' . $share['ext'];
$download_url = '?' . http_build_query(['code' => $code, 'download' => '1']);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($share['name']) ?> - 分享</title>
    <link rel="icon" type="image/svg+xml" href="favicon.svg">
    <link rel="stylesheet" href="assets/css/fontawesome/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <?php include __DIR__ . '/includes/preview.php'; ?>
    <?php include __DIR__ . '/includes/antidebug.php'; ?>
    <style>
    body{font-family:var(--font);background:var(--bg);height:100vh;overflow:hidden;display:flex;flex-direction:column;}
    .share-header{background:#fff;border-bottom:1px solid var(--border);padding:14px 24px;display:flex;align-items:center;gap:10px;flex-shrink:0;}
    .share-header .logo{width:32px;height:32px;border-radius:12px;background:var(--primary);display:flex;align-items:center;justify-content:center;color:#fff;font-size:16px;}
    .share-header span{font-weight:700;font-size:1rem;color:var(--text);}
    .share-main{flex:1;overflow:hidden;display:flex;flex-direction:column;}
    .share-scroll{flex:1;overflow-y:auto;display:flex;align-items:center;justify-content:center;padding:40px 20px;}
    .pwd-card{background:#fff;border-radius:var(--radius);padding:40px;max-width:420px;width:100%;box-shadow:var(--shadow);text-align:center;}
    .pwd-card .lock-icon{width:64px;height:64px;border-radius:50%;background:var(--primary-bg);display:flex;align-items:center;justify-content:center;margin:0 auto 20px;color:var(--primary);font-size:28px;}
    .pwd-card h2{font-size:1.25rem;font-weight:600;color:var(--text);margin-bottom:8px;}
    .pwd-card p{color:var(--text-dim);font-size:0.875rem;margin-bottom:24px;}
    .pwd-error{color:var(--danger);font-size:0.8125rem;margin-bottom:12px;}
    .preview-card{background:#fff;border-radius:var(--radius);padding:32px;max-width:720px;width:100%;box-shadow:var(--shadow);}
    .preview-header{display:flex;align-items:center;gap:16px;margin-bottom:24px;}
    .preview-icon{width:56px;height:56px;border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:28px;flex-shrink:0;}
    .preview-icon.image{background:#FCE7F3;color:#EC4899;}
    .preview-icon.video{background:#FEF0E7;color:#F97316;}
    .preview-icon.audio{background:#E0F2FE;color:#0EA5E9;}
    .preview-icon.pdf{background:#FEE2E2;color:#EF4444;}
    .preview-icon.doc{background:#EEF1FF;color:#4F6EF7;}
    .preview-icon.archive{background:#FEF3C7;color:#F59E0B;}
    .preview-icon.other{background:#F1F5F9;color:#94A3B8;}
    .preview-info h2{font-size:1.125rem;font-weight:600;color:var(--text);word-break:break-all;}
    .preview-meta{display:flex;gap:16px;margin-top:4px;font-size:0.8125rem;color:var(--text-dim);}
    .preview-meta span{display:flex;align-items:center;gap:4px;}
    .preview-content{margin-bottom:24px;border-radius:12px;overflow:hidden;background:var(--bg);}
    .preview-content img{width:100%;max-height:500px;object-fit:contain;display:block;}
    .preview-content video{width:100%;max-height:500px;display:block;}
    .no-preview{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:48px 20px;text-align:center;}
    .no-preview .big-icon{font-size:64px;color:var(--text-dim);margin-bottom:16px;}
    .download-section{text-align:center;}
    .btn-download{display:inline-flex;align-items:center;gap:8px;padding:12px 32px;border-radius:var(--radius-sm);border:none;background:var(--primary);color:#fff;font-size:1rem;font-weight:600;cursor:pointer;text-decoration:none;box-shadow:0 4px 12px rgba(79,110,247,0.3);transition:all 0.2s;}
    .btn-download:hover{background:var(--primary-dark);transform:translateY(-1px);text-decoration:none;color:#fff;}
    .share-footer{text-align:center;margin-top:16px;font-size:0.75rem;color:var(--text-dim);}
    </style>
</head>
<body>
    <header class="share-header">
        <div class="logo"><i class="fa fa-cloud"></i></div>
        <span><?= SITE_NAME ?></span>
    </header>
    <div class="share-main">
    <div class="share-scroll">
        <?php if (!$verified): ?>
            <div class="pwd-card">
                <div class="lock-icon"><i class="fa fa-lock"></i></div>
                <h2>文件已加密</h2>
                <p>请输入提取码查看文件内容</p>
                <?php if ($password_error): ?>
                    <p class="pwd-error"><i class="fa fa-exclamation-circle"></i> 提取码错误，请重试</p>
                <?php endif; ?>
                <form method="POST">
                    <div class="input-wrap" style="margin-bottom:16px;">
                        <input type="text" name="pwd" placeholder="请输入提取码" maxlength="10" autofocus style="text-align:center;font-size:1.125rem;letter-spacing:0.3em;">
                    </div>
                    <button type="submit" class="btn-primary">验证</button>
                </form>
            </div>
        <?php else: ?>
            <div class="preview-card">
                <div class="preview-header">
                    <div class="preview-icon <?= $filetype ?>"><?= getFileIcon($filetype) ?></div>
                    <div class="preview-info">
                        <h2><?= htmlspecialchars($share['name']) ?></h2>
                        <div class="preview-meta">
                            <span><i class="fa fa-hdd-o"></i> <?= formatSize($share['size']) ?></span>
                            <span><i class="fa fa-clock-o"></i> <?= date('Y-m-d H:i', strtotime($share['created_at'])) ?></span>
                            <?php if ($share['expire_time']): ?>
                                <span><i class="fa fa-calendar"></i> 有效期至 <?= date('Y-m-d', strtotime($share['expire_time'])) ?></span>
                            <?php else: ?>
                                <span><i class="fa fa-infinity"></i> 永久有效</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="preview-content" id="previewBox"></div>
                <div class="download-section">
                    <a href="<?= $download_url ?>" class="btn-download"><i class="fa fa-cloud-download"></i> 下载文件</a>
                    <p class="share-footer">由 <?= SITE_NAME ?> 提供安全分享</p>
                </div>
            </div>
        <?php endif; ?>
    </div>
    </div>
<script>
(function(){
    var box = document.getElementById('previewBox');
    if(box){
        PreviewEngine.preview(
            <?= json_encode($share['file_id'] ?? 0) ?>,
            <?= json_encode($share['name']) ?>,
            <?= json_encode($share['ext']) ?>,
            <?= json_encode($file_url) ?>,
            box
        );
    }
})();
</script>
</body>
</html>
