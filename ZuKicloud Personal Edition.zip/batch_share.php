<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';

$code = $_GET['code'] ?? '';
if (empty($code)) die('无效的分享链接');

$stmt = $pdo->prepare("SELECT * FROM batch_shares WHERE batch_code = ?");
$stmt->execute([$code]);
$batch = $stmt->fetch();

if (!$batch) die('分享链接不存在');

if ($batch['expire_time'] && strtotime($batch['expire_time']) < time()) die('分享链接已过期');

$verified = false;
$password_error = false;

if (!empty($batch['extract_code'])) {
    if (isset($_POST['pwd'])) {
        if ($_POST['pwd'] === $batch['extract_code']) {
            $verified = true;
            $_SESSION['batch_share_verified_' . $code] = true;
        } else {
            $password_error = true;
        }
    } elseif (isset($_SESSION['batch_share_verified_' . $code])) {
        $verified = true;
    }
} else {
    $verified = true;
}

$shareCodes = array_filter(explode(',', $batch['share_codes']));
$shares = [];
if ($verified && !empty($shareCodes)) {
    $placeholders = implode(',', array_fill(0, count($shareCodes), '?'));
    $stmt = $pdo->prepare("SELECT s.*, f.name, f.ext, f.size, f.hash, f.type FROM shares s JOIN files f ON s.file_id = f.id WHERE s.share_code IN ($placeholders) AND f.deleted = 0");
    $stmt->execute($shareCodes);
    $shares = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($batch['title'] ?: '批量分享') ?> - <?= SITE_NAME ?></title>
    <link rel="icon" type="image/svg+xml" href="favicon.svg">
    <link rel="stylesheet" href="assets/css/fontawesome/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <?php include __DIR__ . '/includes/preview.php'; ?>
    <?php include __DIR__ . '/includes/antidebug.php'; ?>
    <style>
    body{font-family:var(--font);background:var(--bg);height:100vh;overflow:hidden;display:flex;flex-direction:column;}
    .share-header{background:#fff;border-bottom:1px solid var(--border);padding:14px 24px;display:flex;align-items:center;gap:10px;flex-shrink:0;}
    .share-header .logo{width:32px;height:32px;border-radius:12px;background:var(--primary);display:flex;align-items:center;justify-content:center;color:#fff;font-size:16px;}
    .share-header span{font-weight:700;font-size:1rem;color:var(--text);}
    .share-main{flex:1;overflow:hidden;display:flex;flex-direction:column;}
    .share-scroll{flex:1;overflow-y:auto;padding:40px 20px;max-width:900px;width:100%;margin:0 auto;box-sizing:border-box;}
    .batch-title{font-size:1.5rem;font-weight:700;color:var(--text);margin-bottom:8px;}
    .batch-meta{font-size:.875rem;color:var(--text-dim);margin-bottom:24px;display:flex;gap:16px;}
    .file-list{display:flex;flex-direction:column;gap:12px;}
    .file-item{background:#fff;border-radius:var(--radius);padding:16px 20px;display:flex;align-items:center;gap:16px;box-shadow:var(--shadow-sm);transition:box-shadow .2s;}
    .file-item:hover{box-shadow:var(--shadow);}
    .file-icon{width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;}
    .file-icon.image{background:#FCE7F3;color:#EC4899;}
    .file-icon.video{background:#FEF0E7;color:#F97316;}
    .file-icon.audio{background:#E0F2FE;color:#0EA5E9;}
    .file-icon.pdf{background:#FEE2E2;color:#EF4444;}
    .file-icon.doc{background:#EEF1FF;color:#4F6EF7;}
    .file-icon.archive{background:#FEF3C7;color:#F59E0B;}
    .file-icon.other{background:#F1F5F9;color:#94A3B8;}
    .file-info{flex:1;min-width:0;}
    .file-name{font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
    .file-size{font-size:.8125rem;color:var(--text-dim);margin-top:2px;}
    .file-actions{display:flex;gap:8px;flex-shrink:0;opacity:1 !important;}
    @media(max-width:600px){
        .file-item{flex-wrap:wrap;}
        .file-actions{width:100%;justify-content:flex-end;margin-top:4px;}
    }
    .btn-sm{padding:8px 16px;border-radius:var(--radius-sm);border:none;font-size:.8125rem;font-weight:500;cursor:pointer;display:inline-flex;align-items:center;gap:6px;text-decoration:none;transition:all .15s;color:#fff;}
    .btn-dl{background:var(--primary);}
    .btn-dl:hover{background:var(--primary-dark);text-decoration:none;}
    .btn-view{background:#6366f1;}
    .btn-view:hover{background:#4f46e5;text-decoration:none;}
    .pwd-card{background:#fff;border-radius:var(--radius);padding:40px;max-width:420px;width:100%;box-shadow:var(--shadow);text-align:center;margin:0 auto;}
    .pwd-card .lock-icon{width:64px;height:64px;border-radius:50%;background:var(--primary-bg);display:flex;align-items:center;justify-content:center;margin:0 auto 20px;color:var(--primary);font-size:28px;}
    .pwd-card h2{font-size:1.25rem;font-weight:600;color:var(--text);margin-bottom:8px;}
    .pwd-card p{color:var(--text-dim);font-size:0.875rem;margin-bottom:24px;}
    .pwd-error{color:var(--danger);font-size:0.8125rem;margin-bottom:12px;}
    .share-footer{text-align:center;margin-top:32px;font-size:.75rem;color:var(--text-dim);}
    /* preview modal */
    .modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:1000;display:none;align-items:center;justify-content:center;}
    .modal-overlay.show{display:flex;}
    .modal-card{background:#fff;border-radius:var(--radius);max-width:min(92vw,860px);max-height:92vh;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,.3);}
    .modal-header{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid var(--border);flex-shrink:0;}
    .modal-header h3{font-size:1rem;font-weight:600;margin:0;}
    .modal-close{background:none;border:none;font-size:18px;cursor:pointer;color:var(--text-dim);padding:4px;}
    #previewContent{text-align:center;overflow:auto;flex:1;min-height:0;width:100%;box-sizing:border-box;}
    </style>
</head>
<body>
    <header class="share-header">
        <div class="logo"><i class="fa fa-cloud"></i></div>
        <span><?= SITE_NAME ?></span>
    </header>
    <div class="share-main">
    <div class="share-scroll">
        <?php if (!$verified): ?>
            <div class="pwd-card">
                <div class="lock-icon"><i class="fa fa-lock"></i></div>
                <h2>分享已加密</h2>
                <p>请输入提取码查看文件内容</p>
                <?php if ($password_error): ?>
                    <p class="pwd-error"><i class="fa fa-exclamation-circle"></i> 提取码错误，请重试</p>
                <?php endif; ?>
                <form method="POST">
                    <div class="input-wrap" style="margin-bottom:16px;">
                        <input type="text" name="pwd" placeholder="请输入提取码" maxlength="10" autofocus style="text-align:center;font-size:1.125rem;letter-spacing:0.3em;">
                    </div>
                    <button type="submit" class="btn-primary">验证</button>
                </form>
            </div>
        <?php else: ?>
            <h1 class="batch-title"><?= htmlspecialchars($batch['title'] ?: count($shares) . ' 个文件') ?></h1>
            <div class="batch-meta">
                <span><i class="fa fa-file-o"></i> <?= count($shares) ?> 个文件</span>
                <span><i class="fa fa-clock-o"></i> <?= date('Y-m-d H:i', strtotime($batch['created_at'])) ?></span>
                <?php if ($batch['expire_time']): ?>
                    <span><i class="fa fa-calendar"></i> 有效期至 <?= date('Y-m-d', strtotime($batch['expire_time'])) ?></span>
                <?php else: ?>
                    <span><i class="fa fa-infinity"></i> 永久有效</span>
                <?php endif; ?>
            </div>
            <div style="margin-bottom:16px;display:flex;gap:8px;">
                <button class="btn-sm btn-dl" onclick="downloadAll()"><i class="fa fa-download"></i> 全部下载</button>
            </div>
            <div class="file-list">
                <?php foreach ($shares as $s):
                    $filetype = getFileType($s['ext']);
                ?>
                <div class="file-item">
                    <div class="file-icon <?= $filetype ?>"><?= getFileIcon($filetype) ?></div>
                    <div class="file-info">
                        <div class="file-name" title="<?= htmlspecialchars($s['name']) ?>"><?= htmlspecialchars($s['name']) ?></div>
                        <div class="file-size"><?= formatSize($s['size']) ?></div>
                    </div>
                    <div class="file-actions">
                        <button class="btn-sm btn-view" onclick="previewShareFile(<?= $s['file_id'] ?>,'<?= htmlspecialchars($s['name']) ?>','<?= $s['ext'] ?>','<?= SITE_URL ?>/upload/<?= $s['hash'] ?>.<?= $s['ext'] ?>')"><i class="fa fa-eye"></i> 预览</button>
                        <a href="share.php?code=<?= $s['share_code'] ?>&download=1" class="btn-sm btn-dl"><i class="fa fa-download"></i> 下载</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <p class="share-footer">由 <?= SITE_NAME ?> 提供安全分享</p>
        <?php endif; ?>
    </div>
    </div>

    <!-- Preview Modal -->
    <div class="modal-overlay" id="previewModal">
        <div class="modal-card" style="max-width:min(92vw,860px);max-height:92vh;display:flex;flex-direction:column;">
            <div class="modal-header" style="flex-shrink:0;">
                <h3 id="previewTitle">文件预览</h3>
                <button class="modal-close" onclick="document.getElementById('previewModal').classList.remove('show')"><i class="fa fa-times"></i></button>
            </div>
            <div id="previewContent" style="text-align:center;overflow:auto;flex:1;min-height:0;width:100%;box-sizing:border-box;"></div>
            <div style="text-align:center;padding:12px 16px;flex-shrink:0;border-top:1px solid var(--border);">
                <a id="previewDownload" href="#" class="btn-sm btn-dl" style="text-decoration:none;"><i class="fa fa-download"></i> 下载文件</a>
            </div>
        </div>
    </div>

<script>
function previewShareFile(id,name,ext,url){
    document.getElementById('previewTitle').textContent=name;
    document.getElementById('previewContent').innerHTML='';
    document.getElementById('previewModal').classList.add('show');
    PreviewEngine.previewModal(id,name,ext,url);
}
function downloadAll(){
    window.location.href='batch_share_download.php?code=<?= htmlspecialchars($code) ?>';
}
function copyShareLink(){
    navigator.clipboard.writeText(window.location.href).catch(function(){
        var t=document.createElement('textarea');t.value=window.location.href;document.body.appendChild(t);t.select();document.execCommand('copy');document.body.removeChild(t);
    });
}
</script>
</body>
</html>
