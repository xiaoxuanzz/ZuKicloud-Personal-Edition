<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';

if (isLogin()) { header('Location: index.php'); exit; }

$error = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm'] ?? '';
    $agree = isset($_POST['agree']);

    if (empty($username) || empty($email) || empty($password)) {
        $error = '请填写所有必填项';
    } elseif (strlen($username) < 3 || strlen($username) > 20) {
        $error = '用户名需要3-20个字符';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = '请输入有效的邮箱地址';
    } elseif (strlen($password) < 8) {
        $error = '密码至少8位字符';
    } elseif ($password !== $confirm) {
        $error = '两次密码不一致';
    } elseif (!$agree) {
        $error = '请同意服务条款和隐私政策';
    } else {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetchColumn() > 0) {
            $error = '该用户名已被注册';
        } else {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetchColumn() > 0) {
                $error = '该邮箱已被注册';
            } else {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO users (username, email, password, created_at) VALUES (?, ?, ?, NOW())");
                $stmt->execute([$username, $email, $hash]);
                $success = true;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>注册 - <?= SITE_NAME ?></title>
    <link rel="icon" type="image/svg+xml" href="favicon.svg">
    <link rel="stylesheet" href="assets/css/fontawesome/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <?php include __DIR__ . '/includes/antidebug.php'; ?>
</head>
<body>
<div class="auth-layout">
    <div class="auth-left">
        <div class="circle" style="width:384px;height:384px;top:-160px;left:-160px;"></div>
        <div class="circle" style="width:256px;height:256px;top:-80px;left:-80px;"></div>
        <div class="circle" style="width:480px;height:480px;bottom:0;right:0;transform:translate(33%,33%);"></div>
        <div class="circle" style="width:256px;height:256px;bottom:80px;right:80px;"></div>
        <div style="display:flex;flex-direction:column;align-items:center;gap:40px;z-index:1;">
            <div style="display:flex;flex-direction:column;align-items:center;gap:20px;">
                <div class="brand-logo"><i class="fa fa-cloud"></i></div>
                <h1><?= SITE_NAME ?></h1>
                <p class="slogan">注册即可开始使用</p>
            </div>
            <div class="features">
                <div class="feature-item">免费存储空间，无容量限制</div>
                <div class="feature-item">上传文件无大小限制</div>
                <div class="feature-item">多端同步访问</div>
            </div>
        </div>
    </div>
    <div class="auth-right" style="overflow:auto;">
        <div class="auth-card" style="padding:16px 0;">
            <div class="mobile-brand">
                <div class="logo-sm"><i class="fa fa-cloud"></i></div>
                <span><?= SITE_NAME ?></span>
            </div>
            <h2>创建账号</h2>
            <p class="subtitle">填写信息，立即开始使用</p>
            <?php if ($success): ?>
                <div class="alert alert-success"><i class="fa fa-check-circle"></i> 注册成功！请<a href="login.php">登录</a></div>
            <?php elseif ($error): ?>
                <div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <form method="POST">
                <div class="form-group"><label>用户名</label><div class="input-wrap"><i class="fa fa-user"></i><input type="text" name="username" placeholder="设置用户名" required maxlength="20" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"></div></div>
                <div class="form-group"><label>邮箱地址</label><div class="input-wrap"><i class="fa fa-envelope-o"></i><input type="email" name="email" placeholder="请输入常用邮箱" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"></div></div>
                <div class="form-group"><label>密码</label><div class="input-wrap"><i class="fa fa-lock"></i><input type="password" name="password" id="reg-pwd" placeholder="设置登录密码" required minlength="8" oninput="checkStrength(this.value)"><button type="button" class="toggle-pwd" onclick="togglePwd('reg-pwd',this)"><i class="fa fa-eye"></i></button></div>
                    <div class="pwd-strength" id="pwd-strength" style="display:none;"><div class="pwd-bar"><div class="bar" id="bar1"></div><div class="bar" id="bar2"></div><div class="bar" id="bar3"></div><div class="bar" id="bar4"></div><span class="pwd-label" id="pwd-level"></span></div><div class="pwd-rules"><span id="r1" class="fail"><i class="fa fa-times"></i> 至少8个字符</span><span id="r2" class="fail"><i class="fa fa-times"></i> 包含数字</span><span id="r3" class="fail"><i class="fa fa-times"></i> 包含字母</span><span id="r4" class="fail"><i class="fa fa-times"></i> 包含特殊符号</span></div></div>
                </div>
                <div class="form-group"><label>确认密码</label><div class="input-wrap"><i class="fa fa-lock"></i><input type="password" name="confirm" id="reg-confirm" placeholder="再次输入密码" required oninput="checkMatch()"><button type="button" class="toggle-pwd" onclick="togglePwd('reg-confirm',this)"><i class="fa fa-eye"></i></button></div>
                    <p id="match-error" style="color:var(--danger);font-size:.75rem;margin-top:4px;display:none;">两次密码不一致</p>
                </div>
                <label style="display:flex;align-items:flex-start;gap:8px;cursor:pointer;margin-bottom:16px;"><input type="checkbox" name="agree" style="accent-color:var(--primary);margin-top:3px;"><span style="color:var(--text-sub);font-size:.8125rem;line-height:1.5;">我已阅读并同意 <a href="#">《服务条款》</a> 和 <a href="#">《隐私政策》</a></span></label>
                <button type="submit" class="btn-primary">注册账号</button>
            </form>
            <p class="auth-footer" style="margin-top:20px;">已有账号？ <a href="login.php">立即登录</a></p>
        </div>
    </div>
</div>
<script>
function togglePwd(id,btn){const i=document.getElementById(id),ic=btn.querySelector('i');if(i.type==='password'){i.type='text';ic.className='fa fa-eye-slash'}else{i.type='password';ic.className='fa fa-eye'}}
function checkStrength(pwd){const el=document.getElementById('pwd-strength');if(!pwd){el.style.display='none';return}el.style.display='block';const r=[pwd.length>=8,/\d/.test(pwd),/[a-zA-Z]/.test(pwd),/[^a-zA-Z0-9]/.test(pwd)];const s=r.filter(Boolean).length;const c=['#EF4444','#F59E0B','#10B981','#4F6EF7'];const l=['弱','一般','良好','强'];for(let i=0;i<4;i++){document.getElementById('bar'+(i+1)).style.background=i<s?c[s-1]:'#E2E8F0';const el=document.getElementById('r'+(i+1));el.className=r[i]?'ok':'fail';el.innerHTML=r[i]?'<i class="fa fa-check"></i>':'<i class="fa fa-times"></i> '+['至少8个字符','包含数字','包含字母','包含特殊符号'][i]}document.getElementById('pwd-level').textContent=l[s-1]||'';document.getElementById('pwd-level').style.color=c[s-1]||'#E2E8F0'}
function checkMatch(){const p=document.getElementById('reg-pwd').value,c=document.getElementById('reg-confirm').value,e=document.getElementById('match-error'),i=document.getElementById('reg-confirm');if(c&&p!==c){e.style.display='block';i.style.borderColor='#EF4444'}else{e.style.display='none';i.style.borderColor=c===p&&c?'#10B981':'#E2E8F0'}}
</script>
</body>
</html>
