<?php
$uid = $_SESSION['uid'];
$folderId = intval($_GET['folder'] ?? 0);

$breadcrumb = [];
if ($folderId > 0) {
    $fid = $folderId;
    while ($fid > 0) {
        $stmt = $pdo->prepare("SELECT id, name, parent_id FROM files WHERE id = ? AND uid = ? AND is_folder = 1");
        $stmt->execute([$fid, $uid]);
        $f = $stmt->fetch();
        if (!$f) break;
        array_unshift($breadcrumb, $f);
        $fid = $f['parent_id'];
    }
}

$stmt = $pdo->prepare("SELECT * FROM files WHERE uid = ? AND parent_id = ? AND deleted = 0 ORDER BY is_folder DESC, name ASC");
$stmt->execute([$uid, $folderId]);
$files = $stmt->fetchAll();
?>

<?php if ($folderId > 0): ?>
<div class="breadcrumb-bar">
    <a href="javascript:void(0)" onclick="navigateFolder(0)" class="bc-link"><i class="fa fa-home"></i> 全部文件</a>
    <?php foreach ($breadcrumb as $bc): ?>
        <span class="bc-sep"><i class="fa fa-chevron-right"></i></span>
        <a href="javascript:void(0)" onclick="navigateFolder(<?= $bc['id'] ?>)" class="bc-link"><?= htmlspecialchars($bc['name']) ?></a>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<div class="content-area" id="fileContent">

<!-- Batch Action Bar -->
<div class="batch-bar" id="batchBar" style="display:none;">
    <span class="sc">已选择 0 个文件</span>
    <button class="btn-restore mobile-only" onclick="selectAllCards()"><i class="fa fa-check-square-o"></i> 全选</button>
    <button class="btn-restore" onclick="batchDownload()"><i class="fa fa-download"></i> 批量下载</button>
    <button class="btn-restore" onclick="batchShare()"><i class="fa fa-share-alt"></i> 批量分享</button>
    <button class="btn-restore" onclick="batchZip()"><i class="fa fa-file-archive-o"></i> 压缩下载</button>
    <button class="btn-del-p" onclick="batchDelete()"><i class="fa fa-trash"></i> 批量删除</button>
    <button class="btn-cancel" onclick="clearSelection()" style="border:1px solid var(--border);background:#fff;color:var(--text-sub);">取消选择</button>
</div>

<?php if (empty($files)): ?>
    <div class="empty-state">
        <i class="fa fa-inbox"></i>
        <p>这个文件夹是空的</p>
        <p style="margin-top:8px;font-size:.8125rem;">拖拽文件到此处或点击右下角上传</p>
    </div>
<?php else: ?>
    <div class="file-grid">
    <?php foreach ($files as $f): ?>
        <div class="file-card" data-id="<?= $f['id'] ?>" data-name="<?= htmlspecialchars($f['name']) ?>" data-ext="<?= $f['ext'] ?>" data-hash="<?= $f['hash'] ?>" data-type="<?= $f['is_folder']?'folder':'file' ?>" data-size="<?= $f['size'] ?>"
             <?= $f['is_folder'] ? "ondblclick=\"navigateFolder({$f['id']})\"" : "" ?>>
            <div class="card-select"><input type="checkbox" class="file-cb" value="<?= $f['id'] ?>" style="accent-color:var(--primary)"></div>
            <div class="thumb <?= $f['type'] ?>">
                <?php if ($f['is_folder']): ?>
                    <i class="fa fa-folder"></i>
                <?php else: ?>
                    <?= getFileIcon($f['type']) ?>
                <?php endif; ?>
            </div>
            <div class="card-meta">
                <p class="card-name" title="<?= htmlspecialchars($f['name']) ?>"><?= htmlspecialchars($f['name']) ?></p>
                <p class="card-size"><?= $f['is_folder'] ? '文件夹' : formatSize($f['size']) ?></p>
            </div>
        </div>
    <?php endforeach; ?>
    </div>
<?php endif; ?>
</div>

<!-- Context Menu -->
<div class="ctx-menu" id="ctxMenu">
    <div class="ctx-item" id="ctxOpen" onclick="ctxOpenItem()" style="display:none"><i class="fa fa-folder-open"></i> 打开</div>
    <div class="ctx-item" id="ctxPreview" onclick="ctxPreviewFile()" style="display:none"><i class="fa fa-eye"></i> 预览</div>
    <div class="ctx-item" id="ctxDownload" onclick="ctxDownloadFile()" style="display:none"><i class="fa fa-download"></i> 下载</div>
    <div class="ctx-item" id="ctxShare" onclick="ctxShareFile()" style="display:none"><i class="fa fa-share-alt"></i> 分享</div>
    <div class="ctx-sep"></div>
    <div class="ctx-item" onclick="showCreateFolder()"><i class="fa fa-folder-plus"></i> 新建文件夹</div>
    <div class="ctx-item" onclick="triggerUpload()"><i class="fa fa-cloud-upload"></i> 上传文件</div>
    <div class="ctx-sep"></div>
    <div class="ctx-item" id="ctxRename" onclick="ctxRenameFile()" style="display:none"><i class="fa fa-pencil"></i> 重命名</div>
    <div class="ctx-item" id="ctxDelete" onclick="ctxDeleteFile()" style="display:none;color:var(--danger)"><i class="fa fa-trash"></i> 删除</div>
</div>

<!-- Preview Modal -->
<div class="modal-overlay" id="previewModal">
    <div class="modal-card" style="max-width:min(92vw,860px);max-height:92vh;display:flex;flex-direction:column;">
        <div class="modal-header" style="flex-shrink:0;">
            <h3 id="previewTitle">文件预览</h3>
            <div style="display:flex;align-items:center;gap:6px;">
                <button class="modal-zoom-btn" onclick="PreviewEngine.toggleFullscreen()" title="全屏"><i class="fa fa-arrows-alt"></i></button>
                <button class="modal-close" onclick="closePreview()"><i class="fa fa-times"></i></button>
            </div>
        </div>
        <div id="previewContent" style="text-align:center;overflow:auto;flex:1;min-height:0;width:100%;box-sizing:border-box;"></div>
        <div style="text-align:center;padding:12px 16px;flex-shrink:0;border-top:1px solid var(--border);">
            <a id="previewDownload" href="#" class="btn-gen" style="display:inline-flex;align-items:center;gap:6px;text-decoration:none;"><i class="fa fa-download"></i> 下载文件</a>
        </div>
    </div>
</div>

<!-- Share Modal -->
<div class="modal-overlay" id="shareModal">
    <div class="modal-card">
        <div class="modal-header">
            <h3>分享文件</h3>
            <button class="modal-close" onclick="closeShare()"><i class="fa fa-times"></i></button>
        </div>
        <div class="share-file-preview">
            <div class="preview-icon"><i class="fa fa-file-text-o"></i></div>
            <div><p class="preview-name" id="shareFileName"></p><p class="preview-size" id="shareFileSize"></p></div>
        </div>
        <div class="share-option">
            <label>有效期</label>
            <select id="shareExpiry">
                <option value="0">永久有效</option>
                <option value="1">1 天</option>
                <option value="7" selected>7 天</option>
                <option value="30">30 天</option>
            </select>
        </div>
        <div class="share-option">
            <label>提取码</label>
            <div class="toggle-switch" id="codeToggle" onclick="this.classList.toggle('active')"><div class="toggle-knob"></div></div>
        </div>
        <div class="extract-code-box" style="display:none;margin-bottom:16px;" id="codeBox">
            <span>提取码：</span><code id="extractCode">----</code>
        </div>
        <div id="shareLinkBox" style="display:none;margin-bottom:16px;">
            <div style="display:flex;gap:8px;">
                <input type="text" id="shareLinkInput" readonly style="flex:1;padding:8px 12px;border:1px solid var(--border);border-radius:8px;font-size:.8125rem;">
                <button class="btn-copy btn-gen" onclick="copyLink()"><i class="fa fa-copy"></i> 复制</button>
            </div>
        </div>
        <button class="btn-gen" style="width:100%" onclick="window._batchShareIds?batchGenerateShare():generateShare()">生成链接</button>
    </div>
</div>

<!-- Create Folder Modal -->
<div class="modal-overlay" id="folderModal">
    <div class="modal-card" style="max-width:380px">
        <div class="modal-header">
            <h3>新建文件夹</h3>
            <button class="modal-close" onclick="closeFolderModal()"><i class="fa fa-times"></i></button>
        </div>
        <div class="form-group">
            <label>文件夹名称</label>
            <div class="input-wrap">
                <i class="fa fa-folder"></i>
                <input type="text" id="folderNameInput" placeholder="请输入文件夹名称" maxlength="100">
            </div>
        </div>
        <div style="display:flex;gap:12px;margin-top:20px;">
            <button class="btn-gen" style="flex:1" onclick="submitCreateFolder()">创建</button>
            <button class="btn-cancel" style="flex:1" onclick="closeFolderModal()">取消</button>
        </div>
    </div>
</div>

<script>
let currentFolderId = <?= $folderId ?>;
let currentView = 'grid';
const csrfToken = '<?= csrf_token() ?>';

function navigateFolder(id) {
    currentFolderId = id;
    clearSelection();
    if (id == 0) {
        document.querySelector('.topbar h2').innerHTML = '<i class="fa fa-files-o" style="color:var(--primary);font-size:1.1rem;"></i> 全部文件';
    }
    const baseUrl = 'index.php?page=files&view=grid';
    const fetchUrl = baseUrl + '&folder=' + id + '&ajax=content';
    const pushUrl = id == 0 ? baseUrl : baseUrl + '&folder=' + id;
    fetch(fetchUrl, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
        .then(r => r.text())
        .then(html => {
            var tmp = document.createElement('div');
            tmp.innerHTML = html;
            var newContent = tmp.querySelector('.content-area');
            var oldContent = document.querySelector('.content-area');
            if (!oldContent) return;
            document.querySelectorAll('.breadcrumb-bar').forEach(function(el){ el.remove(); });
            if (newContent) {
                oldContent.innerHTML = newContent.innerHTML;
            }
            var newBc = tmp.querySelector('.breadcrumb-bar');
            if (newBc) {
                oldContent.parentNode.insertBefore(newBc, oldContent);
                var parts = newBc.innerHTML.split('bc-link');
                var lastPart = parts[parts.length - 1];
                var match = lastPart.match(/>([^<]+)</);
                if (match) document.querySelector('.topbar h2').innerHTML = '<i class="fa fa-folder-open-o" style="color:var(--primary);font-size:1.1rem;"></i> ' + match[1];
            }
            rebindCardClicks();
            history.pushState({}, '', pushUrl);
        });
}

function rebindCardClicks(){
    document.querySelectorAll('.file-card').forEach(function(card){
        card.removeEventListener('dblclick',card._dblHandler);
        card._dblHandler=function(){
            if(card.getAttribute('data-type')==='folder')navigateFolder(parseInt(card.getAttribute('data-id')));
        };
        card.addEventListener('dblclick',card._dblHandler);
    });
    document.querySelectorAll('.file-cb').forEach(function(cb){
        cb.removeEventListener('change',cb._handler);
        cb._handler=function(e){
            e.stopPropagation();
            cb.closest('.file-card').classList.toggle('selected',cb.checked);
            updateBatchBar();
        };
        cb.addEventListener('change',cb._handler);
        cb.removeEventListener('click',cb._clickStop);
        cb._clickStop=function(e){e.stopPropagation();};
        cb.addEventListener('click',cb._clickStop);
    });
}

// Context menu
var ctxFileId=0,ctxFileName='',ctxFileExt='',ctxFileHash='',ctxFileType='';
function ctxOpenItem(){if(ctxFileType==='folder')navigateFolder(ctxFileId);}
function ctxPreviewFile(){previewFile(ctxFileId,ctxFileName,ctxFileExt,ctxFileHash);}
function ctxDownloadFile(){window.location='download.php?id='+ctxFileId;}
function ctxShareFile(){openShare(ctxFileId,ctxFileName,0);}
function ctxRenameFile(){renameItem(ctxFileId,ctxFileName);}
function ctxDeleteFile(){deleteItem(ctxFileId,ctxFileName);}

function previewFile(id,name,ext,hash){
    var url='upload/'+hash+'.'+ext;
    PreviewEngine.previewModal(id,name,ext,url);
}
function closePreview(){document.getElementById('previewModal').classList.remove('show');}

function deleteItem(id,name){
    if(!confirm('确定删除「'+name+'」？'))return;
    fetch('index.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'action=delete&id='+id+'&csrf_token='+csrfToken
    }).then(r=>r.json()).then(d=>{if(d.ok)navigateFolder(currentFolderId);});
}
function renameItem(id,oldName){
    var newName=prompt('重命名',oldName);
    if(!newName||newName===oldName)return;
    fetch('index.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'action=rename&id='+id+'&name='+encodeURIComponent(newName)+'&csrf_token='+csrfToken
    }).then(r=>r.json()).then(d=>{if(d.ok)navigateFolder(currentFolderId);});
}
function openShare(id,name,size){
    document.getElementById('shareFileName').textContent=name;
    document.getElementById('shareFileSize').textContent=fmtSize(size);
    document.getElementById('shareModal').classList.add('show');
    document.getElementById('shareLinkBox').style.display='none';
    window._shareFileId=id;
}
function closeShare(){document.getElementById('shareModal').classList.remove('show');}
function generateShare(){
    var expiry=document.getElementById('shareExpiry').value;
    var hasCode=document.getElementById('codeToggle').classList.contains('active');
    var fd=new FormData();
    fd.append('action','create_share');fd.append('file_id',window._shareFileId);
    fd.append('expiry',expiry);if(hasCode)fd.append('has_code','1');
    fd.append('csrf_token',csrfToken);
    fetch('index.php',{method:'POST',body:fd}).then(r=>r.json()).then(data=>{
        if(data.success){document.getElementById('shareLinkInput').value=data.url;document.getElementById('shareLinkBox').style.display='flex';if(data.code)document.getElementById('extractCode').textContent=data.code;}
    });
}
function copyLink(){
    var i=document.getElementById('shareLinkInput');
    navigator.clipboard.writeText(i.value).catch(()=>{i.select();document.execCommand('copy')});
    var b=document.querySelector('.btn-copy');b.innerHTML='<i class="fa fa-check"></i> 已复制';
    setTimeout(()=>{b.innerHTML='<i class="fa fa-copy"></i> 复制';},2000);
}

// Context menu - desktop right-click + mobile long press
(function(){
    const menu = document.getElementById('ctxMenu');
    let longTimer=null,longTriggered=false;
    function showCtx(x,y){
        var vw=window.innerWidth,vh=window.innerHeight;
        menu.style.left='0';menu.style.top='0';
        menu.classList.add('show');
        var mw=menu.offsetWidth,mh=menu.offsetHeight;
        var mx=x,my=y;
        if(mx+mw>vw-8) mx=vw-mw-8;
        if(my+mh>vh-8) my=vh-mh-8;
        if(mx<8) mx=8;
        if(my<8) my=8;
        menu.style.left=mx+'px';
        menu.style.top=my+'px';
    }
    function hideCtx(){menu.classList.remove('show')}

    document.querySelectorAll('.file-card').forEach(function(card){
        card.addEventListener('contextmenu',function(e){
            e.preventDefault();e.stopPropagation();
            var id=card.getAttribute('data-id');
            var name=card.getAttribute('data-name');
            var ext=card.getAttribute('data-ext');
            var hash=card.getAttribute('data-hash');
            var type=card.getAttribute('data-type');
            var isFolder=type==='folder';
            ctxFileId=id;ctxFileName=name;ctxFileExt=ext;ctxFileHash=hash;ctxFileType=type;
            document.getElementById('ctxOpen').style.display=isFolder?'block':'none';
            document.getElementById('ctxPreview').style.display=isFolder?'none':'block';
            document.getElementById('ctxDownload').style.display=isFolder?'none':'block';
            document.getElementById('ctxShare').style.display=isFolder?'none':'block';
            document.getElementById('ctxRename').style.display='block';
            document.getElementById('ctxDelete').style.display='block';
            showCtx(e.pageX,e.pageY);
        });
        card.addEventListener('touchstart',function(e){
            if(e.touches.length===1){
                longTriggered=false;
                var t=e.touches[0];
                longTimer=setTimeout(function(){
                    longTriggered=true;
                    e.preventDefault();
                    var id=card.getAttribute('data-id');
                    var name=card.getAttribute('data-name');
                    var ext=card.getAttribute('data-ext');
                    var hash=card.getAttribute('data-hash');
                    var type=card.getAttribute('data-type');
                    var isFolder=type==='folder';
                    ctxFileId=id;ctxFileName=name;ctxFileExt=ext;ctxFileHash=hash;ctxFileType=type;
                    document.getElementById('ctxOpen').style.display=isFolder?'block':'none';
                    document.getElementById('ctxPreview').style.display=isFolder?'none':'block';
                    document.getElementById('ctxDownload').style.display=isFolder?'none':'block';
                    document.getElementById('ctxShare').style.display=isFolder?'none':'block';
                    document.getElementById('ctxRename').style.display='block';
                    document.getElementById('ctxDelete').style.display='block';
                    showCtx(t.pageX,t.pageY);
                    if(navigator.vibrate)navigator.vibrate(30);
                },500);
            }
        },{passive:false});
        card.addEventListener('touchmove',function(){clearTimeout(longTimer)},{passive:true});
        card.addEventListener('touchend',function(){clearTimeout(longTimer)});
    });

    // Right-click on empty content area
    var contentArea=document.querySelector('.content-area');
    if(contentArea){
        contentArea.addEventListener('contextmenu',function(e){
            if(e.target.closest('.file-card')||e.target.closest('.ctx-menu')||e.target.closest('button')||e.target.closest('a')||e.target.closest('input'))return;
            e.preventDefault();e.stopPropagation();
            ctxFileId=0;ctxFileName='';ctxFileExt='';ctxFileHash='';ctxFileType='';
            document.getElementById('ctxOpen').style.display='none';
            document.getElementById('ctxPreview').style.display='none';
            document.getElementById('ctxDownload').style.display='none';
            document.getElementById('ctxShare').style.display='none';
            document.getElementById('ctxRename').style.display='none';
            document.getElementById('ctxDelete').style.display='none';
            showCtx(e.pageX,e.pageY);
        });
    }

    menu.addEventListener('click',function(e){
        if(e.target.closest('.ctx-item'))hideCtx();
    });
    document.addEventListener('click',function(e){if(!menu.contains(e.target))hideCtx()});
    document.addEventListener('touchstart',function(e){if(!menu.contains(e.target)&&!longTriggered)hideCtx();longTriggered=false},{passive:true});
})();

function showCreateFolder(){document.getElementById('folderModal').classList.add('show');setTimeout(()=>document.getElementById('folderNameInput').focus(),100);}
function closeFolderModal(){document.getElementById('folderModal').classList.remove('show');document.getElementById('folderNameInput').value='';}
function submitCreateFolder(){
    var name=document.getElementById('folderNameInput').value.trim();
    if(!name)return;
    fetch('index.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'action=create_folder&name='+encodeURIComponent(name)+'&parent_id='+currentFolderId+'&csrf_token='+csrfToken
    }).then(r=>r.json()).then(d=>{if(d.ok){closeFolderModal();navigateFolder(currentFolderId);}else alert(d.msg||'创建失败');});
}
function triggerUpload(){window.location='index.php?page=upload';}
function fmtSize(b){if(b>=1073741824)return(b/1073741824).toFixed(1)+' GB';if(b>=1048576)return(b/1048576).toFixed(1)+' MB';return(b/1024).toFixed(1)+' KB';}

// ===== Drag-to-select (Windows-style rubber band) =====
(function(){
    var contentArea = document.querySelector('.content-area');
    if(!contentArea) return;
    var band = document.createElement('div');
    band.className = 'select-band';
    band.style.cssText = 'position:fixed;border:2px solid var(--primary);background:rgba(79,110,247,.08);border-radius:3px;pointer-events:none;z-index:998;display:none;';
    document.body.appendChild(band);
    var startX=0,startY=0,isDragging=false;

    contentArea.addEventListener('mousedown',function(e){
        if(e.target.closest('button')||e.target.closest('a')||e.target.closest('input')||e.target.closest('.ctx-menu'))return;
        if(e.button!==0)return;
        if(e.dataTransfer&&e.dataTransfer.types&&e.dataTransfer.types.indexOf('Files')!==-1)return;
        startX=e.clientX; startY=e.clientY;
        isDragging=false;
        band.style.display='none';
        document.addEventListener('mousemove',onMove);
        document.addEventListener('mouseup',onUp);
    });

    function onMove(e){
        var dx=e.clientX-startX, dy=e.clientY-startY;
        if(!isDragging&&(Math.abs(dx)>4||Math.abs(dy)>4)){
            isDragging=true;
            document.body.classList.add('dragging-select');
        }
        if(!isDragging)return;
        e.preventDefault();
        var x=Math.min(startX,e.clientX), y=Math.min(startY,e.clientY);
        var w=Math.abs(dx), h=Math.abs(dy);
        band.style.left=x+'px'; band.style.top=y+'px';
        band.style.width=w+'px'; band.style.height=h+'px';
        band.style.display='block';
        var cards=document.querySelectorAll('.file-card');
        cards.forEach(function(card){
            var r=card.getBoundingClientRect();
            var hit=!(r.right<x||r.left>x+w||r.bottom<y||r.top>y+h);
            var cb=card.querySelector('.file-cb');
            if(cb){cb.checked=hit;card.classList.toggle('selected',hit);}
        });
        updateBatchBar();
    }

    function onUp(){
        document.removeEventListener('mousemove',onMove);
        document.removeEventListener('mouseup',onUp);
        document.body.classList.remove('dragging-select');
        band.style.display='none';
        isDragging=false;
        updateBatchBar();
    }
})();

function updateBatchBar(){
    var checked=document.querySelectorAll('.file-cb:checked');
    var bar=document.getElementById('batchBar');
    var fab=document.getElementById('fabContainer');
    if(!bar)return;
    if(checked.length>=2){
        bar.style.display='flex';
        var cnt=bar.querySelector('.sc');
        if(cnt)cnt.textContent='已选择 '+checked.length+' 个文件';
        if(fab)fab.classList.add('batch-active');
    }else{
        bar.style.display='none';
        if(fab)fab.classList.remove('batch-active');
    }
}

function clearSelection(){
    document.querySelectorAll('.file-cb').forEach(function(c){c.checked=false;c.closest('.file-card').classList.remove('selected');});
    var bar=document.getElementById('batchBar');
    if(bar)bar.style.display='none';
    var fab=document.getElementById('fabContainer');
    if(fab)fab.classList.remove('batch-active');
}

function selectAllCards(){
    var all=document.querySelectorAll('.file-cb');
    var allChecked=all.length>0&&Array.prototype.every.call(all,function(c){return c.checked;});
    all.forEach(function(c){c.checked=!allChecked;c.closest('.file-card').classList.toggle('selected',c.checked);});
    updateBatchBar();
}

// Toggle card selection on checkbox change (event delegation)
document.getElementById('fileContent').addEventListener('change',function(e){
    if(e.target.classList.contains('file-cb')){
        e.target.closest('.file-card').classList.toggle('selected',e.target.checked);
        updateBatchBar();
    }
});

// Click on card to toggle selection (event delegation)
document.getElementById('fileContent').addEventListener('click',function(e){
    if(e.target.closest('.file-cb')||e.target.closest('button')||e.target.closest('a'))return;
    var card=e.target.closest('.file-card');
    if(!card)return;
    var cb=card.querySelector('.file-cb');
    if(cb){
        cb.checked=!cb.checked;
        card.classList.toggle('selected',cb.checked);
        updateBatchBar();
    }
});

function batchDownload(){
    document.querySelectorAll('.file-cb:checked').forEach(function(cb){
        var a=document.createElement('a');
        a.href='download.php?id='+cb.value;a.download='';
        document.body.appendChild(a);a.click();a.remove();
    });
}
function batchZip(){
    var checked=document.querySelectorAll('.file-cb:checked');
    if(!checked.length)return;
    var ids=[];
    checked.forEach(function(cb){
        var card=cb.closest('.file-card');
        if(card&&card.getAttribute('data-type')!=='folder')ids.push(cb.value);
    });
    if(!ids.length){alert('请选择文件进行压缩（文件夹不支持）');return;}
    var fd=new FormData();
    fd.append('action','batch_zip');
    fd.append('ids',ids.join(','));
    fd.append('csrf_token',csrfToken);
    showToast('正在压缩文件...','info');
    fetch('index.php',{method:'POST',body:fd}).then(function(r){
        if(!r.ok)return r.json().then(function(d){throw new Error(d.error||'压缩失败');});
        return r.blob();
    }).then(function(blob){
        var a=document.createElement('a');
        a.href=URL.createObjectURL(blob);
        a.download='batch_'+new Date().toISOString().slice(0,10).replace(/-/g,'')+'.zip';
        document.body.appendChild(a);a.click();a.remove();
        URL.revokeObjectURL(a.href);
        showToast('压缩完成，已开始下载','success');
    }).catch(function(e){showToast(e.message||'压缩失败','error');});
}
function batchDelete(){
    var checked=document.querySelectorAll('.file-cb:checked');
    if(!checked.length)return;
    if(!confirm('确定删除选中的 '+checked.length+' 个文件？'))return;
    var ids=[];
    checked.forEach(function(cb){ids.push(cb.value);});
    fetch('index.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'action=batch_delete&ids='+encodeURIComponent(ids.join(','))+'&csrf_token='+csrfToken
    }).then(r=>r.json()).then(function(d){
        if(d.ok)navigateFolder(currentFolderId);
    });
}
function batchShare(){
    var checked=document.querySelectorAll('.file-cb:checked');
    if(!checked.length)return;
    var ids=[];
    checked.forEach(function(cb){
        var card=cb.closest('.file-card');
        if(!card)return;
        var type=card.getAttribute('data-type');
        if(type!=='folder')ids.push(cb.value);
    });
    if(!ids.length){alert('请选择文件进行分享（文件夹不支持分享）');return;}
    if(ids.length===1){
        var card=document.querySelector('.file-cb[value="'+ids[0]+'"]').closest('.file-card');
        openShare(ids[0],card.getAttribute('data-name'),parseInt(card.getAttribute('data-size')||0));
    }else{
        openBatchShare(ids);
    }
}

function openBatchShare(ids){
    window._batchShareIds=ids;
    document.getElementById('shareFileName').textContent='批量分享 ('+ids.length+' 个文件)';
    document.getElementById('shareFileSize').textContent='';
    document.getElementById('shareModal').classList.add('show');
    document.getElementById('shareLinkBox').style.display='none';
}

function batchGenerateShare(){
    var ids=window._batchShareIds;
    if(!ids||!ids.length)return;
    var expiry=document.getElementById('shareExpiry').value;
    var hasCode=document.getElementById('codeToggle').classList.contains('active');
    var links=[];
    var idx=0;
    function next(){
        if(idx>=ids.length){
            document.getElementById('shareLinkInput').value=links.join('\n');
            document.getElementById('shareLinkBox').style.display='flex';
            window._batchShareIds=null;
            return;
        }
        var fd='action=create_share&file_id='+encodeURIComponent(ids[idx])+'&expiry='+expiry+'&csrf_token='+encodeURIComponent(csrfToken);
        if(hasCode)fd+='&has_code=1';
        var xhr=new XMLHttpRequest();
        xhr.open('POST','index.php',true);
        xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        xhr.onload=function(){
            try{
                var data=JSON.parse(xhr.responseText);
                if(data.success)links.push(data.url);
            }catch(e){}
            idx++;
            next();
        };
        xhr.onerror=function(){idx++;next();};
        xhr.send(fd);
    }
    next();
}
</script>
