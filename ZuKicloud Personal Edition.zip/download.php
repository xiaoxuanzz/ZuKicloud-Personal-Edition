<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';

$id = intval($_GET['id'] ?? 0);
if ($id <= 0) { http_response_code(400); die('无效请求'); }

// Check if this is a share download (no login required)
$share_code = $_GET['code'] ?? null;
if ($share_code) {
    $stmt = $pdo->prepare("SELECT s.*, f.name, f.ext, f.size, f.hash, f.uid FROM shares s JOIN files f ON s.file_id = f.id WHERE s.share_code = ? AND f.deleted = 0");
    $stmt->execute([$share_code]);
    $share = $stmt->fetch();
    if (!$share || $share['file_id'] != $id) { http_response_code(404); die('文件不存在'); }
    if ($share['expire_time'] && strtotime($share['expire_time']) < time()) { http_response_code(410); die('分享已过期'); }
    if (!empty($share['extract_code'])) {
        $verified = isset($_SESSION['share_verified_' . $share_code]);
        if (!$verified) { http_response_code(403); die('请先验证提取码'); }
    }
} else {
    // Login required for direct download
    requireLogin();
    $stmt = $pdo->prepare("SELECT * FROM files WHERE id = ? AND uid = ? AND deleted = 0 AND is_folder = 0");
    $stmt->execute([$id, $_SESSION['uid']]);
    $file = $stmt->fetch();
    if (!$file) { http_response_code(404); die('文件不存在'); }
    $share = $file;
}

// Sanitize hash to prevent path traversal
$hash = preg_replace('/[^a-f0-9]/', '', $share['hash']);
$ext = preg_replace('/[^a-zA-Z0-9]/', '', $share['ext']);
$filepath = UPLOAD_DIR . $hash . '.' . $ext;

if (!file_exists($filepath) || !is_file($filepath)) {
    http_response_code(404); die('文件不存在');
}

// Validate real path is within upload directory
$realpath = realpath($filepath);
$uploadRealpath = realpath(UPLOAD_DIR);
if ($realpath === false || strpos($realpath, $uploadRealpath) !== 0) {
    http_response_code(403); die('非法访问');
}

// Update download count
$pdo->prepare("UPDATE files SET downloads = downloads + 1 WHERE id = ?")->execute([$share['file_id'] ?? $id]);

// Security headers
$filename = preg_replace('/[^a-zA-Z0-9_\-\.\x80-\xff]/', '_', $share['name']);
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . $share['size']);
header('Cache-Control: no-cache, no-store, must-revalidate');
header('X-Content-Type-Options: nosniff');
header('Content-Security-Policy: default-src \'none\'');

// Rate limit download
$dl_ip = getClientIp();
rateLimit('dl:' . $dl_ip, 30, 60, 120);

readfile($filepath);
exit;
