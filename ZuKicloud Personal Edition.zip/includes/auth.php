<?php
require_once __DIR__ . '/db.php';

// ===== Global Crawler Detection =====
function detectCrawler() {
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $patterns = ['bot','spider','crawler','curl','wget','python-requests','scrapy','headless','phantom','selenium','puppeteer','httpclient','go-http-client'];
    foreach ($patterns as $p) {
        if (stripos($ua, $p) !== false) {
            logSecurityEvent('crawler_detected', getClientIp(), ['ua' => mb_substr($ua, 0, 200), 'pattern' => $p]);
            return true;
        }
    }
    return false;
}

// Auto-detect on every request
if (!isset($GLOBALS['_crawler_checked'])) {
    $GLOBALS['_crawler_checked'] = true;
    detectCrawler();
}

// ===== Rate Limiter =====
function rateLimit($key, $max = 10, $window = 60, $block = 300) {
    global $pdo;
    $now = time();
    $ip = getClientIp();

    $stmt = $pdo->prepare("INSERT INTO rate_limits (key_name, attempts, window_start, blocked_until) VALUES (?, 1, ?, 0) ON DUPLICATE KEY UPDATE attempts = IF(blocked_until > ?, attempts, IF(? - window_start > ?, 1, attempts + 1)), window_start = IF(blocked_until > ?, window_start, IF(? - window_start > ?, ?, window_start)), blocked_until = IF(blocked_until > ?, blocked_until, 0)");
    $stmt->execute([$key, $now, $now, $now, $window, $now, $now, $window, $now, $now]);

    $stmt = $pdo->prepare("SELECT attempts, blocked_until FROM rate_limits WHERE key_name = ?");
    $stmt->execute([$key]);
    $r = $stmt->fetch();

    if ($r['blocked_until'] > $now) {
        return ['ok' => false, 'wait' => $r['blocked_until'] - $now];
    }
    if ($r['attempts'] > $max) {
        $bu = $now + $block;
        $pdo->prepare("UPDATE rate_limits SET blocked_until = ? WHERE key_name = ?")->execute([$bu, $key]);
        logSecurityEvent('rate_block', $ip, ['key' => $key]);
        return ['ok' => false, 'wait' => $block];
    }
    return ['ok' => true, 'left' => $max - $r['attempts']];
}

// ===== Security Event Logging =====
function logSecurityEvent($type, $ip, $details = []) {
    global $pdo;
    try {
        $pdo->prepare("INSERT INTO security_events (event_type, ip, details) VALUES (?, ?, ?)")
            ->execute([$type, $ip, json_encode($details, JSON_UNESCAPED_UNICODE)]);
    } catch (Exception $e) {}
}

// ===== IP Detection =====
function getClientIp() {
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

// ===== Auth Functions =====
function isLogin() {
    return isset($_SESSION['uid']);
}

function requireLogin() {
    if (!isLogin()) {
        header('Location: login.php');
        exit;
    }
}

function getCurrentUser() {
    if (!isLogin()) return null;
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['uid']]);
    return $stmt->fetch();
}

function getUserStorageUsed($uid) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(size), 0) as used FROM files WHERE uid = ? AND deleted = 0");
    $stmt->execute([$uid]);
    return $stmt->fetch()['used'];
}

function formatSize($bytes) {
    if ($bytes >= 1073741824) return round($bytes / 1073741824, 2) . ' GB';
    if ($bytes >= 1048576) return round($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024) return round($bytes / 1024, 2) . ' KB';
    return $bytes . ' B';
}

function getFileType($ext) {
    $ext = strtolower($ext);
    if (in_array($ext, ['jpg','jpeg','png','gif','webp','svg','bmp'])) return 'image';
    if (in_array($ext, ['mp4','avi','mov','wmv','flv','mkv','webm'])) return 'video';
    if (in_array($ext, ['mp3','wav','flac','aac','ogg','wma'])) return 'audio';
    if (in_array($ext, ['doc','docx','txt','rtf','odt','md'])) return 'doc';
    if (in_array($ext, ['xls','xlsx','csv'])) return 'sheet';
    if (in_array($ext, ['ppt','pptx'])) return 'slides';
    if (in_array($ext, ['zip','rar','7z','tar','gz'])) return 'archive';
    if (in_array($ext, ['pdf'])) return 'pdf';
    return 'other';
}

function getFileIcon($type) {
    $icons = [
        'folder' => '<i class="fa fa-folder" style="color:#F59E0B"></i>',
        'image' => '<i class="fa fa-file-image-o" style="color:#EC4899"></i>',
        'video' => '<i class="fa fa-file-video-o" style="color:#F97316"></i>',
        'audio' => '<i class="fa fa-file-audio-o" style="color:#0EA5E9"></i>',
        'doc' => '<i class="fa fa-file-word-o" style="color:#4F6EF7"></i>',
        'sheet' => '<i class="fa fa-file-excel-o" style="color:#10B981"></i>',
        'slides' => '<i class="fa fa-file-powerpoint-o" style="color:#F97316"></i>',
        'archive' => '<i class="fa fa-file-archive-o" style="color:#F59E0B"></i>',
        'pdf' => '<i class="fa fa-file-pdf-o" style="color:#EF4444"></i>',
        'other' => '<i class="fa fa-file-o" style="color:#94A3B8"></i>',
    ];
    return $icons[$type] ?? $icons['other'];
}

function getFileIconHtml($type, $ext = '') {
    $iconMap = [
        'folder' => '<i class="fa fa-folder" style="color:#F59E0B"></i>',
        'image' => '<i class="fa fa-file-image-o" style="color:#EC4899"></i>',
        'video' => '<i class="fa fa-file-video-o" style="color:#F97316"></i>',
        'audio' => '<i class="fa fa-file-audio-o" style="color:#0EA5E9"></i>',
        'doc' => '<i class="fa fa-file-word-o" style="color:#4F6EF7"></i>',
        'sheet' => '<i class="fa fa-file-excel-o" style="color:#10B981"></i>',
        'slides' => '<i class="fa fa-file-powerpoint-o" style="color:#F97316"></i>',
        'archive' => '<i class="fa fa-file-archive-o" style="color:#F59E0B"></i>',
        'pdf' => '<i class="fa fa-file-pdf-o" style="color:#EF4444"></i>',
        'other' => '<i class="fa fa-file-o" style="color:#94A3B8"></i>',
    ];
    return $iconMap[$type] ?? $iconMap['other'];
}

function getFileTypeFromName($name) {
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    return getFileType($ext);
}

function isDangerousExt($ext) {
    $ext = strtolower($ext);
    return in_array($ext, ['php','php3','php4','php5','php7','phtml','pht','phps','cgi','pl','asp','aspx','cer','jsp','jspx','htaccess','htpasswd','sh','bash','cmd','bat','ps1','vbs','vbe','js','jse','wsf','wsc','wsh','py','pyc','pyw','rb','pl','cgi','fcgi','-wrapper']);
}

function isScriptExt($ext) {
    return false;
}

// ===== CSRF Protection =====
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field() {
    return '<input type="hidden" name="csrf_token" value="' . csrf_token() . '">';
}

function verify_csrf() {
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) {
        header('Content-Type: application/json');
        echo json_encode(['ok' => false, 'msg' => 'CSRF验证失败，请刷新页面重试']);
        exit;
    }
}

// ===== Share Functions =====
function generateShareCode($length = 6) {
    $chars = '0123456789abcdefghijklmnopqrstuvwxyz';
    $code = '';
    for ($i = 0; $i < $length; $i++) {
        $code .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $code;
}

// ===== File System Helpers =====
function createFolder($path) {
    if (!is_dir($path)) {
        mkdir($path, 0755, true);
    }
}

function deleteFolder($path) {
    if (!is_dir($path)) return;
    $items = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($path, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($items as $item) {
        if ($item->isDir()) {
            rmdir($item->getRealPath());
        } else {
            unlink($item->getRealPath());
        }
    }
    rmdir($path);
}

// ===== Input Sanitization =====
function cleanInput($input) {
    return htmlspecialchars(trim(strip_tags($input)), ENT_QUOTES, 'UTF-8');
}

function isEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}
