    </div>
    </div>
</div>

<!-- Spotlight Onboarding Overlay -->
<div class="spotlight-overlay" id="spotlightOverlay">
    <div class="spotlight-mask" id="spotlightMask"></div>
    <div class="spotlight-box" id="spotlightBox">
        <div class="spotlight-step-num" id="spotNum">1/5</div>
        <h3 id="spotTitle"></h3>
        <p id="spotDesc"></p>
        <div class="spotlight-nav">
            <span class="spotlight-dot-container" id="spotDots"></span>
            <button class="spotlight-btn" id="spotBtn" onclick="spotNext()">下一步</button>
        </div>
    </div>
</div>

<!-- Global Drag Upload Overlay -->
<div class="drag-overlay" id="dragOverlay">
    <div class="drag-overlay-inner">
        <i class="fa fa-cloud-upload"></i>
        <p>松开即可上传文件</p>
    </div>
</div>

<!-- Floating Upload Button -->
<div class="floating-upload" id="fabContainer">
    <div class="fab-panel" id="fabPanel">
        <h4>上传文件</h4>
        <div class="fab-dropzone" id="fabDropzone">
            <i class="fa fa-cloud-upload"></i>
            <p>点击选择文件</p>
            <small>支持任意格式</small>
            <input type="file" id="fabFileInput" multiple style="display:none">
        </div>
        <div class="fab-progress" id="fabProgress"></div>
    </div>
    <button class="fab-btn" id="fabBtn" onclick="toggleFab()"><i class="fa fa-plus"></i></button>
</div>

<!-- Global Upload Panel -->
<div class="global-upload-btn" id="globalUploadBtn" onclick="toggleGlobalUpload()" style="display:none;">
    <i class="fa fa-cloud-upload"></i>
    <span class="gup-badge" id="gupBadge"></span>
</div>
<div class="global-upload-panel" id="globalUploadPanel"></div>

<script>
// ===== Global Upload Manager (persists across page switches) =====
var UploadManager = (function(){
    var tasks = [];
    var uploading = 0;
    var MAX_CONCURRENT = 3;
    var CHUNK_SIZE = 5 * 1024 * 1024;
    var MAX_SINGLE = <?= parse_size(ini_get('upload_max_filesize')) ?>;
    var csrfToken = '<?= csrf_token() ?>';
    var folderId = 0;
    var _lastSaveTime=0;
    function throttledSave(){var now=Date.now();if(now-_lastSaveTime>2000){_lastSaveTime=now;saveState();}}

    function init(){
        var saved=sessionStorage.getItem('upload_tasks');
        if(saved){try{var p=JSON.parse(saved);tasks=p.filter(function(t){return t.status==='uploading'||t.status==='pending';});tasks.forEach(function(t){t.file=null;t.xhr=null;t.status='pending';t.progress=t.progress||0;});}catch(e){tasks=[];}}
        var panel=document.getElementById('globalUploadPanel');
        var btn=document.getElementById('globalUploadBtn');
        if(panel){
            panel.addEventListener('click',function(e){
                e.stopPropagation();
                var cancelBtn=e.target.closest('.gup-cancel');
                if(cancelBtn){cancelTask(cancelBtn.getAttribute('data-id'));return;}
                var allBtn=e.target.closest('[data-action="cancelAll"]');
                if(allBtn){cancelAll();}
            });
        }
        setInterval(function(){
            if(tasks.length>0)updatePanel();
            else{panel.classList.remove('show');btn.classList.remove('active');}
        },1000);
    }

    function setFolderId(id){folderId=id;}

    function addFiles(files){
        for(var i=0;i<files.length;i++){
            var f=files[i];
            tasks.push({id:Date.now()+'_'+i,name:f.name,size:f.size,progress:0,status:'pending',file:f,xhr:null,fileId:null,el:null});
        }
        updatePanel();
        uploadNext();
    }

    function uploadNext(){
        while(uploading<MAX_CONCURRENT){
            var task=tasks.find(function(t){return t.status==='pending'&&t.file;});
            if(!task)break;
            task.status='uploading';
            uploading++;
            if(task.size>MAX_SINGLE)uploadChunked(task);else uploadSingle(task);
        }
        saveState();
    }

    function uploadSingle(task){
        var fd=new FormData();
        var safeName=task.name.replace(/[^\x00-\x7F]/g,'_');
        var renamedFile=new File([task.file],safeName,{type:task.file.type,lastModified:task.file.lastModified});
        fd.append('files[]',renamedFile);
        fd.append('original_name',task.name);
        fd.append('action','upload');
        fd.append('folder_id',folderId);
        fd.append('csrf_token',csrfToken);
        var xhr=new XMLHttpRequest();
        task.xhr=xhr;
        xhr.upload.onprogress=function(e){
            if(e.lengthComputable){
                task.progress=Math.round(e.loaded/e.total*100);
                updateTaskRow(task);
                throttledSave();
            }
        };
        xhr.onload=function(){
            if(xhr.status===500){task.status='error';task.errorMsg='上传失败';uploading--;updateTaskRow(task);uploadNext();saveState();return;}
            try{
                var res=JSON.parse(xhr.responseText);
                if(Array.isArray(res)&&res[0]&&res[0].success){task.status='done';}
                else{task.status='error';task.errorMsg=(res[0]&&res[0].msg)||'上传失败';}
            }catch(ex){task.status='error';task.errorMsg='响应解析失败';}
            uploading--;
            if(task.status==='done')removeTask(task);
            else updateTaskRow(task);
            uploadNext();saveState();checkRefreshNeeded();
        };
        xhr.onerror=function(){task.status='error';task.errorMsg='网络错误';uploading--;updateTaskRow(task);uploadNext();saveState();};
        xhr.open('POST','index.php');
        xhr.send(fd);
    }

    function uploadChunked(task){
        var file=task.file;
        var totalChunks=Math.ceil(file.size/CHUNK_SIZE);
        var currentChunk=0;
        var fileId=task.name+'_'+task.size+'_'+Date.now();
        task.fileId=fileId;
        function uploadChunk(){
            if(currentChunk>=totalChunks){task.status='done';uploading--;removeTask(task);uploadNext();saveState();checkRefreshNeeded();return;}
            var start=currentChunk*CHUNK_SIZE;
            var end=Math.min(start+CHUNK_SIZE,file.size);
            var chunk=file.slice(start,end);
            var fd=new FormData();
            fd.append('action','upload_chunk');fd.append('file_id',fileId);fd.append('chunk',currentChunk);fd.append('total_chunks',totalChunks);fd.append('name',task.name);fd.append('size',file.size);fd.append('folder_id',folderId);fd.append('csrf_token',csrfToken);fd.append('file_chunk',chunk,'chunk_'+currentChunk);
            var xhr=new XMLHttpRequest();
            task.xhr=xhr;
            xhr.upload.onprogress=function(e){
                if(e.lengthComputable){task.progress=Math.round(((currentChunk+e.loaded/e.total)/totalChunks)*100);updateTaskRow(task);throttledSave();}
            };
            xhr.onload=function(){
                try{var res=JSON.parse(xhr.responseText);if(res.merge){task.status='done';uploading--;removeTask(task);uploadNext();saveState();checkRefreshNeeded();return;}else{currentChunk++;uploadChunk();}}
                catch(ex){currentChunk++;uploadChunk();}
            };
            xhr.onerror=function(){task.status='error';uploading--;updateTaskRow(task);uploadNext();saveState();};
            xhr.open('POST','index.php');xhr.send(fd);
        }
        uploadChunk();
    }

    function cancelTask(id){
        for(var i=0;i<tasks.length;i++){
            if(tasks[i].id===id){
                var task=tasks[i];
                if(task.xhr){try{task.xhr.abort();}catch(e){}if(task.status==='uploading')uploading--;}
                if(task.fileId){
                    var fd=new FormData();fd.append('action','cancel_chunk');fd.append('file_id',task.fileId);fd.append('csrf_token',csrfToken);
                    fetch('index.php',{method:'POST',body:fd});
                }
                removeTask(task);
                uploadNext();saveState();
                return;
            }
        }
    }

    function cancelAll(){
        var list=tasks.slice();
        tasks=[];uploading=0;
        list.forEach(function(t){
            if(t.xhr){try{t.xhr.abort();}catch(e){}}
            if(t.fileId){var fd=new FormData();fd.append('action','cancel_chunk');fd.append('file_id',t.fileId);fd.append('csrf_token',csrfToken);fetch('index.php',{method:'POST',body:fd});}
        });
        buildPanel();saveState();
    }

    function removeTask(task){
        tasks=tasks.filter(function(t){return t!==task;});
        if(task.el&&task.el.parentNode)task.el.remove();
        task.el=null;
        updateHeader();
        if(tasks.length===0){
            var panel=document.getElementById('globalUploadPanel');
            var btn=document.getElementById('globalUploadBtn');
            panel.classList.remove('show');btn.classList.remove('active');
        }
    }

    function updateTaskRow(task){
        if(!task.el)return;
        var bar=task.el.querySelector('.gup-fill');
        var meta=task.el.querySelector('.gup-meta');
        if(bar)bar.style.width=task.progress+'%';
        if(meta){
            var st=task.el.querySelector('.gup-status');
            if(st){
                if(task.status==='error'){st.textContent='失败';st.style.color='var(--danger)';bar.className='gup-fill error';}
                else{st.textContent=task.progress+'%';st.style.color='var(--primary)';}
            }
        }
    }

    function updateHeader(){
        var hdr=document.getElementById('gupTitle');
        if(!hdr)return;
        var active=tasks.filter(function(t){return t.status==='uploading'||t.status==='pending';}).length;
        var errors=tasks.filter(function(t){return t.status==='error';}).length;
        hdr.textContent='上传任务 ('+active+' 进行中'+(errors?', '+errors.length+' 夂败':'')+')';
    }

    function buildPanel(){
        var panel=document.getElementById('globalUploadPanel');
        var btn=document.getElementById('globalUploadBtn');
        if(!panel||!btn)return;
        if(tasks.length===0){panel.classList.remove('show');btn.classList.remove('active');return;}
        btn.classList.add('active');
        panel.innerHTML='<div class="gup-header"><span class="gup-title" id="gupTitle">上传任务</span><div class="gup-actions"><button class="gup-btn gup-danger" data-action="cancelAll">取消全部</button></div></div><div class="gup-list" id="gupList"></div>';
        var list=document.getElementById('gupList');
        tasks.forEach(function(t){
            if(!t.el)createTaskEl(t,list);
        });
        updateHeader();
        panel.classList.add('show');
    }

    function createTaskEl(task,list){
        var icon=getUploadIcon(task.name);
        var div=document.createElement('div');
        div.className='gup-item';
        div.setAttribute('data-id',task.id);
        div.innerHTML='<div class="gup-icon">'+icon+'</div><div class="gup-info"><div class="gup-name" title="'+esc(task.name)+'">'+esc(task.name)+'</div><div class="gup-meta"><span>'+fmtSize(task.size)+'</span><span class="gup-status" style="color:var(--primary)">'+task.progress+'%</span></div><div class="gup-bar"><div class="gup-fill" style="width:'+task.progress+'%"></div></div></div><button class="gup-cancel" data-id="'+task.id+'"><i class="fa fa-times"></i></button>';
        task.el=div;
        if(list)list.appendChild(div);else{var l=document.getElementById('gupList');if(l)l.appendChild(div);}
    }

    function updatePanel(){
        var panel=document.getElementById('globalUploadPanel');
        var btn=document.getElementById('globalUploadBtn');
        if(!panel||!btn)return;
        var hasActive=tasks.some(function(t){return t.status==='uploading'||t.status==='pending'||t.status==='error';});
        if(!hasActive&&tasks.length===0){panel.classList.remove('show');btn.classList.remove('active');return;}
        if(!panel.classList.contains('show'))buildPanel();
        else updateHeader();
    }

    function getUploadIcon(n){
        if(/\.(mp4|mov|avi|mkv|webm)$/i.test(n))return'<i class="fa fa-file-video-o" style="color:#F97316"></i>';
        if(/\.(png|jpg|jpeg|gif|webp|svg)$/i.test(n))return'<i class="fa fa-file-image-o" style="color:#EC4899"></i>';
        if(/\.(zip|rar|7z|tar|gz)$/i.test(n))return'<i class="fa fa-file-archive-o" style="color:#F59E0B"></i>';
        if(/\.(ppt|pptx)$/i.test(n))return'<i class="fa fa-file-powerpoint-o" style="color:#F97316"></i>';
        if(/\.(xls|xlsx|csv)$/i.test(n))return'<i class="fa fa-file-excel-o" style="color:#10B981"></i>';
        if(/\.(doc|docx)$/i.test(n))return'<i class="fa fa-file-word-o" style="color:#4F6EF7"></i>';
        if(/\.(pdf)$/i.test(n))return'<i class="fa fa-file-pdf-o" style="color:#EF4444"></i>';
        if(/\.(mp3|wav|flac|aac)$/i.test(n))return'<i class="fa fa-file-audio-o" style="color:#0EA5E9"></i>';
        return'<i class="fa fa-file-o" style="color:#94A3B8"></i>';
    }
    function fmtSize(b){if(b>=1073741824)return(b/1073741824).toFixed(1)+' GB';if(b>=1048576)return(b/1048576).toFixed(1)+' MB';return(b/1024).toFixed(1)+' KB';}
    function esc(s){var d=document.createElement('div');d.textContent=s;return d.innerHTML;}

    var _refreshPending=false;
    function checkRefreshNeeded(){
        if(_refreshPending)return;
        _refreshPending=true;
        showToast('上传完成，正在刷新...','success');
        setTimeout(function(){
            var contentArea=document.querySelector('.content-area');
            if(contentArea&&typeof navigateFolder==='function'){navigateFolder(typeof currentFolderId!=='undefined'?currentFolderId:0);}
            else if(contentArea){location.reload();}
            _refreshPending=false;
        },800);
    }

    function isActive(){return tasks.some(function(t){return t.status==='uploading'||t.status==='pending';});}
    function saveState(){var s=tasks.filter(function(t){return t.status==='uploading'||t.status==='pending';}).map(function(t){return{id:t.id,name:t.name,size:t.size,progress:t.progress,status:t.status};});sessionStorage.setItem('upload_tasks',JSON.stringify(s));}

    init();

    window.addEventListener('beforeunload',function(){
        if(tasks.some(function(t){return t.status==='uploading'||t.status==='pending';})){saveState();return '正在上传文件，离开页面后上传将中断，确定离开吗？';}
    });
    document.querySelectorAll('.sidebar-nav a').forEach(function(a){
        a.addEventListener('click',function(e){
            if(tasks.some(function(t){return t.status==='uploading'||t.status==='pending';})){
                if(!confirm('正在上传文件，离开页面后上传将中断，确定离开吗？')){e.preventDefault();}
            }
        });
    });

    return{addFiles:addFiles,cancelTask:cancelTask,cancelAll:cancelAll,buildPanel:buildPanel,setFolderId:setFolderId,isActive:isActive};
})();

function toggleGlobalUpload(){
    var panel=document.getElementById('globalUploadPanel');
    panel.classList.toggle('show');
}

// ===== Global Drag Upload =====
var dragCounter=0;
var dragOverlay=document.getElementById('dragOverlay');
document.addEventListener('dragenter',function(e){
    e.preventDefault();
    if(e.target.closest('#userDropdownWrap')||e.target.closest('.user-avatar-link'))return;
    if(e.dataTransfer&&e.dataTransfer.types&&e.dataTransfer.types.indexOf('Files')!==-1){
        dragCounter++;if(dragCounter===1)dragOverlay.classList.add('show');
    }
});
document.addEventListener('dragleave',function(e){
    e.preventDefault();
    if(e.dataTransfer&&e.dataTransfer.types&&e.dataTransfer.types.indexOf('Files')!==-1){
        dragCounter--;if(dragCounter===0)dragOverlay.classList.remove('show');
    }
});
document.addEventListener('dragover',function(e){
    if(e.dataTransfer&&e.dataTransfer.types&&e.dataTransfer.types.indexOf('Files')!==-1)e.preventDefault();
});
document.addEventListener('drop',function(e){
    if(e.target.closest('#userDropdownWrap')||e.target.closest('.user-avatar-link')){e.preventDefault();return;}
    if(e.dataTransfer&&e.dataTransfer.files&&e.dataTransfer.files.length){
        e.preventDefault();dragCounter=0;dragOverlay.classList.remove('show');
        UploadManager.addFiles(e.dataTransfer.files);
    }
});

// ===== Floating Upload =====
var fabOpen=false;
var fabUploading=false;
function toggleFab(){fabOpen=!fabOpen;document.getElementById('fabPanel').classList.toggle('show',fabOpen);document.getElementById('fabBtn').classList.toggle('open',fabOpen);}
document.addEventListener('click',function(e){if(fabOpen&&!document.getElementById('fabContainer').contains(e.target)){fabOpen=false;document.getElementById('fabPanel').classList.remove('show');document.getElementById('fabBtn').classList.remove('open');}});
var fabDZ=document.getElementById('fabDropzone'),fabFI=document.getElementById('fabFileInput');
fabDZ.addEventListener('click',function(){fabFI.click();});
fabDZ.addEventListener('dragover',function(e){e.preventDefault();fabDZ.classList.add('dragover');});
fabDZ.addEventListener('dragleave',function(){fabDZ.classList.remove('dragover');});
fabDZ.addEventListener('drop',function(e){e.preventDefault();fabDZ.classList.remove('dragover');if(e.dataTransfer.files.length)UploadManager.addFiles(e.dataTransfer.files);});
fabFI.addEventListener('change',function(){if(this.files.length)UploadManager.addFiles(this.files);this.value='';});

// ===== Spotlight Onboarding =====
var SP_KEY='mycloud_ob_done';
var steps=[
    {target:'.sidebar-brand',title:'品牌导航',desc:'点击品牌图标返回文件首页',pos:'right',mobileSkip:true},
    {target:'.sidebar-nav',title:'文件管理',desc:'在这里浏览全部文件和回收站',pos:'right',mobileSkip:true},
    {target:'.search-box',title:'搜索文件',desc:'输入文件名快速搜索定位文件',pos:'bottom',mobileSkip:true},
    {target:'.view-toggle',title:'切换视图',desc:'在列表和网格两种布局间切换',pos:'bottom',mobileSkip:true},
    {target:'.floating-upload',title:'快速上传',desc:'点击蓝色按钮或拖拽文件到页面上传',pos:'left'},
    {target:'.sidebar .storage-box',title:'存储空间',desc:'实时显示存储使用情况，本系统无容量限制',pos:'right',mobileSkip:true},
    {target:'.user-dropdown-wrap',title:'用户菜单',desc:'点击右上角头像查看个人中心、安全中心、退出登录',pos:'bottom',openMenu:true},
    {target:'.content-area',title:'右键菜单',desc:'在文件上右键（手机长按）可查看、下载、分享、重命名、删除等操作',pos:'bottom'},
];
var mobileSteps=[
    {target:'.sidebar-toggle',title:'展开侧边栏',desc:'点击左侧箭头展开侧边栏，查看文件分类和存储空间',pos:'right'},
    {target:'.floating-upload',title:'快速上传',desc:'点击蓝色按钮或拖拽文件到页面上传',pos:'left'},
    {target:'.user-dropdown-wrap',title:'用户菜单',desc:'点击右上角头像查看个人中心、安全中心、退出登录',pos:'bottom',openMenu:true},
    {target:'.content-area',title:'长按操作',desc:'长按文件可查看、下载、分享、重命名、删除等操作',pos:'bottom'},
];
var spotIdx=0;
function isMobile(){return window.innerWidth<=768;}
function getVisibleSteps(){return isMobile()?mobileSteps:steps;}

function showSpotlight(){spotIdx=0;renderSpot();document.getElementById('spotlightOverlay').classList.add('show');}
function closeSpot(){
    var ov=document.getElementById('spotlightOverlay');
    var mask=document.getElementById('spotlightMask');
    if(mask)mask.style.clipPath='none';
    ov.classList.remove('show');
    localStorage.setItem(SP_KEY,'1');
    var dd=document.getElementById('userDropdown');if(dd)dd.classList.remove('show');
    // Close context menu
    var cm=document.getElementById('ctxMenu');if(cm)cm.classList.remove('show');
}

if(!localStorage.getItem(SP_KEY)){
    window.addEventListener('load',function(){setTimeout(showSpotlight,600);});
}
function spotNext(){spotIdx++;var vs=getVisibleSteps();if(spotIdx>=vs.length){closeSpot();return;}
    var cm=document.getElementById('ctxMenu');if(cm)cm.classList.remove('show');
    renderSpot();}

function renderSpot(){
    var vs=getVisibleSteps();
    var s=vs[spotIdx];
    if(!s){closeSpot();return;}
    var curPage=new URLSearchParams(window.location.search).get('page')||'files';
    if(s.page&&s.page!==curPage){window.location.href='index.php?page='+s.page+'&_spot='+spotIdx;return;}
    var el=document.querySelector(s.target);
    if(!el){spotNext();return;}
    if(s.openMenu){var dd=document.getElementById('userDropdown');if(dd)dd.classList.add('show');}
    // Show context menu for file-table step
    if(s.showMenu){
        var firstRow=el.querySelector('tr.file-row')||el.querySelector('.file-card');
        if(firstRow){
            setTimeout(function(){
                var ev=new MouseEvent('contextmenu',{bubbles:true,cancelable:true,view:window,clientX:firstRow.getBoundingClientRect().left+50,clientY:firstRow.getBoundingClientRect().top+20});
                firstRow.dispatchEvent(ev);
            },200);
        }
    }
    var mask=document.getElementById('spotlightMask');
    var box=document.getElementById('spotlightBox');
    var pad=10;
    var x1=r.left-pad, y1=r.top-pad, x2=r.left+r.width+pad, y2=r.top+r.height+pad;
    mask.style.clipPath='polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%, 0px '+y1+'px, '+x1+'px '+y1+'px, '+x1+'px '+y2+'px, '+x2+'px '+y2+'px, '+x2+'px '+y1+'px, 0px '+y1+'px)';
    var tx,ty;
    if(s.pos==='right'){tx=x2+20;ty=y1;}
    else if(s.pos==='left'){tx=x1-324;ty=y1;}
    else if(s.pos==='bottom'){tx=x1;ty=y2+20;}
    else{tx=x1;ty=y1-140;}
    tx=Math.max(16,Math.min(tx,window.innerWidth-320));
    ty=Math.max(16,Math.min(ty,window.innerHeight-160));
    box.style.left=tx+'px';box.style.top=ty+'px';
    document.getElementById('spotTitle').textContent=s.title;
    document.getElementById('spotDesc').textContent=s.desc;
    document.getElementById('spotNum').textContent=(spotIdx+1)+'/'+vs.length;
    document.getElementById('spotDots').innerHTML=vs.map(function(_,i){return '<span class="spot-dot'+(i===spotIdx?' active':'')+'"></span>';}).join('');
    var btn=document.getElementById('spotBtn');
    btn.textContent=spotIdx===vs.length-1?'完成':'下一步';
    el.scrollIntoView({behavior:'smooth',block:'center'});
}

if(!localStorage.getItem(SP_KEY)){
    window.addEventListener('load',function(){setTimeout(showSpotlight,600);});
}
function spotNext(){spotIdx++;var vs=getVisibleSteps();if(spotIdx>=vs.length){closeSpot();return;}
    var cm=document.getElementById('ctxMenu');if(cm)cm.classList.remove('show');
    renderSpot();}

function renderSpot(){
    var vs=getVisibleSteps();
    var s=vs[spotIdx];
    if(!s){closeSpot();return;}
    var curPage=new URLSearchParams(window.location.search).get('page')||'files';
    if(s.page&&s.page!==curPage){window.location.href='index.php?page='+s.page+'&_spot='+spotIdx;return;}
    var el=document.querySelector(s.target);
    // For file-table step, try file-grid if file-table not found
    if(!el&&s.target==='.file-table'){el=document.querySelector('.file-grid');}
    if(!el){spotNext();return;}
    if(s.openMenu){var dd=document.getElementById('userDropdown');if(dd)dd.classList.add('show');}
    // Show context menu for file area step
    if(s.showMenu){
        var firstRow=el.querySelector('tr.file-row')||el.querySelector('.file-card');
        if(firstRow){
            setTimeout(function(){
                var rect=firstRow.getBoundingClientRect();
                var ev=new MouseEvent('contextmenu',{bubbles:true,cancelable:true,view:window,clientX:rect.left+rect.width/2,clientY:rect.top+rect.height/2});
                firstRow.dispatchEvent(ev);
            },200);
        }
    }
    var r=el.getBoundingClientRect();
    var mask=document.getElementById('spotlightMask');
    var box=document.getElementById('spotlightBox');
    var pad=10;
    var x1=r.left-pad, y1=r.top-pad, x2=r.left+r.width+pad, y2=r.top+r.height+pad;
    mask.style.clipPath='polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%, 0px '+y1+'px, '+x1+'px '+y1+'px, '+x1+'px '+y2+'px, '+x2+'px '+y2+'px, '+x2+'px '+y1+'px, 0px '+y1+'px)';
    var tx,ty;
    if(s.pos==='right'){tx=x2+20;ty=y1;}
    else if(s.pos==='left'){tx=x1-324;ty=y1;}
    else if(s.pos==='bottom'){tx=x1;ty=y2+20;}
    else{tx=x1;ty=y1-140;}
    tx=Math.max(16,Math.min(tx,window.innerWidth-320));
    ty=Math.max(16,Math.min(ty,window.innerHeight-160));
    box.style.left=tx+'px';box.style.top=ty+'px';
    document.getElementById('spotTitle').textContent=s.title;
    document.getElementById('spotDesc').textContent=s.desc;
    document.getElementById('spotNum').textContent=(spotIdx+1)+'/'+vs.length;
    document.getElementById('spotDots').innerHTML=vs.map(function(_,i){return '<span class="spot-dot'+(i===spotIdx?' active':'')+'"></span>';}).join('');
    var btn=document.getElementById('spotBtn');
    btn.textContent=spotIdx===vs.length-1?'完成':'下一步';
    el.scrollIntoView({behavior:'smooth',block:'center'});
}

var spotParam=new URLSearchParams(window.location.search).get('_spot');
if(spotParam!==null){
    spotIdx=parseInt(spotParam);
    setTimeout(function(){renderSpot();document.getElementById('spotlightOverlay').classList.add('show');},300);
} else if(!localStorage.getItem(SP_KEY)){
    var curPage=new URLSearchParams(window.location.search).get('page')||'files';
    if(curPage==='files'){
        window.addEventListener('load',function(){setTimeout(showSpotlight,600);});
    }
}

// ===== Toast =====
function showToast(msg,type){
    var t=document.getElementById('toast');if(!t)return;
    t.textContent=msg;t.className='toast '+(type||'success')+' show';
    setTimeout(function(){t.classList.remove('show');},2500);
}

// ===== 自动检查更新 =====
var UC_KEY='mycloud_auto_update';
function setCookie(k,v,days){var e=new Date();e.setTime(e.getTime()+days*864e5);document.cookie=k+'='+v+';expires='+e.toUTCString()+';path=/';}
function getCookie(k){var cs=document.cookie.split(';');for(var i=0;i<cs.length;i++){var c=cs[i].trim();if(c.indexOf(k+'=')===0)return c.substring(k.length+1);}return null;}
function toggleAutoUpdate(){
    var el=document.getElementById('autoUpdateToggle');
    if(!el)return;
    el.classList.toggle('active');
    if(el.classList.contains('active')){setCookie(UC_KEY,'1',365);}
    else{setCookie(UC_KEY,'',-1);}
}
function verCompare(a,b){
    var pa=a.split('.').map(Number),pb=b.split('.').map(Number);
    for(var i=0;i<3;i++){if((pa[i]||0)>(pb[i]||0))return 1;if((pa[i]||0)<(pb[i]||0))return -1;}
    return 0;
}
function autoCheckUpdate(){
    if(!getCookie(UC_KEY))return;
    var p=window.location.pathname;
    var q=window.location.search;
    var isMainIndex=(p.endsWith('/index.php')||p.endsWith('/'))&&p.indexOf('/admin/')===-1;
    var isFilesPage=q.indexOf('page=files')!==-1||q.indexOf('page=')===-1;
    if(!(isMainIndex&&isFilesPage))return;
    fetch('admin/ajax_update.php?act=check&_t='+Date.now())
        .then(function(r){return r.json();})
        .then(function(data){
            if(data.code===0&&data.version&&data.current&&verCompare(data.version,data.current)>0){
                showSideNotify('发现新版本 v'+data.version,'update');
            }
        })
        .catch(function(){});
}
function showSideNotify(msg,type){
    var n=document.createElement('div');
    n.className='side-notify '+type;
    var icon=type==='update'?'cloud-download':type==='latest'?'check-circle':'exclamation-circle';
    var linkHtml=type==='update'?' <a href="admin/index.php" style="color:var(--primary);text-decoration:underline;font-weight:700;margin-left:6px;">立即更新</a>':'';
    n.innerHTML='<i class="fa fa-'+icon+'"></i><span>'+msg+linkHtml+'</span>';
    document.body.appendChild(n);
    setTimeout(function(){n.classList.add('show');},10);
    setTimeout(function(){n.classList.remove('show');setTimeout(function(){n.remove();},400);},8000);
}
if(document.readyState==='complete'){autoCheckUpdate();}else{window.addEventListener('load',function(){setTimeout(autoCheckUpdate,2000);});}

// ===== Global Upload Panel CSS (injected) =====
(function(){
var css=document.createElement('style');
css.textContent='.global-upload-btn{position:fixed;bottom:90px;right:24px;width:48px;height:48px;border-radius:50%;background:var(--primary);color:#fff;display:flex;align-items:center;justify-content:center;font-size:18px;cursor:pointer;box-shadow:0 4px 12px rgba(79,110,247,.4);z-index:997;transition:all .3s;}.global-upload-btn:hover{transform:scale(1.1);}.global-upload-btn.active{animation:uploadPulse 2s infinite;}'
+'.gup-badge{position:absolute;top:-2px;right:-2px;width:18px;height:18px;border-radius:50%;background:var(--danger);color:#fff;font-size:10px;display:flex;align-items:center;justify-content:center;font-weight:600;}'
+'.global-upload-panel{position:fixed;bottom:148px;right:24px;width:380px;max-width:calc(100vw - 32px);max-height:60vh;background:#fff;border-radius:16px;box-shadow:0 8px 32px rgba(0,0,0,.15);z-index:999;display:none;overflow:hidden;flex-direction:column;}'
+'.global-upload-panel.show{display:flex;}'
+'.gup-header{padding:14px 16px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;}'
+'.gup-title{font-size:.875rem;font-weight:600;color:var(--text);}'
+'.gup-actions{display:flex;gap:6px;}'
+'.gup-btn{padding:4px 10px;border-radius:6px;border:1px solid var(--border);background:#fff;color:var(--text-sub);font-size:.75rem;cursor:pointer;}'
+'.gup-btn:hover{background:var(--bg);} '
+'.gup-danger{color:var(--danger);border-color:#FECACA;}'
+'.gup-list{overflow-y:auto;flex:1;padding:8px;}'
+'.gup-item{display:flex;align-items:center;gap:10px;padding:10px 8px;border-radius:10px;transition:background .15s;}'
+'.gup-item:hover{background:var(--bg);}'
+'.gup-icon{font-size:18px;flex-shrink:0;width:28px;text-align:center;}'
+'.gup-info{flex:1;min-width:0;}'
+'.gup-name{font-size:.8125rem;font-weight:500;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}'
+'.gup-meta{display:flex;justify-content:space-between;font-size:.75rem;color:var(--text-dim);margin-top:2px;}'
+'.gup-bar{height:3px;border-radius:2px;background:#F0F2F8;margin-top:6px;overflow:hidden;}'
+'.gup-fill{height:100%;border-radius:2px;transition:width .3s;background:var(--primary);}'
+'.gup-fill.done{background:var(--success);}'
+'.gup-fill.error{background:var(--danger);}'
+'.gup-cancel{border:none;background:none;color:var(--text-dim);cursor:pointer;padding:6px;font-size:14px;pointer-events:auto;position:relative;z-index:2;flex-shrink:0;}'
+'.gup-cancel:hover{color:var(--danger);}'
+'.gup-st-icon{font-size:14px;}'
+'@keyframes uploadPulse{0%,100%{box-shadow:0 4px 12px rgba(79,110,247,.4)}50%{box-shadow:0 4px 20px rgba(79,110,247,.7)}}';
document.head.appendChild(css);
})();

// ===== Update global upload button visibility =====
setInterval(function(){
var btn=document.getElementById('globalUploadBtn');
var badge=document.getElementById('gupBadge');
if(!btn)return;
if(UploadManager.isActive()){
btn.style.display='flex';
var active=tasks_count();
badge.textContent=active;
badge.style.display=active>0?'flex':'none';
}else{
btn.style.display='none';
}
},1000);
function tasks_count(){
try{var s=JSON.parse(sessionStorage.getItem('upload_tasks')||'[]');return s.filter(function(t){return t.status==='pending'||t.status==='uploading';}).length;}catch(e){return 0;}
}

<?php if(isset($_GET['msg'])): ?>
showToast('<?= htmlspecialchars($_GET['msg']) ?>','<?= $_GET['msg_type']??'success' ?>');
<?php endif; ?>
</script>
</body>
</html>
