<?php
require_once __DIR__ . '/auth.php';
$currentUser = getCurrentUser();
$used = getUserStorageUsed($_SESSION['uid']);
$totalBytes = getStorageTotal();
$freeBytes = getStorageLimit();
$totalGB = round($totalBytes / 1073741824, 1);
$usedGB = round($used / 1073741824, 2);
$freeGB = round($freeBytes / 1073741824, 1);
$pct = $totalBytes > 0 ? min(100, round($used / $totalBytes * 100)) : 0;
if (!isset($activePage)) $activePage = $_GET['page'] ?? 'files';
$pageForTitle = $activePage; // 保存原始page值用于标题
// 头像点击进来的页面不高亮侧边栏
if (isset($_GET['_from']) && $_GET['_from'] === 'avatar') $activePage = '__none__';
$viewMode = $_GET['view'] ?? 'list';
$initial = mb_substr($currentUser['nickname'] ?? $currentUser['username'], 0, 1);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <base href="<?= (strpos($_SERVER['SCRIPT_NAME'] ?? '', '/admin/') !== false || strpos($_SERVER['SCRIPT_NAME'] ?? '', '/security') !== false) ? '../' : '' ?>">
    <title><?= SITE_NAME ?></title>
    <link rel="icon" type="image/svg+xml" href="favicon.svg">
    <link rel="stylesheet" href="assets/css/fontawesome/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/style.css?v=2.1">
    <?php if($activePage === 'files' || $activePage === 'recycle'): ?>
    <?php include __DIR__ . '/preview.php'; ?>
    <?php endif; ?>
    <script src="assets/js/pinyin.js"></script>
    <?php include __DIR__ . '/antidebug.php'; ?>
</head>
<body>
<div class="app-layout">
    <div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>
    <div class="sidebar-toggle" id="sidebarToggle" onclick="toggleSidebar()">
        <div class="toggle-half"><i class="fa fa-chevron-right"></i></div>
    </div>

    <aside class="sidebar" id="sidebar">
        <a href="index.php" class="sidebar-brand" style="text-decoration:none;color:inherit;">
            <div class="logo"><i class="fa fa-cloud"></i></div>
            <span><?= SITE_NAME ?></span>
        </a>
        <nav class="sidebar-nav">
            <a href="index.php?page=files" class="<?= $activePage==='files'?'active':'' ?>"><i class="fa fa-files-o"></i> 全部文件</a>
            <a href="index.php?page=shares" class="<?= $activePage==='shares'?'active':'' ?>"><i class="fa fa-share-alt"></i> 管理分享</a>
            <a href="index.php?page=recycle" class="<?= $activePage==='recycle'?'active':'' ?>"><i class="fa fa-trash-o"></i> 回收站</a>
        </nav>
        <div class="sidebar-bottom">
            <div class="storage-box" style="margin:0;">
                <div class="storage-header">
                    <span>存储空间</span>
                    <span class="used"><?= $usedGB ?>GB / <?= $freeGB ?>GB 可用</span>
                </div>
                <div class="storage-bar"><div class="fill" style="width:<?= $pct ?>%"></div></div>
                <p class="storage-detail">已用 <?= $usedGB ?>GB，剩余 <?= $freeGB ?>GB</p>
            </div>
        </div>
    </aside>

    <div class="main-content">
        <header class="topbar">
            <div style="display:flex;align-items:center;gap:12px;">
                <h2><?php
                    $titles = ['files'=>['全部文件','fa-files-o'],'upload'=>['上传文件','fa-cloud-upload'],'recycle'=>['回收站','fa-trash-o'],'settings'=>['个人设置','fa-user'],'admin'=>['管理面板','fa-database'],'security'=>['安全中心','fa-shield'],'shares'=>['管理分享','fa-share-alt']];
                    $t = $titles[$pageForTitle] ?? ['文件管理','fa-folder'];
                    $titleText = $t[0];
                    if ($pageForTitle === 'files' && !empty($_GET['folder']) && intval($_GET['folder']) > 0) {
                        $folderStmt = $pdo->prepare("SELECT name FROM files WHERE id = ? AND uid = ? AND is_folder = 1 AND deleted = 0");
                        $folderStmt->execute([intval($_GET['folder']), $_SESSION['uid']]);
                        $folderRow = $folderStmt->fetch();
                        if ($folderRow) $titleText = $folderRow['name'];
                    }
                    echo '<i class="fa '.$t[1].'" style="color:var(--primary);font-size:1.1rem;"></i> '.htmlspecialchars($titleText);
                ?></h2>
            </div>
            <div class="topbar-actions">
                <?php if ($activePage === 'files'): ?>
                <div class="search-box">
                    <i class="fa fa-search"></i>
                    <input type="text" placeholder="搜索文件...">
                </div>
                <div class="view-toggle">
                    <a href="index.php?page=files&view=list" class="<?= $viewMode==='list'?'active':'' ?>"><i class="fa fa-list"></i></a>
                    <a href="index.php?page=files&view=grid" class="<?= $viewMode==='grid'?'active':'' ?>"><i class="fa fa-th"></i></a>
                </div>
                <?php endif; ?>
                <a href="index.php?page=upload" class="btn-upload"><i class="fa fa-cloud-upload"></i> 上传文件</a>

                <!-- User Avatar Dropdown -->
                <div class="user-dropdown-wrap" id="userDropdownWrap">
                    <div class="user-avatar-link" id="userAvatarBtn" onclick="toggleUserDropdown()" draggable="false">
                        <?php if (!empty($currentUser['avatar'])): ?>
                            <img src="<?= htmlspecialchars($currentUser['avatar']) ?>" alt="" draggable="false" style="width:32px;height:32px;border-radius:50%;object-fit:cover;border:2px solid var(--border);pointer-events:none;">
                        <?php else: ?>
                            <div style="width:32px;height:32px;border-radius:50%;background:var(--primary);color:#fff;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:600;"><?= $initial ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="user-dropdown" id="userDropdown">
                        <div class="user-dropdown-header">
                            <?php if (!empty($currentUser['avatar'])): ?>
                                <img src="<?= htmlspecialchars($currentUser['avatar']) ?>" draggable="false" style="width:40px;height:40px;border-radius:50%;object-fit:cover;pointer-events:none;">
                            <?php else: ?>
                                <div style="width:40px;height:40px;border-radius:50%;background:var(--primary);color:#fff;display:flex;align-items:center;justify-content:center;font-size:16px;font-weight:600;"><?= $initial ?></div>
                            <?php endif; ?>
                            <div>
                                <div style="font-weight:600;font-size:.875rem;color:var(--text);"><?= htmlspecialchars($currentUser['nickname'] ?? $currentUser['username']) ?></div>
                                <div style="font-size:.75rem;color:var(--text-dim);"><?= htmlspecialchars($currentUser['email'] ?? '') ?></div>
                            </div>
                        </div>
                        <div class="user-dropdown-sep"></div>
                        <a href="index.php?page=settings&_from=avatar" class="user-dropdown-item"><i class="fa fa-user"></i> 个人中心</a>
                        <a href="admin/index.php?_from=avatar" class="user-dropdown-item"><i class="fa fa-database"></i> 更新管理</a>
                        <a href="security.php?_from=avatar" class="user-dropdown-item"><i class="fa fa-shield"></i> 安全中心</a>
                        <div class="user-dropdown-sep"></div>
                        <a href="index.php?action=logout" class="user-dropdown-item" style="color:var(--danger);"><i class="fa fa-sign-out"></i> 退出登录</a>
                    </div>
                </div>
            </div>
        </header>

<script>
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('sidebarOverlay').classList.toggle('show');
    document.getElementById('sidebarToggle').classList.toggle('open');
}
function toggleUserDropdown() {
    document.getElementById('userDropdown').classList.toggle('show');
}
document.addEventListener('click', function(e) {
    const wrap = document.getElementById('userDropdownWrap');
    if (wrap && !wrap.contains(e.target)) {
        document.getElementById('userDropdown').classList.remove('show');
    }
});

// View mode persistence
(function(){
    var VIEW_KEY='mycloud_view_mode';
    var params=new URLSearchParams(window.location.search);
    var pageVal=params.get('page');
    if(pageVal==='files'){
        var v=params.get('view');
        if(v){localStorage.setItem(VIEW_KEY,v);}
        else{
            var saved=localStorage.getItem(VIEW_KEY);
            if(saved&&(saved==='list'||saved==='grid')){
                params.set('view',saved);
                window.location.replace('index.php?'+params.toString());
            }
        }
    }
    document.querySelectorAll('.view-toggle a').forEach(function(a){
        a.addEventListener('click',function(e){
            e.preventDefault();
            var href=a.getAttribute('href');
            var mView=href.match(/view=(\w+)/);
            if(mView){localStorage.setItem(VIEW_KEY,mView[1]);}
            window.location.href=href;
        });
    });
})();

// Real-time search - global search via server
(function(){
    var searchInput=document.querySelector('.search-box input');
    if(!searchInput)return;
    var originalContent=null;
    var searchTimer=null;
    searchInput.addEventListener('input',function(){
        var q=searchInput.value.replace(/\s+/g,'').trim();
        var contentArea=document.querySelector('.content-area');
        if(!contentArea)return;
        clearTimeout(searchTimer);
        if(!q){
            if(originalContent){
                contentArea.innerHTML=originalContent;
                originalContent=null;
            }
            return;
        }
        searchTimer=setTimeout(function(){
            if(!originalContent)originalContent=contentArea.innerHTML;
            var view=window.location.search.indexOf('view=grid')!==-1?'grid':'list';
            fetch('index.php?ajax=search&q='+encodeURIComponent(q)+'&view='+view,{headers:{'X-Requested-With':'XMLHttpRequest'}})
            .then(function(r){return r.text();})
            .then(function(html){
                if(!html.trim()){
                    contentArea.innerHTML='<div style="text-align:center;padding:60px 20px;color:var(--text-dim);"><i class="fa fa-search" style="font-size:48px;margin-bottom:12px;display:block;"></i><p>未找到匹配的文件</p></div>';
                    return;
                }
                if(view==='grid'){
                    contentArea.innerHTML='<div class="file-grid">'+html+'</div>';
                }else{
                    contentArea.innerHTML='<table class="file-table"><thead><tr><th style="width:40px"><input type="checkbox" onchange="toggleAll(this)" style="accent-color:var(--primary)"></th><th>文件名</th><th style="width:112px">大小</th><th style="width:160px">修改时间</th><th style="width:112px">操作</th></tr></thead><tbody>'+html+'</tbody></table>';
                }
            });
        },300);
    });
    searchInput.addEventListener('keydown',function(e){
        if(e.key==='Enter')e.preventDefault();
    });
})();
</script>
