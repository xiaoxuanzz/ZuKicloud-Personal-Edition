<?php
class SafeRender {
    private static $token = null;
    private static $secret = 'mc_sk_2024_secure_key_do_not_share';

    public static function init() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (empty($_SESSION['rt']) || (time() - ($_SESSION['rtt'] ?? 0)) > 3600) {
            $_SESSION['rt'] = bin2hex(random_bytes(16));
            $_SESSION['rtt'] = time();
        }
        self::$token = $_SESSION['rt'];
    }

    public static function getToken() { return self::$token; }

    private static function deriveAesKey($token) {
        $k1 = hash_hmac('sha256', $token, self::$secret);
        $k2 = hash_hmac('sha256', $k1, self::$secret . ':aes');
        return $k2;
    }

    private static function deriveHmacKey($token) {
        return hash_hmac('sha256', $token, self::$secret . ':hmac');
    }

    private static function encrypt($plaintext, $aesKeyHex) {
        $key = hex2bin($aesKeyHex);
        $iv = random_bytes(16);
        $encrypted = openssl_encrypt($plaintext, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
        $hmacKey = hex2bin(self::deriveHmacKey($_SESSION['rt']));
        $tag = hash_hmac('sha256', $iv . $encrypted, $hmacKey);
        return base64_encode($iv . $encrypted . hex2bin(substr($tag, 0, 32)));
    }

    private static function obfuscate($data) {
        $parts = str_split($data, 6);
        $shuffled = [];
        $map = range(0, count($parts) - 1);
        shuffle($map);
        foreach ($map as $i => $j) {
            $shuffled[] = $parts[$j];
        }
        return base64_encode(json_encode(['d' => $shuffled, 'm' => $map]));
    }

    private static function deobfuscate($encoded) {
        $obj = json_decode(base64_decode($encoded), true);
        $result = array_fill(0, count($obj['m']), '');
        foreach ($obj['m'] as $i => $j) {
            $result[$j] = $obj['d'][$i];
        }
        return implode('', $result);
    }

    private static function isSecureContext() {
        if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') return true;
        if (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443) return true;
        $host = $_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? '';
        if (preg_match('/^(localhost|127\.0\.0\.1|::1)(:\d+)?$/i', $host)) return true;
        return false;
    }

    public static function render($html) {
        if (!self::isSecureContext()) {
            echo $html;
            exit;
        }
        $token = self::getToken();
        $aesKeyHex = self::deriveAesKey($token);
        $payload = json_encode($html, JSON_UNESCAPED_UNICODE);
        $encrypted = self::encrypt($payload, $aesKeyHex);
        $keyObf = self::obfuscate($aesKeyHex);
        $encObf = self::obfuscate($encrypted);
        $ts = time();
        $check = hash_hmac('sha256', $ts . $token, self::$secret);
        ?>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title><?= SITE_NAME ?></title><link rel="icon" type="image/svg+xml" href="favicon.svg"></head>
<body>
<div id="_d" style="display:none" data-t="<?= $ts ?>" data-c="<?= $check ?>"><?= $encObf ?></div>
<div id="_k" style="display:none"><?= $keyObf ?></div>
<script>
(function(){
var _dc=document.getElementById('_d');
var _kc=document.getElementById('_k');
if(!_dc||!_kc)return;
var _ts=_dc.getAttribute('data-t');
var _ck=_dc.getAttribute('data-c');
var _enc64=_dc.textContent;_dc.textContent='';_dc.remove();
var _key64=_kc.textContent;_kc.textContent='';_kc.remove();
function _dob(e){var o=JSON.parse(atob(e));var r=Array(o.d.length);o.m.forEach(function(j,i){r[j]=o.d[i]});return r.join('')}
function _h2b(h){var b=new Uint8Array(h.length/2);for(var i=0;i<h.length;i+=2)b[i/2]=parseInt(h.substr(i,2),16);return b}
function _b2b(s){var d=atob(s);var a=new Uint8Array(d.length);for(var i=0;i<d.length;i++)a[i]=d.charCodeAt(i);return a}
var _kh=_dob(_key64);var _ed=_dob(_enc64);
var _raw=_b2b(_ed);var _iv=_raw.slice(0,16);var _ct=_raw.slice(16,_raw.length-16);var _tag=_raw.slice(_raw.length-16);
var _kb=_h2b(_kh);
if(window.crypto&&window.crypto.subtle){
window.crypto.subtle.importKey('raw',_kb,{name:'AES-CBC',length:256},false,['decrypt'])
.then(function(k){return window.crypto.subtle.decrypt({name:'AES-CBC',iv:_iv},k,_ct)})
.then(function(buf){
var s=new TextDecoder('utf-8').decode(new Uint8Array(buf));
try{var html=JSON.parse(s);document.open();document.write(html);document.close();}catch(e){}
}).catch(function(){});
}else{
fetch('index.php?page=files',{headers:{'X-Requested-With':'XMLHttpRequest'}}).then(function(r){return r.text();}).then(function(html){
document.open();document.write(html);document.close();
}).catch(function(){document.body.innerHTML='<div style="text-align:center;margin-top:40vh"><h2 style="color:#999">请使用 HTTPS 访问</h2><p>当前浏览器不支持加密传输，请使用 HTTPS 或 localhost 访问</p></div>';});
}
var _dc=0;function _lock(){if(_dc)return;_dc=1;var id=setInterval(function(){},99999);for(var i=0;i<=id;i++){clearInterval(i);clearTimeout(i);}
var o=document.createElement('div');o.id='_lk';o.style.cssText='position:fixed;inset:0;z-index:999999;background:#f8f9fa;display:flex;align-items:center;justify-content:center;font-family:sans-serif';
o.innerHTML='<div style="text-align:center"><h1 style="color:#555;font-size:1.5rem;font-weight:600">安全提示</h1><p style="color:#999;font-size:.9rem">检测到开发者工具，页面已锁定</p></div>';
document.documentElement.appendChild(o);
document.documentElement.style.overflow='hidden';
document.body.style.overflow='hidden';}
function _ck(){if(_dc)return;if(document.getElementById('_lk')){_dc=1;return;}var d=window.outerWidth-window.innerWidth>160||window.outerHeight-window.innerHeight>160;if(d)_lock();}
_ck();
document.addEventListener('DOMContentLoaded',_ck);
setInterval(_ck,800);
document.addEventListener('keydown',function(e){if(e.keyCode===123||(e.ctrlKey&&e.shiftKey&&(e.keyCode===73||e.keyCode===74)))_lock()});
document.addEventListener('contextmenu',function(e){e.preventDefault()});
})();
</script>
</body></html>
<?php
        exit;
    }

    public static function verifyApi() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $token = $_SERVER['HTTP_X_RENDER_KEY'] ?? '';
        if (empty($token) || empty($_SESSION['rt'])) return false;
        if (time() - ($_SESSION['rtt'] ?? 0) > 3600) return false;
        return hash_equals($_SESSION['rt'], $token);
    }

    public static function requireApi() {
        if (!self::verifyApi()) {
            http_response_code(403);
            header('Content-Type: application/json');
            echo json_encode(['error' => 'Forbidden']);
            exit;
        }
    }
}
