<!-- Preview Libraries CSS -->
<link rel="stylesheet" href="assets/lib/glightbox.min.css">
<link rel="stylesheet" href="assets/lib/plyr.css">
<link rel="stylesheet" href="assets/lib/highlight-dark.min.css">

<!-- Preview Libraries JS -->
<script src="assets/lib/pdf.min.js"></script>
<script src="assets/lib/pdf.worker.min.js"></script>
<script src="assets/lib/highlight.min.js"></script>
<script src="assets/lib/glightbox.min.js"></script>
<script src="assets/lib/plyr.js"></script>
<script src="assets/lib/marked.min.js"></script>
<script src="assets/lib/xlsx.full.min.js"></script>
<script src="assets/lib/mammoth.browser.min.js"></script>

<script>
(function(){
    var origGetContext=HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext=function(type){
        var args=Array.prototype.slice.call(arguments);
        if(type==='2d'&&args.length<2){args[1]={};}
        if(type==='2d'&&args[1]&&!args[1].willReadFrequently){args[1].willReadFrequently=true;}
        return origGetContext.apply(this,args);
    };
})();
var PreviewEngine = (function(){
    var imageExts = /\.(jpg|jpeg|png|gif|webp|bmp|tiff|tif|ico|heic|heif|svg)$/i;
    var videoExts = /\.(mp4|webm|avi|mov|mkv|flv|wmv|m4v|3gp|ogv)$/i;
    var audioExts = /\.(mp3|wav|flac|aac|ogg|wma|m4a|opus|aiff)$/i;
    var pdfExts = /\.pdf$/i;
    var mdExts = /\.(md|markdown)$/i;
    var excelExts = /\.(xls|xlsx|csv|ods)$/i;
    var wordExts = /\.(doc|docx|odt|rtf)$/i;
    var pptExts = /\.(ppt|pptx|odp)$/i;
    var textExts = /\.(txt|log|ini|conf|cfg|env|json|xml|yaml|yml|toml)$/i;
    var codeExts = /\.(js|ts|jsx|tsx|php|py|java|c|cpp|h|hpp|cs|go|rs|rb|swift|kt|scala|r|pl|sh|bash|bat|cmd|ps1|zsh|fish|css|scss|sass|less|styl|html|htm|sql|vue|svelte)$/i;
    var archiveExts = /\.(zip|rar|7z|tar|gz|bz2|xz)$/i;

    function getExt(name){
        var m = name.match(/\.([^.]+)$/);
        return m ? m[1].toLowerCase() : '';
    }

    function isImage(name){ return imageExts.test(name); }
    function isVideo(name){ return videoExts.test(name); }
    function isAudio(name){ return audioExts.test(name); }
    function isPdf(name){ return pdfExts.test(name); }
    function isMarkdown(name){ return mdExts.test(name); }
    function isExcel(name){ return excelExts.test(name); }
    function isWord(name){ return wordExts.test(name); }
    function isPpt(name){ return pptExts.test(name); }
    function isText(name){ return textExts.test(name); }
    function isCode(name){ return codeExts.test(name); }
    function isArchive(name){ return archiveExts.test(name); }

    function fetchText(url, cb, errCb){
        fetch(url).then(function(r){
            if(!r.ok) throw new Error('Network error');
            return r.text();
        }).then(cb).catch(errCb || function(){});
    }

    function escapeHtml(s){
        return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }

    function renderImage(url, name){
        return '<div class="preview-image-wrap"><img src="'+url+'" alt="'+escapeHtml(name)+'" style="max-width:100%;max-height:70vh;border-radius:12px;object-fit:contain;"></div>';
    }

    function renderSvg(url, name, container){
        fetch(url).then(function(r){return r.text();}).then(function(svg){
            if(svg.indexOf('<svg') === -1) throw new Error('Not SVG');
            var fixed = svg.replace(/<svg([^>]*)>/i, function(m, attrs){
                attrs = attrs.replace(/width="[^"]*"/gi, '').replace(/height="[^"]*"/gi, '');
                return '<svg' + attrs + ' style="max-width:100%;height:auto;">';
            });
            container.innerHTML = '<div style="padding:20px;background:#fff;border-radius:12px;">'+fixed+'</div>';
        }).catch(function(){
            container.innerHTML = renderImage(url, name);
        });
    }

    function renderVideo(url, ext){
        var type = 'video/' + (ext === 'mkv' ? 'x-matroska' : ext === 'avi' ? 'x-msvideo' : ext === 'mov' ? 'quicktime' : ext);
        return '<div class="preview-video-wrap" style="border-radius:12px;overflow:hidden;background:#000;"><video id="previewPlayer" controls style="width:100%;max-height:70vh;display:block;"><source src="'+url+'" type="'+type+'">您的浏览器不支持视频播放</video></div>';
    }

    function renderAudio(url, ext, name){
        var type = 'audio/' + (ext === 'm4a' ? 'mp4' : ext);
        return '<div style="padding:40px 20px;text-align:center;"><div style="width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,var(--primary),#7c3aed);display:flex;align-items:center;justify-content:center;margin:0 auto 20px;"><i class="fa fa-music" style="font-size:32px;color:#fff;"></i></div><p style="color:var(--text);font-weight:500;margin-bottom:20px;">'+escapeHtml(name)+'</p><audio id="previewPlayer" controls style="width:100%;max-width:500px;"><source src="'+url+'" type="'+type+'">您的浏览器不支持音频播放</audio></div>';
    }

    function renderPdf(url, container){
        container.innerHTML = '<div id="pdfCanvas" style="overflow:auto;max-height:70vh;text-align:center;background:#525659;padding:10px;border-radius:12px;"></div>';
        var containerEl = document.getElementById('pdfCanvas');
        var containerWidth = containerEl.clientWidth - 20;
        var dpr = window.devicePixelRatio || 1;
        pdfjsLib.GlobalWorkerOptions.workerSrc = 'assets/lib/pdf.worker.min.js';
        pdfjsLib.getDocument(url).promise.then(function(pdf){
            var totalPages = pdf.numPages;
            containerEl.innerHTML = '<div style="color:#ccc;font-size:12px;margin-bottom:8px;">共 '+totalPages+' 页</div>';
            for(var i = 1; i <= totalPages; i++){
                (function(pageNum){
                    pdf.getPage(pageNum).then(function(page){
                        var unscaledViewport = page.getViewport({scale:1});
                        var fitScale = Math.min(containerWidth / unscaledViewport.width, 2);
                        var renderScale = fitScale * dpr;
                        var viewport = page.getViewport({scale:renderScale});
                        var canvas = document.createElement('canvas');
                        canvas.id = 'pdfPage'+pageNum;
                        canvas.style.cssText = 'display:block;margin:0 auto 8px;max-width:100%;box-shadow:0 2px 8px rgba(0,0,0,0.3);border-radius:4px;width:'+(unscaledViewport.width*fitScale)+'px;height:'+(unscaledViewport.height*fitScale)+'px;';
                        var ctx = canvas.getContext('2d', {willReadFrequently: true});
                        canvas.height = viewport.height;
                        canvas.width = viewport.width;
                        containerEl.appendChild(canvas);
                        page.render({canvasContext:ctx, viewport:viewport});
                    });
                })(i);
            }
        }).catch(function(){
            container.innerHTML = '<div style="padding:40px;text-align:center;"><p style="color:var(--text-dim);">PDF 加载失败，请下载后查看</p></div>';
        });
    }

    function renderMarkdown(url, container){
        fetchText(url, function(text){
            var html = marked.parse(text);
            container.innerHTML = '<div class="preview-markdown" style="padding:24px;background:#fff;border-radius:12px;text-align:left;max-height:70vh;overflow:auto;line-height:1.8;color:var(--text);word-break:break-word;max-width:100%;">'+html+'</div>';
        }, function(){
            container.innerHTML = '<div style="padding:40px;text-align:center;"><p style="color:var(--text-dim);">无法加载文件</p></div>';
        });
    }

    function renderText(url, container){
        fetchText(url, function(text){
            container.innerHTML = '<pre style="text-align:left;padding:20px;background:var(--bg);border-radius:12px;overflow:auto;max-height:70vh;font-size:13px;line-height:1.6;white-space:pre-wrap;word-break:break-all;color:var(--text);font-family:Consolas,Monaco,\'Courier New\',monospace;">'+escapeHtml(text)+'</pre>';
        }, function(){
            container.innerHTML = '<div style="padding:40px;text-align:center;"><p style="color:var(--text-dim);">无法加载文件</p></div>';
        });
    }

    function renderCode(url, container){
        fetchText(url, function(text){
            var escaped = escapeHtml(text);
            container.innerHTML = '<pre style="text-align:left;padding:20px;background:#0d1117;border-radius:12px;overflow:auto;max-height:70vh;font-size:13px;line-height:1.6;white-space:pre-wrap;word-break:break-all;color:#c9d1d9;font-family:Consolas,Monaco,\'Courier New\',monospace;margin:0;"><code class="hljs">'+escaped+'</code></pre>';
            var codeEl = container.querySelector('code');
            if(codeEl && window.hljs){
                hljs.highlightElement(codeEl);
            }
        }, function(){
            container.innerHTML = '<div style="padding:40px;text-align:center;"><p style="color:var(--text-dim);">无法加载文件</p></div>';
        });
    }

    function renderExcel(url, container){
        container.innerHTML = '<div style="padding:20px;text-align:center;"><i class="fa fa-spinner fa-spin" style="font-size:24px;color:var(--primary);"></i><p style="color:var(--text-dim);margin-top:8px;">加载中...</p></div>';
        fetch(url).then(function(r){return r.arrayBuffer();}).then(function(data){
            var workbook = XLSX.read(data, {type:'array'});
            var sheetName = workbook.SheetNames[0];
            var sheet = workbook.Sheets[sheetName];
            var json = XLSX.utils.sheet_to_json(sheet, {header:1, defval:''});
            if(json.length === 0){
                container.innerHTML = '<div style="padding:40px;text-align:center;"><p style="color:var(--text-dim);">空工作表</p></div>';
                return;
            }
            var tableHtml = '<table style="width:100%;border-collapse:collapse;font-size:13px;background:#fff;">';
            json.forEach(function(row, ri){
                tableHtml += '<tr>';
                row.forEach(function(cell, ci){
                    var tag = ri === 0 ? 'th' : 'td';
                    var style = 'border:1px solid #d0d7de;padding:6px 10px;text-align:left;';
                    if(ri === 0) style += 'background:#f6f8fa;font-weight:600;position:sticky;top:0;';
                    if(ri > 0 && ci === 0) style += 'background:#f6f8fa;font-weight:500;';
                    tableHtml += '<'+tag+' style="'+style+'">'+escapeHtml(String(cell))+'</'+tag+'>';
                });
                tableHtml += '</tr>';
            });
            tableHtml += '</table>';
            container.innerHTML = '<div style="overflow:auto;max-height:70vh;border-radius:12px;border:1px solid var(--border);"><div style="padding:8px 16px;background:var(--bg);border-bottom:1px solid var(--border);font-size:13px;color:var(--text-sub);display:flex;justify-content:space-between;"><span>工作表: '+escapeHtml(sheetName)+'</span><span>'+json.length+' 行</span></div><div style="overflow:auto;">'+tableHtml+'</div></div>';
        }).catch(function(){
            container.innerHTML = '<div style="padding:40px;text-align:center;"><i class="fa fa-file-excel-o" style="font-size:64px;color:#217346;display:block;margin-bottom:16px;"></i><p style="color:var(--text-sub);">无法加载 Excel 预览</p><p style="color:var(--text-dim);font-size:.8125rem;margin-top:8px;">请下载后查看</p></div>';
        });
    }

    function renderWord(url, container){
        container.innerHTML = '<div style="padding:20px;text-align:center;"><i class="fa fa-spinner fa-spin" style="font-size:24px;color:var(--primary);"></i><p style="color:var(--text-dim);margin-top:8px;">加载中...</p></div>';
        fetch(url).then(function(r){return r.arrayBuffer();}).then(function(data){
            if(typeof mammoth !== 'undefined'){
                mammoth.convertToHtml({arrayBuffer:data}).then(function(result){
                    var html = result.value || '<p style="color:var(--text-dim);">文档内容为空</p>';
                    container.innerHTML = '<div class="preview-word" style="padding:32px 40px;background:#fff;border-radius:12px;text-align:left;max-height:70vh;overflow:auto;line-height:2;color:var(--text);font-size:15px;word-break:break-word;max-width:100%;">'+html+'</div>';
                }).catch(function(err){
                    container.innerHTML = '<div style="padding:40px;text-align:center;"><i class="fa fa-file-word-o" style="font-size:64px;color:var(--primary);display:block;margin-bottom:16px;"></i><p style="color:var(--text-sub);">Word 文档解析失败</p><p style="color:var(--text-dim);font-size:.8125rem;margin-top:8px;">请下载后查看</p></div>';
                });
            } else {
                container.innerHTML = '<div style="padding:40px;text-align:center;"><i class="fa fa-file-word-o" style="font-size:64px;color:var(--primary);display:block;margin-bottom:16px;"></i><p style="color:var(--text-sub);">Word 预览组件未加载</p><p style="color:var(--text-dim);font-size:.8125rem;margin-top:8px;">请下载后查看</p></div>';
            }
        }).catch(function(){
            container.innerHTML = '<div style="padding:40px;text-align:center;"><p style="color:var(--text-dim);">无法加载文件</p></div>';
        });
    }

    function renderUnsupported(type){
        var icon = 'fa-file-o';
        var color = 'var(--text-dim)';
        var text = '此文件类型暂不支持在线预览';
        if(type === 'ppt'){
            icon = 'fa-file-powerpoint-o'; color = '#D04423';
            text = 'PPT 文件预览需要下载后查看';
        } else if(type === 'archive'){
            icon = 'fa-file-archive-o'; color = '#F59E0B';
            text = '压缩包文件请下载后解压查看';
        }
        return '<div style="padding:40px;text-align:center;"><i class="fa '+icon+'" style="font-size:64px;color:'+color+';display:block;margin-bottom:16px;"></i><p style="color:var(--text-sub);">'+text+'</p><p style="color:var(--text-dim);font-size:.8125rem;margin-top:8px;">请下载后查看</p></div>';
    }

    // ===== Minimal ZIP + DEFLATE inflate for PPTX =====
    function readZip(buf){
        var dv=new DataView(buf), u8=new Uint8Array(buf);
        var files={}, eocdOffset=-1;
        for(var i=buf.byteLength-22;i>=Math.max(0,buf.byteLength-65557);i--){
            if(dv.getUint32(i,true)===0x06054b50){eocdOffset=i;break;}
        }
        if(eocdOffset<0)return files;
        var cdOffset=dv.getUint32(eocdOffset+16,true);
        var cdSize=dv.getUint32(eocdOffset+12,true);
        var pos=cdOffset, cdEnd=cdOffset+cdSize;
        while(pos<cdEnd){
            if(pos+46>buf.byteLength||dv.getUint32(pos,true)!==0x02014b50)break;
            var compMethod=dv.getUint16(pos+10,true);
            var compSizeCd=dv.getUint32(pos+20,true);
            var uncompSizeCd=dv.getUint32(pos+24,true);
            var nameLen=dv.getUint16(pos+28,true);
            var extraLen=dv.getUint16(pos+30,true);
            var commentLen=dv.getUint16(pos+32,true);
            var lhOffset=dv.getUint32(pos+42,true);
            var name='';
            for(var j=0;j<nameLen;j++)name+=String.fromCharCode(u8[pos+46+j]);
            if(lhOffset+30>buf.byteLength){pos+=46+nameLen+extraLen+commentLen;continue;}
            var lNameLen=dv.getUint16(lhOffset+26,true);
            var lExtraLen=dv.getUint16(lhOffset+28,true);
            var dataStart=lhOffset+30+lNameLen+lExtraLen;
            var flag=dv.getUint16(lhOffset+8,true);
            var lCompSize=dv.getUint32(lhOffset+18,true);
            if(compMethod===0){
                var fileSize=uncompSizeCd;
                if(lCompSize>0&&lCompSize<uncompSizeCd)fileSize=lCompSize;
                if(dataStart+fileSize<=buf.byteLength&&fileSize>0){
                    files[name]=new Uint8Array(buf,dataStart,fileSize);
                }
            }else if(compMethod===8){
                var rawLen=compSizeCd;
                if(lCompSize>0)rawLen=lCompSize;
                if(rawLen>0&&dataStart+rawLen<=buf.byteLength){
                    var rawBytes=new Uint8Array(buf,dataStart,rawLen);
                    try{
                        var result=inflateRaw(rawBytes);
                        if(result&&result.length>0)files[name]=result;
                    }catch(e){}
                }
            }
            pos+=46+nameLen+extraLen+commentLen;
        }
        return files;
    }

    function inflateRaw(data){
        var ip=0,bitBuf=0,bitCnt=0,out=[];
        var dataLen=data.length;
        function rb(){return ip<dataLen?data[ip++]:0;}
        function bits(n){
            while(bitCnt<n){bitBuf|=(rb()<<bitCnt);bitCnt+=8;}
            var v=bitBuf&((1<<n)-1);bitBuf>>>=n;bitCnt-=n;return v;
        }
        function buildHuffTree(lens,n){
            var MAX_BITS=15;
            var bl_count=new Array(MAX_BITS+1).fill(0);
            for(var i=0;i<n;i++)if(lens[i]>0)bl_count[lens[i]]++;
            bl_count[0]=0;
            var next_code=new Array(MAX_BITS+1).fill(0);
            var code=0;
            for(var bits_=1;bits_<=MAX_BITS;bits_++){
                code=(code+bl_count[bits_-1])<<1;
                next_code[bits_]=code;
            }
            var nodes=[];
            for(var i=0;i<n;i++){
                if(lens[i]>0){
                    nodes.push({len:lens[i],code:next_code[lens[i]]++,val:i});
                }
            }
            var root={children:[null,null],sym:-1};
            for(var i=0;i<nodes.length;i++){
                var nd=nodes[i];
                var cur=root;
                for(var b=nd.len-1;b>=0;b--){
                    var bit=(nd.code>>b)&1;
                    if(!cur.children[bit])cur.children[bit]={children:[null,null],sym:-1};
                    cur=cur.children[bit];
                }
                cur.sym=nd.val;
            }
            return root;
        }
        var fltTree,fstTree;
        function getFltTree(){
            if(fltTree)return fltTree;
            var l=new Array(288).fill(8);
            for(var i=144;i<256;i++)l[i]=9;
            for(var i=280;i<288;i++)l[i]=7;
            fltTree=buildHuffTree(l,288);return fltTree;
        }
        function getFstTree(){
            if(fstTree)return fstTree;
            fstTree=buildHuffTree(new Array(32).fill(5),32);return fstTree;
        }
        function readHuffSym(tree){
            var cur=tree;
            for(var i=0;i<15;i++){
                var bit=bits(1);
                cur=cur.children[bit];
                if(!cur)return 0;
                if(cur.sym>=0)return cur.sym;
            }
            return 0;
        }
        var bfinal,btype;
        var safetyCounter=0;
        do{
            if(++safetyCounter>100000){break;}
            bfinal=bits(1);btype=bits(2);
            if(btype===0){
                if(bitCnt>0){bitBuf=0;bitCnt=0;}
                var ln=rb()|(rb()<<8);
                var nln=rb()|(rb()<<8);
                for(var i=0;i<ln;i++)out.push(rb());
            }else{
                var ltRoot,dtRoot;
                if(btype===1){ltRoot=getFltTree();dtRoot=getFstTree();}
                else{
                    var hlit=bits(5)+257,hdist=bits(5)+1,hclen=bits(4)+4;
                    var co=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];
                    var cl=new Array(19).fill(0);
                    for(var i=0;i<hclen;i++)cl[co[i]]=bits(3);
                    var ct=buildHuffTree(cl,19),al=[],tot=hlit+hdist;
                    while(al.length<tot){
                        var s=readHuffSym(ct);
                        if(s<16){al.push(s);}
                        else if(s===16){var r=bits(2)+3;var p=al.length?al[al.length-1]:0;for(var j=0;j<r;j++)al.push(p);}
                        else if(s===17){var n=bits(3)+3;al.length+=n;}
                        else if(s===18){var n=bits(7)+11;al.length+=n;}
                    }
                    al.length=tot;
                    ltRoot=buildHuffTree(al.slice(0,hlit),hlit);
                    dtRoot=buildHuffTree(al.slice(hlit),hdist);
                }
                var blockSafety=0;
                while(++blockSafety<100000){
                    var sym=readHuffSym(ltRoot);
                    if(sym===256)break;
                    if(sym<256){out.push(sym);continue;}
                    var lb,le;
                    if(sym<=264){lb=sym-254;le=0;}
                    else if(sym<=284){
                        var x=sym-265;
                        lb=[11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227][x];
                        le=[1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5][x];
                    }else{lb=258;le=0;}
                    var len=lb+(le?bits(le):0);
                    var dsym=readHuffSym(dtRoot),db,de;
                    if(dsym<=3){db=dsym+1;de=0;}
                    else{
                        var dx=dsym-4;
                        db=[5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577][dx];
                        de=[1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13][dx];
                    }
                    var dist=db+(de?bits(de):0);
                    for(var i=0;i<len;i++)out.push(out[out.length-dist]);
                }
            }
        }while(!bfinal);
        return new Uint8Array(out);
    }

    function extractSlideInfo(xml){
        var info={bg:'#ffffff',shapes:[]};
        // Extract background color
        var bgMatch=xml.match(/<a:solidFill>[\s\S]*?<a:srgbClr[^>]*val="([0-9A-Fa-f]{6})"[\s\S]*?<\/a:solidFill>[\s\S]*?<\/p:bg>/i);
        if(bgMatch)info.bg='#'+bgMatch[1];

        function extractTextFromXml(block){
            var texts=[];
            // paragraphs in sp
            var ps=block.match(/<a:p[^>]*>[\s\S]*?<\/a:p>/gi)||[];
            ps.forEach(function(p){
                var runs=p.match(/<a:r[^>]*>[\s\S]*?<\/a:r>/gi)||[];
                var pText='';var pColor=null;var pSize=null;var pBold=false;
                runs.forEach(function(r){
                    var tm=r.match(/<a:t[^>]*>([^<]*)<\/a:t>/i);
                    if(!tm||!tm[1])return;
                    pText+=tm[1];
                    var rPr=r.match(/<a:rPr[^>]*>/i);
                    if(rPr){
                        var sz=rPr[0].match(/sz="(\d+)"/i);
                        if(sz){var s=parseInt(sz[1])/100;if(!pSize||s>pSize)pSize=s;}
                        var cl=rPr[0].match(/val="([0-9A-Fa-f]{6})"/i);
                        if(cl)pColor='#'+cl[1];
                        if(rPr[0].match(/b="1"/i))pBold=true;
                    }
                });
                if(pText.trim())texts.push({text:pText.trim(),color:pColor,size:pSize,bold:pBold});
            });
            // Also extract from nested groups
            var grps=block.match(/<p:grpSp[^>]*>[\s\S]*?<\/p:grpSp>/gi)||[];
            grps.forEach(function(g){texts=texts.concat(extractTextFromXml(g));});
            return texts;
        }

        // Extract from all shapes including graphicFrame (tables)
        var allBlocks=xml.match(/<p:(?:sp|grpSp|pic|graphicFrame)[^>]*>[\s\S]*?<\/p:(?:sp|grpSp|pic|graphicFrame)>/gi)||[];
        allBlocks.forEach(function(block){
            // Extract table cell text
            var tblMatch=block.match(/<a:tbl[^>]*>[\s\S]*?<\/a:tbl>/i);
            if(tblMatch){
                var cells=tblMatch[0].match(/<a:tc[^>]*>[\s\S]*?<\/a:tc>/gi)||[];
                cells.forEach(function(cell){
                    var cellTexts=extractTextFromXml(cell);
                    cellTexts.forEach(function(t){t.isTable=true;});
                    info.shapes.push({type:'table',texts:cellTexts});
                });
                return;
            }
            var texts=extractTextFromXml(block);
            if(texts.length>0){
                // Check position
                var off=block.match(/<a:off[^>]*x="(\d+)"[^>]*y="(\d+)"/i);
                var ext=block.match(/<a:ext[^>]*cx="(\d+)"[^>]*cy="(\d+)"/i);
                var x=off?parseInt(off[1]):0;
                var y=off?parseInt(off[2]):0;
                var w=ext?parseInt(ext[1]):9144000;
                var h=ext?parseInt(ext[2]):6858000;
                info.shapes.push({type:'text',texts:texts,x:x,y:y,w:w,h:h});
            }
        });

        // Fallback: extract any remaining text
        if(info.shapes.length===0){
            var raw=xml.replace(/<[^>]+>/g,' ').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/\s+/g,' ').trim();
            if(raw.length>5)info.shapes.push({type:'text',texts:[{text:raw,color:null,size:null,bold:false}],x:0,y:0,w:9144000,h:6858000});
        }
        return info;
    }

    function renderPpt(url, name, container){
        container.innerHTML='<div style="padding:20px;text-align:center;"><i class="fa fa-spinner fa-spin" style="font-size:24px;color:var(--primary);"></i><p style="color:var(--text-dim);margin-top:8px;">加载PPT中...</p></div>';
        fetch(url).then(function(r){return r.arrayBuffer();}).then(function(buf){
            var files=readZip(buf);
            var slideKeys=Object.keys(files).filter(function(k){return /^ppt\/slides\/slide\d+\.xml$/i.test(k);});
            slideKeys.sort(function(a,b){
                var na=parseInt(a.match(/slide(\d+)/i)[1]);
                var nb=parseInt(b.match(/slide(\d+)/i)[1]);
                return na-nb;
            });
            if(slideKeys.length===0){
                container.innerHTML='<div style="padding:40px;text-align:center;"><i class="fa fa-file-powerpoint-o" style="font-size:64px;color:#D04423;display:block;margin-bottom:16px;"></i><p style="color:var(--text-sub);">无法解析PPT内容</p><p style="color:var(--text-dim);font-size:.8125rem;margin-top:8px;">请下载后查看</p></div>';
                return;
            }
            var slides=[];
            slideKeys.forEach(function(k){
                var bytes=files[k];
                var xml=new TextDecoder('utf-8').decode(bytes);
                slides.push(extractSlideInfo(xml));
            });
            var cur=0;
            function renderSlide(){
                var s=slides[cur];
                var bgColor=s.bg;
                var r=parseInt(bgColor.substr(1,2),16),g=parseInt(bgColor.substr(3,2),16),b=parseInt(bgColor.substr(5,2),16);
                var bright=(r*299+g*587+b*114)/1000;
                var defaultText=bright>128?'#333333':'#ffffff';
                var subText=bright>128?'#666666':'#cccccc';

                var html='<div style="background:'+bgColor+';border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,0.15);max-width:720px;margin:0 auto;aspect-ratio:16/9;position:relative;overflow:auto;min-height:300px;padding:24px 32px;">';

                if(s.shapes.length===0){
                    html+='<div style="display:flex;align-items:center;justify-content:center;height:100%;"><p style="color:'+subText+';">（空白页）</p></div>';
                }else{
                    // Sort shapes by Y then X position
                    var sorted=s.shapes.slice().sort(function(a,b){return (a.y||0)-(b.y||0)||(a.x||0)-(b.x||0);});

                    // Detect title: first shape with large text, typically at top
                    var titleShape=null;
                    var contentShapes=[];
                    sorted.forEach(function(sh){
                        if(!titleShape&&!sh.isTable){
                            var maxSz=0;
                            sh.texts.forEach(function(t){if(t.size&&t.size>maxSz)maxSz=t.size;});
                            var hasLarge=maxSz>=28||(sh.y||0)<2000000;
                            if(hasLarge){titleShape=sh;return;}
                        }
                        contentShapes.push(sh);
                    });

                    // Render title
                    if(titleShape){
                        titleShape.texts.forEach(function(t){
                            var fs=t.size||32;if(fs>56)fs=56;if(fs<16)fs=16;
                            var clr=t.color||defaultText;
                            html+='<p style="font-size:'+fs+'px;font-weight:'+(t.bold?'700':'600')+';color:'+clr+';margin:0 0 16px 0;line-height:1.3;word-wrap:break-word;">'+escapeHtml(t.text)+'</p>';
                        });
                        html+='<div style="height:1px;background:'+(bright>128?'rgba(0,0,0,0.08)':'rgba(255,255,255,0.15)')+';margin:0 0 16px 0;"></div>';
                    }

                    // Render content
                    contentShapes.forEach(function(sh){
                        if(sh.type==='table'){
                            html+='<div style="margin:6px 0;padding:6px 10px;background:'+(bright>128?'rgba(0,0,0,0.03)':'rgba(255,255,255,0.08)')+';border-radius:4px;">';
                            sh.texts.forEach(function(t){
                                var fs=t.size||14;if(fs>24)fs=24;if(fs<10)fs=10;
                                var clr=t.color||subText;
                                html+='<span style="font-size:'+fs+'px;color:'+clr+';margin-right:8px;">'+escapeHtml(t.text)+'</span>';
                            });
                            html+='</div>';
                        }else{
                            sh.texts.forEach(function(t){
                                var fs=t.size||18;if(fs>40)fs=40;if(fs<10)fs=10;
                                var clr=t.color||defaultText;
                                var fw=t.bold?'700':'400';
                                var isBullet=t.text.match(/^[\u2022\u25cf\u25cb\u25a0\u25b6\-\*\•]/)||t.text.match(/^\d+[\.\)]/);
                                var indent=isBullet?'padding-left:16px;':'';
                                html+='<p style="font-size:'+fs+'px;color:'+clr+';font-weight:'+fw+';line-height:1.6;margin:4px 0;word-wrap:break-word;'+indent+'">'+escapeHtml(t.text)+'</p>';
                            });
                        }
                    });
                }
                html+='</div>';
                html+='<div style="display:flex;align-items:center;justify-content:center;gap:16px;margin-top:16px;">';
                html+='<button onclick="pptNav(-1)" style="padding:8px 16px;border-radius:8px;border:1px solid var(--border);background:#fff;cursor:pointer;font-size:.8125rem;'+(cur===0?'opacity:.4;pointer-events:none;':'')+'"><i class="fa fa-chevron-left"></i> 上一页</button>';
                html+='<span style="color:var(--text-dim);font-size:.8125rem;">'+(cur+1)+' / '+slides.length+'</span>';
                html+='<button onclick="pptNav(1)" style="padding:8px 16px;border-radius:8px;border:1px solid var(--border);background:#fff;cursor:pointer;font-size:.8125rem;'+(cur===slides.length-1?'opacity:.4;pointer-events:none;':'')+'">下一页 <i class="fa fa-chevron-right"></i></button>';
                html+='</div>';
                html+='<p style="text-align:center;color:var(--text-dim);font-size:.75rem;margin-top:10px;"><i class="fa fa-info-circle"></i> 在线预览可能无法完整显示全部内容，建议下载后查看完整版本</p>';
                container.innerHTML=html;
            }
            window.pptNav=function(d){cur=Math.max(0,Math.min(slides.length-1,cur+d));renderSlide();};
            renderSlide();
        }).catch(function(e){
            container.innerHTML='<div style="padding:40px;text-align:center;"><i class="fa fa-file-powerpoint-o" style="font-size:64px;color:#D04423;display:block;margin-bottom:16px;"></i><p style="color:var(--text-sub);">PPT 加载失败</p><p style="color:var(--text-dim);font-size:.8125rem;margin-top:8px;">请下载后查看</p></div>';
        });
    }

    function preview(id, name, ext, url, container){
        var lower = getExt(name);
        if(!ext) ext = lower;

        if(isImage(name)){
            if(lower === 'svg'){
                renderSvg(url, name, container);
            } else {
                container.innerHTML = renderImage(url, name);
                var img = container.querySelector('img');
                if(img) img.onload = function(){
                    if(window.GLightbox){
                        GLightbox({elements:[{type:'image',href:url,title:name}]});
                    }
                };
            }
        } else if(isVideo(name)){
            container.innerHTML = renderVideo(url, lower);
            if(window.Plyr){
                new Plyr('#previewPlayer',{captions:{active:true}});
            }
        } else if(isAudio(name)){
            container.innerHTML = renderAudio(url, lower, name);
            if(window.Plyr){
                new Plyr('#previewPlayer');
            }
        } else if(isPdf(name)){
            renderPdf(url, container);
        } else if(isMarkdown(name)){
            renderMarkdown(url, container);
        } else if(isExcel(name)){
            renderExcel(url, container);
        } else if(isWord(name)){
            renderWord(url, container);
        } else if(isPpt(name)){
            container.innerHTML = renderUnsupported('ppt');
        } else if(isText(name)){
            renderText(url, container);
        } else if(isCode(name)){
            renderCode(url, container);
        } else if(isArchive(name)){
            container.innerHTML = renderUnsupported('archive');
        } else {
            container.innerHTML = renderUnsupported();
        }
    }

    function toggleFullscreen(){
        var card = document.querySelector('#previewModal .modal-card');
        if(!card) return;
        if(!document.fullscreenElement){
            card.requestFullscreen().catch(function(){});
        }else{
            document.exitFullscreen();
        }
    }

    function previewModal(id, name, ext, url){
        var modal = document.getElementById('previewModal');
        var title = document.getElementById('previewTitle');
        var content = document.getElementById('previewContent');
        var dlBtn = document.getElementById('previewDownload');
        title.textContent = '预览 - ' + name;
        dlBtn.href = 'download.php?id=' + id;
        content.innerHTML = '<div style="padding:20px;text-align:center;"><i class="fa fa-spinner fa-spin" style="font-size:24px;color:var(--primary);"></i></div>';
        modal.classList.add('show');
        preview(id, name, ext, url, content);
    }

    return {
        preview: preview,
        previewModal: previewModal,
        toggleFullscreen: toggleFullscreen,
        isImage: isImage,
        isVideo: isVideo,
        isAudio: isAudio,
        isPdf: isPdf,
        isText: isText,
        isCode: isCode
    };
})();
</script>
