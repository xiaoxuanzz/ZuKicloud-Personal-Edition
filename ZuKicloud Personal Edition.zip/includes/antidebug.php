<script>
var _dc=0;function _lock(){if(_dc)return;_dc=1;var id=setInterval(function(){},99999);for(var i=0;i<=id;i++){clearInterval(i);clearTimeout(i);}
var o=document.createElement('div');o.id='_lk';o.style.cssText='position:fixed;inset:0;z-index:999999;background:#f8f9fa;display:flex;align-items:center;justify-content:center;font-family:sans-serif';
o.innerHTML='<div style="text-align:center"><h1 style="color:#555;font-size:1.5rem;font-weight:600">安全提示</h1><p style="color:#999;font-size:.9rem">检测到开发者工具，页面已锁定</p></div>';
document.documentElement.appendChild(o);
document.documentElement.style.overflow='hidden';
document.body.style.overflow='hidden';}
function _ck(){if(_dc)return;if(document.getElementById('_lk')){_dc=1;return;}var d=window.outerWidth-window.innerWidth>160||window.outerHeight-window.innerHeight>160;if(d)_lock();}
_ck();
document.addEventListener('DOMContentLoaded',_ck);
setInterval(_ck,800);
document.addEventListener('keydown',function(e){if(e.keyCode===123||(e.ctrlKey&&e.shiftKey&&(e.keyCode===73||e.keyCode===74)))_lock()});
document.addEventListener('contextmenu',function(e){e.preventDefault()});
</script>
