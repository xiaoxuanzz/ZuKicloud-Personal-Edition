<?php
require_once __DIR__ . '/../config.php';

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
    // Add bg columns if not exist
    try { $pdo->exec("ALTER TABLE users ADD COLUMN bg_image VARCHAR(255) DEFAULT NULL"); } catch(Exception $e) {}
    try { $pdo->exec("ALTER TABLE users ADD COLUMN bg_opacity INT DEFAULT 15"); } catch(Exception $e) {}
} catch (PDOException $e) {
    die("数据库连接失败: " . $e->getMessage());
}
