<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/safe_render.php';
SafeRender::init();
requireLogin();

$activePage = 'security';

// 爬虫检测与拦截
$ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
$crawlerPatterns = ['bot', 'spider', 'crawler', 'curl', 'wget', 'python-requests', 'scrapy', 'headless', 'phantom', 'selenium', 'puppeteer', 'httpclient', 'go-http-client', 'java/', 'php/', 'ruby'];
$isCrawler = false;
$matchedPattern = '';
foreach ($crawlerPatterns as $pattern) {
    if (stripos($ua, $pattern) !== false) {
        $isCrawler = true;
        $matchedPattern = $pattern;
        break;
    }
}

// 记录爬虫事件并拦截
if ($isCrawler) {
    logSecurityEvent('crawler_blocked', getClientIp(), [
        'ua' => mb_substr($ua, 0, 200),
        'pattern' => $matchedPattern,
        'action' => '已拦截',
        'request_uri' => $_SERVER['REQUEST_URI'] ?? '',
        'request_method' => $_SERVER['REQUEST_METHOD'] ?? '',
        'referer' => $_SERVER['HTTP_REFERER'] ?? '',
        'response' => '返回403并终止请求'
    ]);
    http_response_code(403);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>403</title></head><body>';
    echo '<div style="text-align:center;padding:80px 20px;font-family:sans-serif;">';
    echo '<h1 style="color:#ef4444;">🚫 访问被拒绝</h1>';
    echo '<p style="color:#64748b;">检测到自动化工具访问，请求已被拦截</p>';
    echo '</div></body></html>';
    exit;
}

$today = date('Y-m-d');
$week = date('Y-m-d', strtotime('-7 days'));
$loginAttempts = $pdo->query("SELECT COUNT(*) FROM security_events WHERE event_type='failed_login' AND DATE(created_at)='$today'")->fetchColumn();
$rateBlocks = $pdo->query("SELECT COUNT(*) FROM security_events WHERE event_type='rate_block' AND DATE(created_at)='$today'")->fetchColumn();
$loginSuccess = $pdo->query("SELECT COUNT(*) FROM security_events WHERE event_type='login_success' AND DATE(created_at)='$today'")->fetchColumn();
$weekAttempts = $pdo->query("SELECT COUNT(*) FROM security_events WHERE event_type='failed_login' AND created_at>='$week'")->fetchColumn();
$crawlerDetected = $pdo->query("SELECT COUNT(*) FROM security_events WHERE event_type='crawler_detected' AND DATE(created_at)='$today'")->fetchColumn();
$crawlerBlocked = $pdo->query("SELECT COUNT(*) FROM security_events WHERE event_type='crawler_blocked' AND DATE(created_at)='$today'")->fetchColumn();
$recentEvents = $pdo->query("SELECT * FROM security_events ORDER BY created_at DESC LIMIT 10")->fetchAll();

ob_start();
require_once __DIR__ . '/includes/header.php';
?>

<div class="content-area">
    <div class="settings-wrap">
        <!-- 安全概览 -->
        <section class="settings-sec">
            <h3><i class="fa fa-shield" style="color:var(--primary)"></i> 安全概览</h3>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;">
                <div style="background:var(--primary-bg);border-radius:12px;padding:16px;text-align:center;">
                    <div style="font-size:1.5rem;font-weight:700;color:var(--primary);"><?= $loginSuccess ?></div>
                    <div style="font-size:.75rem;color:var(--text-sub);margin-top:4px;">今日登录成功</div>
                </div>
                <div style="background:#FEF2F2;border-radius:12px;padding:16px;text-align:center;">
                    <div style="font-size:1.5rem;font-weight:700;color:var(--danger);"><?= $loginAttempts ?></div>
                    <div style="font-size:.75rem;color:var(--text-sub);margin-top:4px;">今日登录失败</div>
                </div>
                <div style="background:#FEF3C7;border-radius:12px;padding:16px;text-align:center;">
                    <div style="font-size:1.5rem;font-weight:700;color:var(--warning);"><?= $rateBlocks ?></div>
                    <div style="font-size:.75rem;color:var(--text-sub);margin-top:4px;">今日限流触发</div>
                </div>
                <div style="background:#FEE2E2;border-radius:12px;padding:16px;text-align:center;">
                    <div style="font-size:1.5rem;font-weight:700;color:var(--danger);"><?= $crawlerBlocked ?></div>
                    <div style="font-size:.75rem;color:var(--text-sub);margin-top:4px;">今日爬虫拦截</div>
                </div>
            </div>
        </section>

        <!-- 防护状态（默认折叠） -->
        <section class="settings-sec" id="protectionSection">
            <div style="display:flex;align-items:center;justify-content:space-between;cursor:pointer;" onclick="toggleProtection()">
                <h3 style="margin-bottom:0;"><i class="fa fa-check-circle" style="color:var(--success)"></i> 防护状态</h3>
                <i class="fa fa-chevron-down" id="protectionArrow" style="color:var(--text-dim);transition:transform .3s;font-size:12px;"></i>
            </div>
            <div id="protectionList" style="display:none;margin-top:16px;">
                <?php
                $protections = [
                    ['name' => '登录限流', 'desc' => '5次/分钟，超限封锁5分钟', 'status' => true],
                    ['name' => 'CSRF 保护', 'desc' => '所有表单提交需验证令牌', 'status' => true],
                    ['name' => '路径遍历防护', 'desc' => '下载时验证文件路径', 'status' => true],
                    ['name' => 'API 密钥验证', 'desc' => 'AJAX 请求需携带页面密钥', 'status' => true],
                    ['name' => '源码加密', 'desc' => '页面输出 Base64 加密', 'status' => true],
                    ['name' => '反调试检测', 'desc' => '检测开发者工具', 'status' => true],
                    ['name' => '爬虫防护', 'desc' => '检测 User-Agent 中的 bot/spider/crawler 关键词', 'status' => true],
                ];
                foreach ($protections as $p): ?>
                <div class="info-row">
                    <span class="info-label"><?= $p['name'] ?></span>
                    <span style="font-size:.75rem;color:<?= $p['status']?'var(--success)':'var(--danger)' ?>;">
                        <i class="fa fa-<?= $p['status']?'check-circle':'times-circle' ?>"></i>
                        <?= $p['status']?'已启用':'未启用' ?>
                    </span>
                </div>
                <?php endforeach; ?>
            </div>
        </section>

        <!-- 最近安全事件 -->
        <section class="settings-sec">
            <h3><i class="fa fa-clock-o" style="color:var(--primary)"></i> 最近安全事件</h3>
            <?php if (empty($recentEvents)): ?>
                <p style="color:var(--text-dim);font-size:.875rem;text-align:center;padding:20px;">暂无安全事件记录</p>
            <?php else: ?>
            <div style="display:flex;flex-direction:column;gap:8px;">
                <?php foreach ($recentEvents as $ev): ?>
                    <?php
                    $isOk = in_array($ev['event_type'], ['login_success']);
                    $label = $isOk ? '正常' : '异常';
                    $color = $isOk ? 'var(--success)' : 'var(--danger)';
                    $bg = $isOk ? '#F0FDF4' : '#FEF2F2';
                    $icon = 'info-circle';
                    if ($ev['event_type'] === 'login_success') $icon = 'check-circle';
                    elseif ($ev['event_type'] === 'failed_login') $icon = 'times-circle';
                    elseif ($ev['event_type'] === 'rate_block') $icon = 'ban';
                    elseif ($ev['event_type'] === 'crawler_blocked') $icon = 'shield';
                    $detail = '';
                    if ($ev['event_type'] === 'failed_login') $detail = '登录失败';
                    elseif ($ev['event_type'] === 'rate_block') $detail = '触发限流封锁';
                    elseif ($ev['event_type'] === 'crawler_detected') $detail = '检测到爬虫';
                    elseif ($ev['event_type'] === 'crawler_blocked') $detail = '爬虫已拦截';
                    else $detail = '操作成功';
                    ?>
                    <div style="display:flex;align-items:center;gap:12px;padding:10px 14px;border-radius:10px;background:<?= $bg ?>;cursor:pointer;transition:all .15s;" onclick="showEventDetail(this.getAttribute('data-ev'))" data-ev="<?= htmlspecialchars(json_encode($ev, JSON_UNESCAPED_UNICODE), ENT_QUOTES) ?>" onmouseover="this.style.opacity='.85'" onmouseout="this.style.opacity='1'">
                        <span style="width:28px;height:28px;border-radius:8px;display:flex;align-items:center;justify-content:center;background:<?= $color ?>;flex-shrink:0;"><i class="fa fa-<?= $icon ?>" style="font-size:12px;color:#fff;"></i></span>
                        <span style="font-size:.75rem;color:var(--text-dim);min-width:80px;"><?= date('m-d H:i', strtotime($ev['created_at'])) ?></span>
                        <span style="font-size:.8125rem;font-weight:600;color:<?= $color ?>;min-width:40px;"><?= $label ?></span>
                        <span style="font-size:.75rem;color:var(--text-sub);flex:1;"><?= $detail ?></span>
                        <span style="font-size:.7rem;color:var(--text-dim);"><?= htmlspecialchars($ev['ip']) ?></span>
                        <i class="fa fa-chevron-right" style="font-size:10px;color:var(--text-dim);"></i>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </section>
    </div>
</div>

<script>
function toggleProtection() {
    var list = document.getElementById('protectionList');
    var arrow = document.getElementById('protectionArrow');
    if (list.style.display === 'none') {
        list.style.display = 'block';
        arrow.style.transform = 'rotate(180deg)';
    } else {
        list.style.display = 'none';
        arrow.style.transform = 'rotate(0deg)';
    }
}

function showEventDetail(attr) {
    var modal = document.getElementById('eventDetailModal');
    var ev = {};
    try { ev = JSON.parse(attr); } catch(e) { ev = {event_type:'unknown',ip:'-',created_at:'-',details:'{}'}; }
    var details = {};
    try { details = JSON.parse(ev.details || '{}'); } catch(e) { details = {raw: ev.details || '无'}; }

    var typeMap = {
        'login_success': { label: '登录成功', icon: 'check-circle', color: '#10b981', bg: 'linear-gradient(135deg,#10b981,#059669)', severity: '信息', tip: '用户正常登录，无需处理' },
        'failed_login': { label: '登录失败', icon: 'times-circle', color: '#ef4444', bg: 'linear-gradient(135deg,#ef4444,#dc2626)', severity: '警告', tip: '连续失败可能为暴力破解，建议关注该IP' },
        'rate_block': { label: '限流封锁', icon: 'ban', color: '#f59e0b', bg: 'linear-gradient(135deg,#f59e0b,#d97706)', severity: '警告', tip: '请求过于频繁已被临时封锁，无需处理' },
        'crawler_detected': { label: '爬虫检测', icon: 'bug', color: '#f59e0b', bg: 'linear-gradient(135deg,#f59e0b,#d97706)', severity: '警告', tip: '检测到自动化工具访问' },
        'crawler_blocked': { label: '爬虫已拦截', icon: 'shield', color: '#ef4444', bg: 'linear-gradient(135deg,#ef4444,#dc2626)', severity: '严重', tip: '已返回403并终止请求，无需处理' }
    };
    var t = typeMap[ev.event_type] || { label: ev.event_type, icon: 'info-circle', color: '#6366f1', bg: 'linear-gradient(135deg,#6366f1,#4f46e5)', severity: '信息', tip: '' };

    document.getElementById('evtIcon').innerHTML = '<i class="fa fa-' + t.icon + '" style="font-size:22px;color:#fff;"></i>';
    document.getElementById('evtIcon').style.background = t.bg;
    document.getElementById('evtTitle').textContent = t.label;
    document.getElementById('evtTime').textContent = ev.created_at;
    document.getElementById('evtIp').textContent = ev.ip || '-';

    var sevColors = {'信息':'#3b82f6','警告':'#f59e0b','严重':'#ef4444'};
    var sevBg = {'信息':'#EFF6FF','警告':'#FFFBEB','严重':'#FEF2F2'};
    document.getElementById('evtSeverity').innerHTML = '<span style="display:inline-block;padding:2px 10px;border-radius:20px;font-size:.7rem;font-weight:600;background:'+(sevBg[t.severity]||'#f1f5f9')+';color:'+(sevColors[t.severity]||'#64748b')+';">'+t.severity+'</span>';
    document.getElementById('evtTip').textContent = t.tip || '';

    var fieldLabels = {
        'ua': 'User-Agent (浏览器标识)',
        'pattern': '匹配规则关键词',
        'action': '系统响应',
        'request_uri': '请求地址',
        'request_method': '请求方法',
        'referer': '来源页面',
        'response': '响应内容',
        'username': '用户名',
        'user_id': '用户ID',
        'wait': '等待时间(秒)',
        'attempts': '尝试次数',
        'key': '限流键',
        'raw': '原始数据'
    };

    var html = '';
    for (var k in details) {
        var val = details[k];
        if (typeof val === 'object' && val !== null) {
            try { val = JSON.stringify(val, null, 2); } catch(e) { val = String(val); }
        }
        var label = fieldLabels[k] || k;
        var isLong = String(val).length > 60;
        html += '<div style="padding:8px 0;border-bottom:1px solid #f1f5f9;">';
        html += '<div style="font-weight:600;color:#475569;font-size:.75rem;margin-bottom:4px;text-transform:uppercase;letter-spacing:.5px;">' + escHtml(label) + '</div>';
        html += '<div style="color:#1e293b;font-size:.8125rem;word-break:break-all;background:#f8fafc;padding:10px 14px;border-radius:8px;font-family:'+(isLong?'monospace':'inherit')+';line-height:1.6;white-space:'+(isLong?'pre-wrap':'normal')+';">' + escHtml(String(val)) + '</div>';
        html += '</div>';
    }
    document.getElementById('evtDetails').innerHTML = html || '<p style="color:#94a3b8;text-align:center;padding:16px;">无详细信息</p>';

    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeEventDetail() {
    document.getElementById('eventDetailModal').style.display = 'none';
    document.body.style.overflow = '';
}

function escHtml(s) { var d = document.createElement('div'); d.textContent = s; return d.innerHTML; }
</script>

<!-- Event Detail Modal -->
<div id="eventDetailModal" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.5);z-index:9999;align-items:center;justify-content:center;" onclick="if(event.target===this)closeEventDetail()">
    <div style="background:#fff;border-radius:16px;box-shadow:0 20px 60px rgba(0,0,0,.2);width:420px;max-width:92vw;max-height:80vh;overflow:hidden;">
        <div style="display:flex;align-items:center;gap:14px;padding:20px 24px;border-bottom:1px solid #f1f5f9;">
            <div id="evtIcon" style="width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;flex-shrink:0;"></div>
            <div style="flex:1;min-width:0;">
                <h3 id="evtTitle" style="font-size:16px;font-weight:700;color:#1e293b;margin:0;"></h3>
                <p id="evtTime" style="font-size:12px;color:#94a3b8;margin:2px 0 0;"></p>
            </div>
            <button onclick="closeEventDetail()" style="background:none;border:none;font-size:18px;color:#94a3b8;cursor:pointer;padding:4px;">×</button>
        </div>
        <div style="padding:4px 24px 20px;">
            <div style="display:flex;gap:16px;padding:10px 0;border-bottom:1px solid #f1f5f9;">
                <div style="flex:1;">
                    <div style="font-weight:600;color:#64748b;font-size:.7rem;text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px;">事件级别</div>
                    <div id="evtSeverity"></div>
                </div>
                <div style="flex:1;">
                    <div style="font-weight:600;color:#64748b;font-size:.7rem;text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px;">IP 地址</div>
                    <div id="evtIp" style="color:#1e293b;font-size:.875rem;font-weight:500;"></div>
                </div>
            </div>
            <div style="padding:10px 0;border-bottom:1px solid #f1f5f9;">
                <div style="font-weight:600;color:#64748b;font-size:.7rem;text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px;">处理建议</div>
                <div id="evtTip" style="color:#475569;font-size:.8125rem;background:#f0fdf4;padding:8px 12px;border-radius:8px;border-left:3px solid #22c55e;"></div>
            </div>
            <div style="padding-top:10px;">
                <div style="font-weight:600;color:#64748b;font-size:.7rem;text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px;">详细数据</div>
                <div id="evtDetails"></div>
            </div>
        </div>
    </div>
</div>

<?php
require_once __DIR__ . '/includes/footer.php';
$html = ob_get_clean();
SafeRender::render($html);
