<?php
/**
 * 定时清理未完成的分片上传文件
 * 
 * 建议通过 cron 每30分钟执行一次：
 *   */30 * * * * php /path/to/mycloud/cron_cleanup_chunks.php
 * 
 * 或通过 web 访问（带token）：
 *   http://your-domain/cron_cleanup_chunks.php?token=YOUR_SECRET
 */

$cliMode = (php_sapi_name() === 'cli');
$webToken = $_GET['token'] ?? '';

if (!$cliMode && $webToken !== 'mycloud_cleanup_' . date('Ymd')) {
    http_response_code(403);
    exit('Forbidden');
}

require_once __DIR__ . '/config.php';

$chunkDir = UPLOAD_DIR . '.chunks';
$maxAge = 30 * 60;
$activeThreshold = 5 * 60;

if (!is_dir($chunkDir)) {
    echo "No chunks directory found.\n";
    exit(0);
}

$dirs = glob($chunkDir . '/*', GLOB_ONLYDIR);
if (empty($dirs)) {
    echo "No chunk folders to clean.\n";
    exit(0);
}

$cleaned = 0;
foreach ($dirs as $dir) {
    $files = glob($dir . '/*');
    if (empty($files)) { @rmdir($dir); $cleaned++; continue; }

    $oldest = PHP_INT_MAX;
    $newest = 0;
    foreach ($files as $f) {
        $mtime = filemtime($f);
        if ($mtime < $oldest) $oldest = $mtime;
        if ($mtime > $newest) $newest = $mtime;
    }

    if ((time() - $newest) < $activeThreshold) continue;

    if ((time() - $oldest) > $maxAge) {
        foreach ($files as $f) { if (is_file($f)) @unlink($f); }
        @rmdir($dir);
        $cleaned++;
    }
}

echo "Cleaned $cleaned stale chunk folders.\n";
